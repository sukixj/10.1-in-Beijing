#include<algorithm>
#include<cstring>
#include<cstdio>
#include<queue>
using namespace std;

const int maxn = 1000006;
int n;
char a[maxn];
int cnt[33],cnt1[33];
int main() {
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",a);
	int maxn=-1,minn=0x7fffffff;
	int ans=1;
	for(int i=0; i<n; i++) {
		for(int tmp,j=i+1; j<n; j++) {
			memset(cnt,0,sizeof cnt);
			minn=0x7fffffff,maxn=-1;
			int min_who=30;
			cnt[30]=0x7fffffff;
			for(int q=i; q<=j; q++) {
				tmp=a[q]-'a'+1;
				cnt[tmp]++;
				minn=cnt[min_who];
				if(cnt[tmp]>maxn)maxn=cnt[tmp];
				if(cnt[tmp]<minn)minn=cnt[tmp],min_who=tmp;

			}
			ans=max(ans,maxn-minn);
		}
	}
	printf("%d\n",ans);
	return 0;
}
}
