#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;
double x1,y1,x2,y2;
double xx1,xx2,yy1,yy2;
double xxx1,yyy1,xxx2,yyy2;
struct node{
	double k,b;
}edge[10];int cnt=0;
void calc1(double x1,double y1,double x2,double y2) {
	double k=(y2-y1)/(x2-x1);
	double b=y1-x1*k;
	edge[++cnt].k=k,edge[cnt].b=b;
}
double calc2(double k1,double b1,double k2,double b2)//jiao dian ;
{
	//printf("%lf %lf %lf %lf %l\nf",k1,k2,b1,b2,(b2-b1)/(k1-k2));
	return (b2-b1)/(k1-k2);
}
double calc3(double x,double y,double k1,double b1)
{
	double k2,b2;
	k2=-1/k1,b2=y-k2*x;
	return calc2(k1,b1,k2,b2);
}
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%lf%lf%lf%lf",&x1,&y1,&x2,&y2);
	scanf("%lf%lf%lf%lf",&xx1,&yy1,&xx2,&yy2);
	scanf("%lf%lf%lf%lf",&xxx1,&yyy1,&xxx2,&yyy2);
	calc1(x1,y1,x2,y2);
	calc1(xx1,yy1,xx2,yy2);
	calc1(xxx1,yyy1,xxx2,yyy2);
	bool flag=0;
	if((y1-(edge[3].k*x1+edge[3].b))*(y2-(edge[3].k*x2+edge[3].b))>0)flag=1;
	if(edge[1].k!=edge[2].k&&edge[1].k!=edge[3].k) 
	{
		double t=calc2(edge[1].k,edge[1].b,edge[2].k,edge[2].b);
		if((t>=x1&&t<=x2)||(t>=x2&&t<=x1)&&flag)
		{
			double tt=calc3(x1,y1,edge[3].k,edge[3].b);
			if((tt>=xxx1&&tt<=xxx2)||(tt>=xxx2&&tt<=xxx1))
			{
				double yy=tt*edge[3].k+edge[3].b;
				calc1(tt,yy,x2,y2);
				double tttt=calc2(edge[2].k,edge[2].b,edge[4].k,edge[4].b);
				if((tttt>=xx1&&tttt<=xx2)||(tttt>=xx2&&tttt<=xx1))
				{
					puts("NO");return 0;
				}
			}
			else if((t>=x1&&t<=x2)||(t>=x2&&t<=x1))
			{
				puts("NO");return 0;
			}
		}
	}
	else if(edge[1].k==edge[2].k&&edge[1].k!=edge[3].k)
		{
			if(flag)
			{
				double tt=calc3(x1,y1,edge[3].k,edge[3].b);
				if((tt>=x1&&tt<=x2)||(tt>=x2&&tt<=x1))
				{
					int yy=tt*edge[3].k+edge[3].b;
					calc1(tt,yy,x2,y2);
					int tttt=calc2(edge[2].k,edge[2].b,edge[4].k,edge[4].b);
					if((tttt>=xx1&&tttt<=xx2)||(tttt>=xx2&&tttt<=xx1))
					{
						puts("NO");return 0;
					}
				}
			}
			else{
			puts("NO");return 0;	
			} 
		}
	puts("YES");
	return 0;
}
