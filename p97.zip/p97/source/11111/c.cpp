#include<iostream>
using namespace std;
int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	cout<<5;
	return 0;
}
