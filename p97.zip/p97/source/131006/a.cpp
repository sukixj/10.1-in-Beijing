#include <iostream>
using namespace std;
#include <cstdio>
#include <queue>
#include <cstring>
char str[1001000];
int num[27]={0};
int main(){
    freopen("a.in","r",stdin);
    freopen("a.out","w",stdout);
	int n;
	scanf("%d",&n);
	int ans,tmp;
	ans=0;
	tmp=0;
	scanf("%s",str+1);
	for(int i=1;i<=n;i++){
         num[str[i]-'a'+1]++;
         int ma,mi;
         ma=0,mi=99;
         for(int j=1;j<=26;j++){
                 ma=max(ma,num[j]);
                 if(num[j]) mi=min(mi,num[j]);
         }
         ans=max(ans,ma-mi);
    }
    
    for(int i=1;i<=n;i++){
         num[str[i]-'a'+1]--;
         int ma,mi;
         ma=0,mi=99;
         for(int j=1;j<=26;j++){
                 ma=max(ma,num[j]);
                 if(num[j]) mi=min(mi,num[j]);
         }
         ans=max(ans,ma-mi);
    }
    cout<<ans<<endl;
	
	
	return 0;
}
