#include <iostream>
using namespace std;
#include <cstdio>
#define ld float
struct point{
       ld x,y;
};
int flag=0;
point intersection(point pa,point pb,point pc,point pd){
     flag=0;
    ld k1,b1,k2,b2;
    point ans;
    ans.x=ans.y=0;
    k1=(ld)(pa.y-pb.y)/(pa.x-pb.x);
    b1=(ld)(pa.y-k1*pa.x);
  
    if(pc.x==pd.x){
        if(pa.x==pb.x){
	         flag=1;
	         return ans;
        }
        ans.x=pc.x;
        ans.y=k1*pc.x +b1;
        return ans;
    }
    k2=(ld)(pc.y-pd.y)/(pc.x-pd.x);
    b2=(ld)(pc.y-k2*pc.x);
    if(pa.x==pb.x){
         ans.x=pa.x;
         ans.y=k2*ans.x+b2;
         return ans;
    }
    
    ans.x=(b2-b1)/(k1-k2);
    ans.y=k1*ans.x+b1;
    
    return ans;
}

int onSeg(point t,point a,point b){
		if(a.y>b.y){
				point tmp=a;
				a=b;
				b=tmp;
}
	if(a.x==b.x) return t.x==a.x && (t.y>a.y && t.y<b.y);
	if(a.x>b.x){
				point tmp=a;
				a=b;
				b=tmp;
}
	ld k1=(a.y-b.y)/(a.x-b.x);
	ld k=(t.y-a.y)/(t.x-a.x);
	if(k==k1 && a.x<t.x && t.x<b.x) return 1;
	return 0;	
}
int main(){
    freopen("b.out","w",stdout);
    freopen("b.in","r",stdin);
    point ptHja,ptYjq,ptWal1,ptWal2,ptMir1,ptMir2;
    scanf("%f%f",&ptHja.x,&ptHja.y);
    scanf("%f%f",&ptYjq.x,&ptYjq.y);
    scanf("%f%f%f%f",&ptWal1.x,&ptWal1.y,&ptWal2.x,&ptWal2.y);
    scanf("%f%f%f%f",&ptMir1.x,&ptMir1.y,&ptMir2.x,&ptMir2.y);
    point t;
    t=intersection(ptHja,ptYjq,ptWal1,ptWal2);
    if(!onSeg(t,ptWal1,ptWal2)){
				printf("YES\n");
				return 0;
    }
    // reflection from the mirror
    ld kk,bb,kprime1,kprime2,bprime1,bprime2;
    kk=(ld)(ptMir1.y-ptMir2.y)/(ptMir1.x-ptMir2.x);
    bb=(ld)(ptMir1.y-kk*ptMir1.x);
  //  printf("%f %f slope\n",kk,bb);
    kprime1=-1/kk;
    bprime1=ptHja.y-kprime1*ptHja.x;
    kprime2=-1/kk;
    bprime2=ptYjq.y-kprime2*ptYjq.x;
    
    point v1,v2;
    v1.x=(bb-bprime1)/(kprime1-kk);
    v1.y=kk*v1.x+bb;
    v2.x=(bb-bprime2)/(kprime2-kk);
    v2.y=kk*v2.x+bb;
    if(kk==0){
			  v1.x=ptHja.x;
			  v2.x=ptYjq.x;
			  v1.y=v2.y=bb;
}
if(ptMir1.x==ptMir2.x){
	v1.x=v2.x=ptMir1.x;
	v1.y=ptHja.y;
	v2.y=ptYjq.y;			   				   
}
 //   printf("%f %f %f %f v\n",v1.x,v1.y,v2.x,v2.y);
    point mid;
    mid.x=(v1.x+v2.x)/2;
    mid.y=(v1.y+v2.y)/2;
 //   printf("%f %f mid\n",mid.x,mid.y);
    //on the edge
    if((mid.x==ptMir1.x && mid.y==ptMir1.y)||(mid.x==ptMir2.x && mid.y==ptMir2.y)){
		 
 	 	 printf("NO");
 	 	 return 0;
	}
    
    point int1,int2;
    int1=intersection(mid,ptHja,ptWal1,ptWal2);
    int2=intersection(mid,ptYjq,ptWal1,ptWal2);
    
    if(!onSeg(int1,ptWal1,ptWal2) && !onSeg(int2,ptWal1,ptWal2)) printf("YES");
    else printf("NO");
    
    return 0;
}
