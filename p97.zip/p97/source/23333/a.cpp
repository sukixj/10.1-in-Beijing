#include<cstring>
#include<fstream>
#define MAXN 1100
#define INF 0x3f
using namespace std;
ifstream cin("a.in");
ofstream cout("a.out");

int len, cnt[26], maximum, minimum, ans = 0;
char num[MAXN];

int main(){
	cin >> len;
	for(int i = 1; i <= len; i++) cin>>num[i];
	for(int i = 1; i <= len; i++)
        for(int j = 1; j <= len; j++){
        	memset(cnt, 0, sizeof(cnt));
        	maximum = 0; minimum = INF;
            for(int k = i; k <= j; k++) cnt[num[k] - 'a']++;
            for(int k = 0; k < 26; k++)
                if(cnt[k] != 0) {maximum = max(maximum, cnt[k]); minimum = min(minimum, cnt[k]);}
		    ans = max(ans, maximum - minimum);
		}
	cout<<ans;
    return 0;
}
