#include<fstream>
#define INF 0xffffffff
using namespace std;
ifstream cin("b.in");
ofstream cout("b.out");

struct Point {int x, y;};
bool Intersect(Point a1, Point a2, Point b1, Point b2);
double min(double a, double b) {return a < b ? a : b;}
double max(double a, double b) {return a > b ? a : b;}

Point hja, yjq;
Point wall1, wall2;
Point mirr1, mirr2;

int main(){
    cin >> hja.x >> hja.y;
    cin >> yjq.x >> yjq.y;
    cin >> wall1.x >> wall1.y >> wall2.x >> wall2.y;
    cin >> mirr1.x >> mirr1.y >> mirr2.x >> mirr2.y;
    if(Intersect(hja, yjq, wall1, wall2)) {cout << "NO"; return 0;}
    if(Intersect(hja, yjq, mirr1, mirr2)) {cout << "NO"; return 0;}
    cout << "YES"; return 0;
}

bool Intersect(Point a1, Point a2, Point b1, Point b2){
    double i1, j1, i2, j2, x, y;
    if(a2.x - a1.x != 0) i1 = (a2.y - a1.y) / (a2.x - a1.x);
    else i1 = INF;
	if(i1 != INF) j1 = a1.y - a1.x * i1;
    else j1 = a1.x;
    
    if(b2.x - b1.x != 0) i2 = (b2.y - b1.y) / (b2.x - b1.x);
    else i2 = INF;
	if(i2 != INF) j2 = b1.y - b1.x * i2;
    else j2 = b1.x;
    
    if(i1 != i2 && i1 != INF && i2 != INF) x = (j2 - j1) / (i1 - i2);
    else if(i1 == INF && i2 == INF) return false;
    else if(i1 == INF && i2 != INF) return a1.x;
    else if(i1 != INF && i2 == INF) return a2.x;
	y = x * i1 + j1;
    
    if(x > max(a1.x, a2.x) || x < min(a1.x, a2.x) || x > max(b1.x, b2.x) || x < min(b1.x, b2.x)) return false;
    if(y > max(a1.y, a2.y) || y < min(a1.y, a2.y) || y > max(b1.y, b2.y) || y < min(b1.y, b2.y)) return false;
    return true;
}

