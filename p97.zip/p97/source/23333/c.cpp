#include<cstring>
#include<fstream>
#define INF 0x3f
using namespace std;
ifstream cin("c.in");
ofstream cout("c.out");

struct Block {char up, down, left, right; int move;};
Block map[3][3];

int main(){
    cin >> map[0][0].up >> map[0][0].down >> map[0][0].left >> map[0][0].right >> map[0][0].move;
    cin >> map[0][1].up >> map[0][1].down >> map[0][1].left >> map[0][1].right >> map[0][1].move;
    cin >> map[0][2].up >> map[0][2].down >> map[0][2].left >> map[0][2].right >> map[0][2].move;
    cin >> map[1][0].up >> map[1][0].down >> map[1][0].left >> map[1][0].right >> map[1][0].move;
    cin >> map[1][1].up >> map[1][1].down >> map[1][1].left >> map[1][1].right >> map[1][1].move;
    cin >> map[1][2].up >> map[1][2].down >> map[1][2].left >> map[1][2].right >> map[1][2].move;
    cin >> map[2][0].up >> map[2][0].down >> map[2][0].left >> map[2][0].right >> map[2][0].move;
    cin >> map[2][1].up >> map[2][1].down >> map[2][1].left >> map[2][1].right >> map[2][1].move;
    cin >> map[2][2].up >> map[2][2].down >> map[2][2].left >> map[2][2].right >> map[2][2].move;
    cout << 5;
	return 0;
}
