#include<cstdio>
#include<iostream>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
char a[1100];
int b[1100][150];
int maxn[1100],minn[1100];
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	memset(b,0,sizeof(b));
	memset(maxn,0,sizeof(maxn));
	memset(minn,0x7f,sizeof(minn));
	int n;
	int ans=0;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		b[i][a[i]]=b[i-1][a[i]]+1;
		for(int j=97;j<=122;j++)
		{
			if(j!=a[i])	b[i][j]=b[i-1][j];
			if(maxn[i]<b[i][j])
			{
				maxn[i]=b[i][j];
			}
			if(minn[i]>b[i][j]&&b[i][j]!=0)
			{
				minn[i]=b[i][j];
			}
		}
	} 
	for(int i=1;i<=n;i++)
	{
		for(int j=i;j<=n;j++)
		{
			if(ans<maxn[j]-maxn[i]-minn[j]+minn[i])
			{
				ans=maxn[j]-maxn[i]-minn[j]+minn[i];
			}
		}
	}
	cout<<ans;
	return 0;
	fclose(stdin);
	fclose(stdout);
}
