#include <fstream>
#include <algorithm>
using namespace std;
ifstream cin("a.in");
ofstream cout("a.out");
int g[28][1009];
int main()
{
	int n,i=0,j,k;
	char x,a[1009];
	cin>>n;
	cin>>a;
	while(a[i]!='\0')
	{
		g[(int)a[i]-96][i]=g[(int)a[i]-96][i-1]+1;
		for(j=1;j<=26;j++)
		{
			if(j!=(int)a[i]-96)
			   g[j][i]=g[j][i-1];
		}
		i++;
	}
	int maxa=0,mina=100009,ans=0;
	for(i=0;i<n;i++)
	{
		for(j=0;j<=i;j++)
		{
			maxa=0;mina=100009;
			for(k=1;k<=26;k++)
			{
				if(g[k][i]-g[k][j-1]>maxa)
				   maxa=g[k][i]-g[k][j-1];
				if(g[k][i]-g[k][j-1]<mina&&g[k][i]-g[k][j-1]>0)
				   mina=g[k][i]-g[k][j-1];
			}
			ans=max(ans,maxa-mina);
		}
	}
	cout<<ans<<endl;
	return 0;
}
