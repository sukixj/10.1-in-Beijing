#include<iostream>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<cstdio>
using namespace std;
int b[1000010];
int ff(int head,int tail)
{
	int maxn=-1,minn=1000010,i,a[27]={0};
	for(i=head;i<tail;i++)
	{
		int tmp=b[i];
		a[tmp]++;
		if(a[tmp]>maxn) maxn=a[tmp];
    }
    for(i=0;i<27;i++) if(a[i]!=0 && a[i]<minn) minn=a[i];
	return maxn-minn;
}
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	int maxn=0,n,i,j;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		char c;
		cin>>c;
		b[i]=c-97;
	}
	for(i=0;i<n-1;i++)
	{
		for(j=i+2;j<=n;j++)
		{
			int tmp=ff(i,j);
			if(tmp>maxn) maxn=tmp;
		}
	}
	cout<<maxn;
	fclose(stdout);
	return 0;
}
