#include<iostream>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<cstdio>
using namespace std;
int x1,y3,x2,y2,w1,w2,w3,w4,m1,m2,m3,m4;
double l1,l2,l3,b1,b2,b3;
bool plan1()
{
	double k1,k2;
	k1=(b2-b1)/1.0/(l1-l2);
	k2=k1*l1+b1;
	if((k1<min(w1,w2) || k1>max(w1,w2) || k2<min(m1,m2) || k2>max(m1,m2)) && ((k1<min(w1,w2) || k1>max(w1,w2)) && (k2<min(m1,m2) || k2>max(m1,m2)))) 
	{
		cout<<"YES";
		return true;
	}
	return false;
}
void plan2()
{
	
}
int main()
{
	//freopen("b.in","r",stdin);
//freopen("b.out","w",stdout);
    scanf("%d%d%d%d%d%d%d%d%d%d%d%d",&x1,&y3,&x2,&y2,&w1,&m1,&w2,&m2,&w3,&m3,&w4,&m4);
    l1=(y2-y3)/1.0/(x2-x1);
    b1=y2-l1*x2;
    l2=(m1-m2)/1.0/(w1-w2);
    l3=(m3-m4)/1.0/(w3-w4);
    b2=m2-l2*w2;
    b3=m4-l3*w4;
	if(plan1()) return 0;
	
	//fclose(stdout);
	return 0;
}

