#include<iostream>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<cstdio>
using namespace std;
int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
   for(int i=0;i<9;i++)
   {
   	int a,b,c,d,e;
   	cin>>a>>b>>c>>d>>e;
   }
   cout<<5;
	fclose(stdout);
	return 0;
}

