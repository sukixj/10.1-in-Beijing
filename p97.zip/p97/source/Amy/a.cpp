#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
#define ll long long 
#define inf 214747364
using namespace std;
int n,t[30],ans,MAX,MIN;
string s;
int C(char c){return int(c)-96;}
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
//�����ǲ����ˣ���֪��������û�з� 
	scanf("%d",&n);
	cin>>s;
	for(int i=n-1;i>=0;i--)
	{
	  memset(t,0,sizeof(t));
	  for(int j=i;j<=n-1;j++)
	  {
		char a;a=s[j];	
		t[C(a)]++;
		MIN=inf,MAX=0;
		//cout<<i<<" "<<j<<" *** "<<endl;
		for(int k=1;k<=26;k++)
		{
		 if(t[k]==0) continue;
		// cout<<"&& "<<k<<" "<<t[k]<<endl;
		 MAX=max(MAX,t[k]);
		 MIN=min(MIN,t[k]);	
		}
		//cout<<MAX<<" "<<MIN<<endl;
		ans=max(ans,MAX-MIN);
	   }	
	} 
	printf("%d",ans);
	return 0;
}/*
���������롿
10
aabbaaabab
�����������
3
*/
