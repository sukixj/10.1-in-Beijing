#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
string a[100];
int map[10][10];
int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout); 
	for(int i=1;i<=9;i++) cin>>a[i];
	cout<<1;
	return 0;
} 
