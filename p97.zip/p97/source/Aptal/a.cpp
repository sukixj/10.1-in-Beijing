#include <algorithm>
#include <cstdio>

#define max(a,b) (a>b?a:b)
#define min(a,b) (a<b?a:b)
inline void read(int &x)
{
	x=0; register char ch=getchar();
	for(; ch>'9'||ch<'0'; ) ch=getchar();
	for(; ch>='0'&&ch<='9'; ch=getchar()) x=x*10+ch-'0';
}
const int N(1e6+5);
int cnt[28][N];
char s[N];
int n,ans;

int Presist()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	read(n);
	scanf("%s",s+1);
	for(int i=0; i<27; ++i)
	  for(int j=1; j<=n; ++j)
	  {
		if((s[j]-'a')!=i) cnt[i][j]+=cnt[i][j-1];
		else cnt[i][j]+=cnt[i][j-1]+1;
	  }
	int maxx,minn;
	for(int i=0; i<=n; ++i)
	{
		for(int j=i+1; j<=n; ++j)
		{
			maxx=0,minn=0x3f3f3f3f;
			for(int k=0; k<27; ++k)
			{
				if(cnt[k][j]-cnt[k][i])
				minn=min(minn,cnt[k][j]-cnt[k][i]);
				maxx=max(maxx,cnt[k][j]-cnt[k][i]);
			}
			ans=max(ans,maxx-minn);
		}
	}
	printf("%d\n",ans);
	return 0;
}

int Aptal=Presist();
int main(int argc,char*argv[]){;}
