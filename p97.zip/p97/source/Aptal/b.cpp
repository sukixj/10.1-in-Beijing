#include <algorithm>
#include <cstdio>

#define max(a,b) (a>b?a:b)
#define min(a,b) (a<b?a:b)
const int N(1e6+5);
int ax,ay,bx,by,xw1,yw1,xm1,ym1,xw2,yw2,xm2,ym2;

int Presist()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%d%d%d%d",&ax,&ay,&bx,&by);
	scanf("%d%d%d%d",&xw1,&yw1,&xw2,&yw2);
	scanf("%d%d%d%d",&xm1,&ym1,&xm2,&ym2);
	puts("NO");
	return 0;
}

int Aptal=Presist();
int main(int argc,char*argv[]){;}
