#include <cstdlib>
#include <cstdio>
#include <ctime>

int Presist()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	srand(time(0));
	printf("%d\n", rand() % 20010626 );
	return 0;
}

int Aptal=Presist();
int main(int argc,char*argv[]){;}
