#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <string>

using namespace std;

inline int read() {
	int x = 0 , f = 1; char ch = getchar();
	for ( ; !isdigit(ch) ; ch = getchar()) if (ch == '-') f = -1;
	for ( ; isdigit(ch) ; ch = getchar()) x = x * 10 + ch - '0';
	return x * f;
}

inline void write(int x) {
	if (!x) { putchar('0'); return; }
	if (x < 0) { x = -x ; putchar('-'); }
	int len = 0 , buf[20] = { 0 };
	while (x > 0) { buf[++len] = x % 10; x /= 10; }
	for (int i = len ; i >= 1 ; i --) putchar(buf[i] + '0');
}

#define writespace(x) write((x)),putchar(' ')
#define writeln(x) write((x)),puts("");
#define endline puts("")

const int maxLen = 1e6 + 1;

const int maxAlphabet = 27;

int qzh[maxLen][maxAlphabet];

char a[maxLen];

int len , ans;

int main() {
	freopen("a.in" , "r" , stdin);
	freopen("a.out" , "w" , stdout);
	
	len = read();
	scanf("%s" , &a);
	
	qzh[0][a[0] - 'a'] ++;
	
	for (int i = 1 ; i < len ; i ++) {
		for (int j = 0 ; j < 26 ; j ++) {
			qzh[i][j] = qzh[i - 1][j];
		}
		
		qzh[i][a[i] - 'a'] ++;
	}
	
	for (int i = 0 ; i < len ; i ++) {
		for (int j = i + 1 ; j < len ; j ++) {
			int maxx = 0 , minn = 2147483647;
			for (int k = 0 ; k < 26 ; k ++) {
				maxx = max(maxx , qzh[j][k] - qzh[i][k]);
				if (qzh[j][k] - qzh[i][k]) {
					minn = min(minn , qzh[j][k] - qzh[i][k]);
				}
			}
			
			//cout << maxx << " " << minn << endl;
			ans = max(ans , maxx - minn);
		}
	}
	
	writeln(ans);
}
/*
test data:
10
aabbaaabab
*/
