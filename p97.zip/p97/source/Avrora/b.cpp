#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <string>

using namespace std;

typedef long double ld;

const ld eps = 1e-10;

inline int read() {
	int x = 0 , f = 1; char ch = getchar();
	for ( ; !isdigit(ch) ; ch = getchar()) if (ch == '-') f = -1;
	for ( ; isdigit(ch) ; ch = getchar()) x = x * 10 + ch - '0';
	return x * f;
}

inline void write(int x) {
	if (!x) { putchar('0'); return; }
	if (x < 0) { x = -x ; putchar('-'); }
	int len = 0 , buf[20] = { 0 };
	while (x > 0) { buf[++len] = x % 10; x /= 10; }
	for (int i = len ; i >= 1 ; i --) putchar(buf[i] + '0');
}

#define writespace(x) write((x)),putchar(' ')
#define writeln(x) write((x)),puts("");
#define endline puts("")

int xv , yv , xp , yp , xw1 , yw1 , xw2 , yw2 , xm1 , ym1 , xm2 , ym2;

struct linear_function {
	ld k , b;
	
	inline void make_linear_function(int x1 , int y1 , int x2 , int y2) {
		this->k = (ld) ((ld)(y1 - y2) / (ld)(x1 - x2));
		this->b = (ld) ((ld)y1 - (ld)(x1 * y1 - x1 * y2) / (ld)(x1 - x2));
		
		return ;
	}
}_peo , _wall , _mirror , _line , fun;

struct node {
	ld x , y;
}_begin , _end;

ld get_intersection(linear_function _l1 , linear_function _l2) {
	if (_l1.k == _l2.k) {
		return 1e15;
	}
	
	return (_l2.b - _l1.b) / (_l1.k - _l2.k);
}

node get_perpendicular(linear_function l , node _node) {
	fun.k =  -1.0 / l.k;
	fun.b = _node.y + _node.x / l.k;
	//cout << fun.k << " " << fun.b << endl;
	
	ld intersection = get_intersection(l , fun);
	ld distance = abs(intersection - _node.x);
	
	//cout << distance << endl;
	
	node ren;
	ren.x = intersection - distance;
	ren.y = fun.k * ren.x + fun.b;
	
	return ren;
}

int main() {
	freopen("b.in" , "r" , stdin);
	freopen("b.out" , "w" , stdout);
	
	xv = read() , yv = read();
	xp = read() , yp = read();
	xw1 = read() , yw1 = read() , xw2 = read() , yw2 = read();
	xm1 = read() , ym1 = read() , xm2 = read() , ym2 = read();
	
	_begin.x = xv , _begin.y = yv;
	_end.x = xp , _end.y = yp;
	
	_peo.make_linear_function(xv , yv , xp , yp);
	_wall.make_linear_function(xw1 , yw1 , xw2 , yw2);
	_mirror.make_linear_function(xm1 , ym1 , xm2 , ym2);
	//cout << _mirror.k << " " << _mirror.b << endl;
	
	ld Intersection_of_peo_and_wall = get_intersection(_peo , _wall);
	ld Intersection_of_peo_and_mirror = get_intersection(_peo , _mirror);
	
	//cout << Intersection_of_peo_and_wall << endl;
	//cout << Intersection_of_peo_and_mirror << endl;
	
	if (Intersection_of_peo_and_wall <= min(xw1 , xw2) && Intersection_of_peo_and_wall >= max(xw1 , xw2)) {
		puts("YES");
		exit(0);
	}
	if (Intersection_of_peo_and_mirror >= min(xm1 , xm2) && Intersection_of_peo_and_mirror <= max(xm1 , xm2)) {
		puts("NO");
		exit(0);
	}
	
	//now wall and peo's intersection is on the wall
	//also mirror and peo's intersection is on the mirror
	
	node perpendicular = get_perpendicular(_mirror , _end);
	_line.make_linear_function(perpendicular.x , perpendicular.y , _begin.x , _begin.y);
	if (_line.k == ) {
		puts("YES");
		exit(0);
	}
	
	ld fuck = get_intersection(_line , fun);
	if (fuck >= min(xm1 , xm2) && fuck <= max(xm1 , xm2)) {
		puts("YES");
	}
	else {
		puts("NO");
	}
}

/*
-1 3
1 3 
0 2 0 4
0 0 0 1

0 0
1 1 
0 1 1 0
-100 -100 -101 -101

0 0 
1 1 
0 1 1 0
-1 1 1 3

0 0 
10 0
100 100 101 101
1 0 3 0 
*/
