#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <string>

using namespace std;

inline int read() {
	int x = 0 , f = 1; char ch = getchar();
	for ( ; !isdigit(ch) ; ch = getchar()) if (ch == '-') f = -1;
	for ( ; isdigit(ch) ; ch = getchar()) x = x * 10 + ch - '0';
	return x * f;
}

inline void write(int x) {
	if (!x) { putchar('0'); return; }
	if (x < 0) { x = -x ; putchar('-'); }
	int len = 0 , buf[20] = { 0 };
	while (x > 0) { buf[++len] = x % 10; x /= 10; }
	for (int i = len ; i >= 1 ; i --) putchar(buf[i] + '0');
}

#define writespace(x) write((x)),putchar(' ')
#define writeln(x) write((x)),puts("");
#define endline puts("")

int main() {
	freopen("c.in" , "r" , stdin);
	freopen("c.out" , "w" , stdout);
	
	puts("0");
}
