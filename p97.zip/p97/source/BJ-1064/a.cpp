#include <iostream>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
using namespace std;
char s[101010];
int a[101010][30];
int main()
{
    
    freopen("a.in","r",stdin);
    freopen("a.out","w",stdout);
    
    int n;
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        cin>>s[i];
        a[i][s[i]-'a'+1]=a[i-1][s[i]-'a'+1]+1;
        for(int j=1;j<=26;j++)
            if(j==s[i]-'a'+1) continue;
            else
            {
                if(i==n && a[i-1][j]==0/**/) a[i][j]=-1;
                else a[i][j]=a[i-1][j];
            }
    }
    int maxn=0,minn=9999999;
    int ans=0;
    for(int i=1;i<=n;i++)
    {
        for(int j=0;j<i;j++)
        {
            maxn=0;minn=9999999;/**/
            for(int k=1;k<=26;k++)
            {
                if(a[n][k]==-1) continue;
                maxn=max(maxn,a[i][k]-a[j][k]);
                if(a[i][k]-a[j][k]==0) continue;/**/
                minn=min(minn,a[i][k]-a[j][k]);
                ans=max(ans,maxn-minn);
            }
        }
    }
    printf("%d",ans);
    return 0;
}
