#include <iostream>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
using namespace std;
int Hx,Hy,Yx,Yy;
int stx,edx,sty,edy;
int w[2][2],m[2][2];
double f(int x)
{
    return ((edy-sty)/(edx-stx))*x+((edx*sty)-(sty*edy))/(edx-stx);
}
double g(int x)
{ 
    return ((w[2][2]-w[1][2])/(w[2][1]-w[1][1]))*x+((w[2][1]*w[1][2])-(w[1][2]*w[2][2]))/(w[2][1]-w[1][1]);
}
int main()
{
    
    freopen("b.in","r",stdin);
    freopen("b.out","w",stdout);
    
    scanf("%d%d%d%d",&Hx,&Hy,&Yx,&Yy);
    for(int i=1;i<=2;i++) scanf("%d%d",&w[i][1],&w[i][2]);
    for(int i=1;i<=2;i++) scanf("%d%d",&m[i][1],&m[i][2]);
    if(Hx<=Yx) {stx=Hx;edx=Yx;sty=Hy;edy=Yy;}
    else {stx=Yx;edx=Hx;sty=Yy;edy=Hy;}
    bool ok=true;
    if(w[1][1]==w[2][1])
    {
        if(sty>=w[1][2] && edy<=w[2][2]) ok=false;
        else if(sty<=w[1][2] && edy>=w[2][2]) ok=false;
    }
    else
    {
        for(int x=stx;x<=edx;x++)
        {
            if(x<w[1][1] || x>w[2][1]) continue;
            if(f(x)==g(x)) {ok=false;break;}
        }
    }
    if(ok) printf("YES");
    else printf("NO");
    return 0;
}
