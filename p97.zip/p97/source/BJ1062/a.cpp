#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("a.in", "r", stdin);
    freopen("a.out", "w", stdout);
    int n,l,num=0,sum[26];
    cin>>n;
    char a,b,x[n];
    int y[n],tot=1,line=1;
	cin>>a;
    for(int i=1;i<n;i++)
    {
    	cin>>b;
    	if(a==b)
    	tot++;
    	else
    	{
    		x[line]=a;
    		y[line++]=tot;
    		tot=1;
		}
		a=b;
	}
    for(int i=1;i<line;i++)
    {
    	for(int j=i;j<line;j++)
    	{
    		memset(sum,0,sizeof(sum));
    		for(int k=i;k<=j;k++)
    			sum[x[k]-'a']+=y[k];
			sort(sum,sum+26);
			l=0;
			while(!sum[l])
				l++;
    		num=max(num,sum[25]-sum[l]);
		}
	}
	cout<<num;
}
