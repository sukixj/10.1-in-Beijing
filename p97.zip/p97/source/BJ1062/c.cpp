#include<bits/stdc++.h>
using namespace std;
char a[3][3][4];
int b[3][3];
void bfs(int x)
{
	
}
int panduan()
{
	for(int i=0;i<3;i++)
    	for(int j=0;j<3;j++)
    	{
    		if(i-1>=0&&a[i-1][j][1]!=a[i][j][0])
    		return 0;
    		if(j-1>=0&&a[i][j-1][3]!=a[i][j][2])
    		return 0;
		}
}
int change(char m,int n,char d)//�ݺᣬ���У����� 
{
	if(m=='x')
	{
		for(int i=0;i<3;i++)
			if(b[i][n-1])
				return 0;
		swap(a[0][n-1],a[1][n-1]);
		if(d=='l')
		swap(a[1][n-1],a[2][n-1]);
		else
		swap(a[0][n-1],a[2][n-1]);
	}
	else
	{
		for(int i=0;i<3;i++)
			if(b[n-1][i])
				return 0;
		swap(a[n-1][0],a[n-1][1]);
		if(d=='u')
		swap(a[n-1][1],a[n-1][2]);
		else
		swap(a[n-1][0],a[n-1][2]);
	}
}
int main()
{
	//freopen("a.in", "r", stdin);
    //freopen("a.out", "w", stdout);
    for(int i=0;i<3;i++)
    	for(int j=0;j<3;j++)
    	{
    		for(int k=0;k<4;k++)
    			cin>>a[i][j][k];
			cin>>b[i][j];
		}
	for(int i=0;i<3;i++)
    	for(int j=0;j<3;j++)
    	{
    		
		}
}
