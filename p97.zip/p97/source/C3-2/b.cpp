#include <fstream>
#include <cstdlib>
#include <cstring>
using namespace std;
ifstream cin("b.in");
ofstream cout("b.out");

struct line_t
{
    bool perpendicular;
    double rate, offset;
    line_t()
    {
        perpendicular = false;
        rate = offset = 0;
    }
    line_t(bool _perp, double _rate, double _offset)
    {
        perpendicular = _perp;
        rate = _rate;
        offset = _offset;
    }
    bool operator==(const line_t &rhs) const
    {
        return perpendicular == rhs.perpendicular && rate == rhs.rate && offset == rhs.offset;
    }
};

double x1, y1, x2, y2;
double wall_x1, wall_y1, wall_x2, wall_y2;
double mirr_x1, mirr_y1, mirr_x2, mirr_y2;
line_t wall, mirror;
line_t direct;

line_t determine_a_line(double x1, double y1, double x2, double y2)
{
    // 1. Check if this is a perpendicular line
    if(x1 == x2)
        return line_t(true, 0, x1);

    // 2. Calculate the two components that describes the line
    const double rate = (y2 - y1) / (x2 - x1);
    const double offset = y1 - x1 * rate;
    return line_t(false, rate, offset);
}

bool coll_test(line_t l1, line_t l2, double l1_x1, double l1_y1, double l1_x2, double l1_y2, double l2_x1, double l2_y1, double l2_x2, double l2_y2)
{
    if(l1 == l2)
    {
        if(!l1.perpendicular)
        {
            if(l1_x1 > l2_x1)
            {
                swap(l1_x1, l2_x1);
                swap(l1_y1, l2_y1);
                swap(l1_x2, l2_x2);
                swap(l1_y2, l2_y2);
            }
            if(l1_x2 >= l2_x1)
                return true;
            else
                return false;
        }
        else
        {
            if(l1_y1 > l2_y1)
            {
                swap(l1_x1, l2_x1);
                swap(l1_y1, l2_y1);
                swap(l1_x2, l2_x2);
                swap(l1_y2, l2_y2);
            }
            if(l1_y2 >= l2_y1)
                return true;
            else
                return false;
        }
    }
    if(l1.perpendicular == true && l2.perpendicular == true)
        return false;
    if(l2.perpendicular == true)
    {
        swap(l1_x1, l2_x1);
        swap(l1_y1, l2_y1);
        swap(l1_x2, l2_x2);
        swap(l1_y2, l2_y2);
        swap(l1, l2);
    }
    if(l1.perpendicular)
    {
        // l1 -| x-axis and l2 is not
        // intersection point is (l1.offset, l1.offset * l2.rate + l2.offset)
        const double x = l1.offset;
        const double y = x *l2.rate + l2.offset;
        if(y < l1_y1 || y > l1_y2)
            return false;
        if(x < l2_x1 || x > l2_x2)
            return false;
        return true;
    }
    if(l1.rate == l2.rate)
        return false;

    // general case
    // k1x+b1=k2x+b2
    // (k1-k2)x = b2-b1
    const double x = (l2.offset - l1.offset) / (l1.rate - l2.rate);
    const double y = x * l1.rate + l1.offset;
    if(x < l1_x1 || x > l1_x2 || x < l2_x1 || x > l2_x2)
        return false;
    return true;
}

bool mirror_penetration_test()
{
    const double old_mirr_x1 = mirr_x1, old_mirr_y1 = mirr_y1;
    const double old_mirr_x2 = mirr_x2, old_mirr_y2 = mirr_y2;
    if(mirror.perpendicular)
    {
        mirr_y2 = 10000.0;
        mirr_y1 = -10000.0;
    }
    else
    {
        mirr_x1 = -10000.0;
        mirr_y1 = mirr_x1 * mirror.rate + mirror.offset;
        mirr_x2 = 10000.0;
        mirr_y2 = mirr_x2 * mirror.rate + mirror.offset;
    }
    bool result = coll_test(direct, mirror, x1, y1, x2, y2, mirr_x1, mirr_y1, mirr_x2, mirr_y2);
    mirr_x1 = old_mirr_x1; mirr_y1 = old_mirr_y1;
    mirr_x2 = old_mirr_x2; mirr_y2 = old_mirr_y2;
    return result;
}

pair<double, double> orthogonal_intersect(line_t line, double x, double y)
{
    line_t orthogonal;
    if(line.perpendicular)
        return make_pair(line.offset, y);
    else if(line.rate == 0)
        return make_pair(x, line.offset);

    orthogonal.perpendicular = false;
    orthogonal.rate = -1 / line.rate;
    orthogonal.offset = y - x * orthogonal.rate;
    // k1x+b1=k2x+b2
    // (k1-k2)x = b2-b1
    const double x0 = (orthogonal.offset - line.offset) / (line.rate - orthogonal.rate);
    const double y0 = x0 * line.rate + line.offset;
    return make_pair(x0, y0);
}

double fabs(double x)
{
    if(x < 0)
        return -x;
    else
        return x;
}

double sqrt(double v)
{
    double val = v;
    double last;
    do
    {
        last = val;
        val = (val + v / val) / 2;
    } while(fabs(val - last) > 1e-9);
    return val;
}


int main()
{
    cin >> x1 >> y1 >> x2 >> y2;
    if(x1 > x2)
    {
        swap(x1, x2);
        swap(y1, y2);
    }
    cin >> wall_x1 >> wall_y1 >> wall_x2 >> wall_y2;
    if(wall_x1 > wall_x2)
    {
        swap(wall_x1, wall_x2);
        swap(wall_y1, wall_y2);
    }
    cin >> mirr_x1 >> mirr_y1 >> mirr_x2 >> mirr_y2;
    if(mirr_x1 > mirr_x2)
    {
        swap(mirr_x1, mirr_x2);
        swap(mirr_y1, mirr_y2);
    }

    direct = determine_a_line(x1, y1, x2, y2);
    if(direct.perpendicular && y1 > y2)
    {
        swap(x1, x2);
        swap(y1, y2);
    }
    wall = determine_a_line(wall_x1, wall_y1, wall_x2, wall_y2);
    if(wall.perpendicular && wall_y1 > wall_y2)
    {
        swap(wall_x1, wall_x2);
        swap(wall_y1, wall_y2);
    }
    mirror = determine_a_line(mirr_x1, mirr_y1, mirr_x2, mirr_y2);
    if(mirror.perpendicular && mirr_y1 > mirr_y2)
    {
        swap(mirr_x1, mirr_x2);
        swap(mirr_y1, mirr_y2);
    }

    if(direct == mirror)
    {
        if(coll_test(direct, wall, x1, y1, x2, y2, wall_x1, wall_y1, wall_x2, wall_y2))
        {
            cout << "NO" << endl;
            return 0;
        }
        else
        {
            cout << "YES" << endl;
            return 0;
        }
    }
    else
    {
        if(mirror_penetration_test())
        {
            cout << "NO" << endl;
            return 0;
        }
        else
        {
            if(coll_test(direct, wall, x1, y1, x2, y2, wall_x1, wall_y1, wall_x2, wall_y2))
            {
                double itX1_x, itX1_y, itX2_x, itX2_y;
                pair<double, double> receiver;
                receiver = orthogonal_intersect(mirror, x1, y1);
                itX1_x = receiver.first;
                itX1_y = receiver.second;
                receiver = orthogonal_intersect(mirror, x2, y2);
                itX2_x = receiver.first;
                itX2_y = receiver.second;
                double dist1, dist2;
                dist1 = sqrt((x1-itX1_x)*(x1-itX1_x) + (y1-itX1_y)*(y1-itX1_y));
                dist2 = sqrt((x2-itX2_x)*(x2-itX2_x) + (y2-itX2_y)*(y2-itX2_y));
                if(itX1_x == itX2_x)
                {
                    if(itX1_y > itX2_y)
                    {
                        swap(itX1_x, itX2_x);
                        swap(itX1_y, itX2_y);
                        swap(dist1, dist2);
                    }
                    const double mid_y = itX1_y + (dist1/(dist1+dist2));
                    if(mid_y < mirr_y1 || mid_y > mirr_y2)
                    {
                        cout << "NO" << endl;
                        return 0;
                    }
                    else
                    {
                        cout << "YES" << endl;
                        return 0;
                    }
                }
                if(itX1_x > itX2_x)
                {
                    swap(itX1_x, itX2_x);
                    swap(itX1_y, itX2_y);
                    swap(dist1, dist2);
                }
                const double mid_x = itX1_x + (dist1/(dist1+dist2));
                if(mid_x < mirr_x1 || mid_x > mirr_x2)
                {
                    cout << "NO" << endl;
                    return 0;
                }
                else
                {
                    cout << "YES" << endl;
                    return 0;
                }
            }
            else
            {
                cout << "YES" << endl;
                return 0;
            }
        }
    }
    return 0;
}
