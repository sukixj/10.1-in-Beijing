#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;
char c[100001];
int t,ou[100001][26],M,m,Ma,mi;

int main() {
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	int n,ans=0;
	scanf("%d",&n);
	scanf("%s",&c);
	for(int i=1; i<=n; ++i) {
		for(int k=1; k<=26; ++k)
			ou[i][k]=ou[i-1][k];
		++ou[i][c[i-1]-96];
		for(int j=1; j<=i; ++j) {
			mi=0x7fffffff;
			for(int k=1; k<=26; ++k) {
				if(Ma<ou[i][k]-ou[j-1][k]) Ma=ou[i][k]-ou[j-1][k],M=k;
				if(mi>ou[i][k]-ou[j-1][k]&&ou[i][k]-ou[j-1][k]) mi=ou[i][k]-ou[j-1][k],m=k;
			}
			ans=max(ans,(ou[i][M]-ou[j-1][M])-(ou[i][m]-ou[j-1][m]));
		}
	}
	printf("%d",ans);
	return 0;
}
