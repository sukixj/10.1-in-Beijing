#include<ctime>
#include<cstdio>
#include<cstdlib>
#include<iostream>
using namespace std;

int main() {
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	srand(time(0));
	int n=rand()%1000+1;
	if(n%2) printf("NO");
	else printf("YES");
	return 0;
}
