#include<ctime>
#include<cstdio>
#include<cstdlib>
#include<iostream>
using namespace std;

int main() {
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	srand(time(0));
	int n=rand()%17+1;
	printf("%d",&n);
	return 0;
}
