#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,a[1000005];
struct E{
	int sum[27];
}pre[1000005];
int ans;
int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	cin>>n;
	getchar();
	for(int i=1;i<=n;i++){
		a[i]=getchar()-'a'+1;
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=26;j++){
			pre[i].sum[j]=pre[i-1].sum[j];
		}
		pre[i].sum[a[i]]++;
	}
	int mmax,mmin;
	for(int i=n;i>=1;i--){
		for(int j=1;j<=i;j++){
			mmax=-1,mmin=10000000;
			for(int k=1;k<=26;k++){
				int q=pre[i].sum[k],p=pre[j-1].sum[k];
				mmax=max(mmax,q-p);
				if((q-p)!=0){
					mmin=min(mmin,q-p);
				}
			}
			ans=max(ans,mmax-mmin);
		}
	}
	cout<<ans;
}
