#include<cmath>
#include<queue>
#include<string>
#include<vector>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#define MAXN (10+1000)

using namespace std;
int n,ans,dp[MAXN][MAXN][31];
char str[MAXN]; 

int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
    scanf("%d",&n);
	getchar();
	for(int i=1;i<=n;i++)scanf("%c",&str[i]);
	for(int i=1;i<=n;i++){
        for(int j=i;j<=n;j++){
            dp[i][j][str[j]-'a']++;
            for(int k=0;k<26;k++)dp[i][j+1][k]=dp[i][j][k];
		}
	}
	
	for(int i=1;i<=n;i++){
	    for(int j=i;j<=n;j++){
	    	int m1=0,m2=999999999;
	        for(int k=0;k<26;k++){
	            m1=max(m1,dp[i][j][k]);
	            if(dp[i][j][k]!=0)m2=min(m2,dp[i][j][k]);
			}
            ans=max(ans,m1-m2);			
		}
	}
	printf("%d",ans);
	return 0;
}