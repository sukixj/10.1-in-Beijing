#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define MAXN 1000010
using namespace std;
char s[MAXN];
int cnt[30];

int main() {
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	int n;
	scanf("%d%s",&n,s+1);
	int Max,Min,ans=-MAXN;
	for(int i=3;i<=n;i++) {
		for(int l=1,r=l+i-1;l<=n&&r<=n;l++,r=l+i-1) {
			Max=-MAXN,Min=MAXN;
			for(int k=l;k<=r;k++)
				cnt[s[k]-'a'+1]++;
			for(int k=1;k<=26;k++)
				if(cnt[k]!=0) {
					Max=max(cnt[k],Max);
					Min=min(cnt[k],Min);
					cnt[k]=0;
				}
			ans=max(ans,Max-Min);
		}
	}
	printf("%d",ans);
	return 0;
}
