#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cmath>

using namespace std;
struct Point {
	double x,y;
} a1,a2,b1,b2,c1,c2,aa1,aa2;
struct Line {
	double a,b,c;
};
double mult(Point a,Point b,Point c) {
	return (a.x-c.x)*(b.y-c.y)-(b.x-c.x)*(a.y-c.y);
}
bool judge(Point aa, Point bb, Point cc, Point dd) {
	if(max(aa.x,bb.x)<min(cc.x,dd.x)) return false;
	if(max(aa.y,bb.y)<min(cc.y,dd.y)) return false;
	if(max(cc.x,dd.x)<min(aa.x,bb.x)) return false;
	if(max(cc.y,dd.y)<min(aa.y,bb.y)) return false;
	if(mult(cc,bb,aa)*mult(bb,dd,aa)<0) return false;
	if(mult(aa,dd,cc)*mult(dd,bb,cc)<0) return false;
	return true;
}
Point jiaodian(Point u1,Point u2,Point v1,Point v2) {
	Point ret=u1;
	double t=((u1.x-v1.x)*(v1.y-v2.y)-(u1.y-v1.y)*(v1.x-v2.x))/((u1.x-u2.x)*(v1.y-v2.y)-(u1.y-u2.y)*(v1.x-v2.x));
	ret.x+=(u2.x-u1.x)*t;
	ret.y+=(u2.y-u1.y)*t;
	return ret;
}
Line PL(Point p1,Point p2) {
	Line tmp;
	tmp.a=p2.y-p1.y;
	tmp.b=p1.x-p2.x;
	tmp.c=p2.x*p1.y-p1.x*p2.y;
	return tmp;
}
Point duichen(Point p,Line L) {
	Point p2;
	double d;
	d=L.a*L.a+L.b*L.b;
	p2.x=(L.b*L.b*p.x-L.a*L.a*p.x-2*L.a*L.b*p.y-2*L.a*L.c)/d;
	p2.y=(L.a*L.a*p.y-L.b*L.b*p.y-2*L.a*L.b*p.x-2*L.b*L.c)/d;
	return p2;
}

int main() {
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	cin>>a1.x>>a1.y>>a2.x>>a2.y>>b1.x>>b1.y>>b2.x>>b2.y>>c1.x>>c1.y>>c2.x>>c2.y;
	Point i,j;
	i=duichen(a1,PL(c1,c2));
	if(judge(a1,a2,b1,b2) && judge(a1,a2,c1,c2)) {
		if(!judge(i,a2,c1,c2)) {
			cout<<"NO";
			return 0;
		}
		else {
			if(judge(jiaodian(i,a2,c1,c2),a2,b1,b2)) {
				cout<<"NO";
				return 0;
			}
		}
	}
	cout<<"YES";
	return 0;
}
