#include <iostream>
#include <ctime>
#include <cstdio>
#include <algorithm>
using namespace std;

int main() {
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	srand(time(NULL)+20020207);
	cout<<(rand()%9+1)*(rand()%9+1)/(rand()%9+1);
	return 0;
}
