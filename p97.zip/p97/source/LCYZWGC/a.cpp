#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
int n,num[30],fmx=-2147483647,fin=2147483647,ans=-2147483647;
string a;
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	cin>>n;
	if(n==1)
	{
		cout<<"0"<<endl;
		return 0;
	}
	cin>>a;
	for(int k=2;k<=n;k++)//�ִ����� 
	{
		for(int i=0;i<n;i++)//ö��λ�� 
		{
			memset(num,0,sizeof(num));
			fmx=-2147483647;fin=2147483647;
			if(i+k-1>n-1) continue;
			for(int j=i;j<i+k;j++)//���бȽ� 
			{
				int p=a[j]-96;
				num[p]++; 
			}
			for(int j=1;j<=26;j++)
			{
				if(!num[j]) continue;
				fmx=max(fmx,num[j]);fin=min(fin,num[j]);
			}
			ans=max(ans,fmx-fin);
		}
	}
	cout<<ans<<endl;
	return 0;
}
