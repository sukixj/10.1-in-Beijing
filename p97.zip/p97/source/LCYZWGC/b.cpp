#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
using namespace std;
double xv,yv,xp,yp,xw1,yw1,xw2,yw2,xm1,ym1,xm2,ym2,k1,k2,k3,b1,b2,b3;
double x,y,k4,b4;
bool pd,pd1,pd2,pd3;
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	cin>>xv>>yv>>xp>>yp>>xw1>>yw1>>xw2>>yw2>>xm1>>ym1>>xm2>>ym2;
	if(xv!=xp)
	{
		k1=(yp-yv)/(xp-xv);//�˵�б��
		b1=(xv*yp-xp*yv)/(xp-xv);//�˵Ľؾ�
		b1=0-b1;
		pd1=true;
	}
	if(xw2!=xw1)
	{
	    k2=(yw2-yw1)/(xw2-xw1);//ǽ��б��
		b2=(xw1*yw2-xw2*yw1)/(xw2-xw1);//ǽ�Ľؾ�
		b2=0-b2;
		pd2=true;
	}
	if(xm2!=xm1)
    {
    	k3=(ym2-ym1)/(xm2-xm1);//���ӵ�б��
		b3=(xm1*ym2-xm2*ym1)/(xm2-xm1);//���ӵĽؾ�
		b3=0-b3;
		pd3=true;
	}
	if(pd1&&pd2)
    {
    	x=(b1-b2)/(k2-k1);
	}
	else if(pd1&&!pd2)
	{
		x=xw1;
	}
	else
	{
		x=xv;
	}
	if(x>=min(xv,xp)&&x<=max(xv,xp)&&x>=min(xw1,xw2)&&x<=max(xw1,xw2))
	{
		pd=true;//���˼���ǽ��� 
	}
	if(!pd)
	{
		cout<<"YES"<<endl;
		return 0;
	} 
	pd=false;
    k4=(-1/k3);//�д��ߴ�ֱ���ߵ�б�� 
    b4=(-1*k4)*xv+yv;//�д��ߴ�ֱ���ߵĽؾ�
    x=(b4-b3)/(k3-k4);
    x=2*x-xv;y=k4*x+b4;
	k4=(y-yp)/(x-xp);
	b4=(x*yp-xp*y)/(xp-x);
	b4=0-b4;
	x=(b4-b3)/(k3-k4);
	if(x>=min(xm1,xm2)&&x<=max(xm1,xm2))
	{
		pd=true;
	}
	if(pd)
	{
		cout<<"YES"<<endl;
		return 0;
	}
	else
	{
		cout<<"NO"<<endl;
	} 
	return 0; 
}
