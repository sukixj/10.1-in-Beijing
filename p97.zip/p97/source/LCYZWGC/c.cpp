#include<iostream>
#include<cstdio>
#include<cstdlib>
using namespace std;
int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
    cout<<"8"<<endl;
	return 0;
}
