#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
using namespace std;

int  n;
char a[1000005];
int s[1000005];
int maxx;
int minn=0x7FFFFFFF;
int cnt;
int ans;

int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
	}
	while(cnt<n)
	{
		for(int i=0;i<cnt;i++)
		{
			s[a[i]]++;
		}
		for(int i=0;i<cnt;i++)
		{
			maxx=max(s[a[i]],maxx);
			minn=min(s[a[i]],minn);
			ans=max((maxx-minn),ans);
			//cout<<maxx<<" "<<minn<<" "<<ans<<endl;
		}
		maxx=0;
		minn=0x7FFFFFFF;
		for(int i=0;i<cnt;i++)
		{
			s[a[i]]=0;
		}
		cnt++;
	}
	cout<<ans<<endl;
	return 0;
}
