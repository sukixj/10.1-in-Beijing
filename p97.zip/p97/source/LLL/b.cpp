#include<iostream>
#include<cstdio>
using namespace std;

int xz,yz,xd,yd,xq1,yq1,xq2,yq2,xj1,yj1,xj2,yj2;

int main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	cin>>xz>>yz;//starts
	cin>>xd>>yd;//ends
	cin>>xq1>>yq1>>xq2>>yq2;
	cin>>xj1>>yj1>>xj2>>yj2;

	cout<<"NO"<<endl;
	return 0;
}
