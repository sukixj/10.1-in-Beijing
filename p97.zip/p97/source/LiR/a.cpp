#include <cstdio>
#include <iostream>
#include <cstring>
#include <string>
#include <climits>
#include <algorithm>
using namespace std;
int a[26][1003],ma[1003],mi[1003];
int dp[1003][1003];
bool flag[26];
int n,ans;
string s;
int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	memset(mi,0x3f3f3f,sizeof(mi));
	mi[0]=0,ma[0]=0;
	cin>>n;
	cin>>s;
	for(int i=0;i<n;++i){
		if(!flag[s[i]-'a']) flag[s[i]-'a']=1;
		for(int j=i+1;j<=n;++j)
			++a[s[i]-'a'][j];
		dp[i][i]=0;
		dp[i][i+1]=0;
	}
	for(int i=1;i<=n;++i){
		for(int t=0;t<26;++t){
			if(flag[t]&&a[t][i]!=0){
				ma[i]=max(ma[i],a[t][i]);
				mi[i]=min(mi[i],a[t][i]);
			}
		}
	}
	/*for(int i=1;i<=n;++i) cout<<ma[i]<<" ";
	cout<<endl;
	for(int i=1;i<=n;++i) cout<<mi[i]<<" ";
	cout<<endl;*/
	for(int i=1;i<n;++i){
		for(int k=3;k+i-1<=n;++k){
			int j=i+k-1;
			dp[i][j]=dp[i][j-1];
			for(int t=0;t<26;++t){
				if(flag[t]){
					dp[i][j]=max(dp[i][j],ma[j]-ma[i-1]-mi[j]+mi[i-1]);
				}
			}
			ans=max(ans,dp[i][j]);
		}
	}
	/*for(int i=1;i<=n;++i){
		for(int j=1;j<=n;++j){
			cout<<dp[i][j]<<" ";
		}
		cout<<endl;
	}*/
	cout<<ans<<endl;
	return 0;
}
