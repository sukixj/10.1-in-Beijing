#include<cstdio>
#include<cstring>
#include<algorithm>
const int maxn=1e6+10;
using namespace std;
char str[maxn];
int hash[26+10];//a to z => 0-25
int n,ans,max_pos,min_pos;
int main()
{
	#ifndef LOCAL
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	#endif
	scanf("%d",&n);
	scanf("%s",str);
	for(int i=0;i<n-1;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			memset(hash,-1,sizeof(hash));
			for(int k=i;k<=j;k++)
				hash[str[k]-'a']++;
			sort(hash,hash+26);
			for(int l=0;l<26;l++)
				if(hash[l]!=-1)
				{
					min_pos=l;
					break;
				}
				max_pos=min_pos;
			for(int l=min_pos+1;l<26;l++)
				if(hash[l]!=-1)
				{
					max_pos=l;
					break;
				}
			ans = ans > hash[max_pos]-hash[min_pos] ? ans : hash[max_pos]-hash[min_pos];
		}
	}
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
//author: Mingqi_H
//mark: ~30'
//worst case: n^3+n^2\log n
//2017 QBXT
