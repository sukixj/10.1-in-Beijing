 #include<ctime>
#include<cstdio>
#include<cstdlib>
using namespace std;
int x1,x2,x3,x4,y1,y2,y3,y4;
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	srand(time(NULL));
	scanf("%d%d%d%d%d%d%d%d",&x1,&y2,&x2,&y2,&x3,&y3,&x4,&y4);
	printf(rand()%2 ? "NO" : "YES");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
//Mingqi_H
