#include<cstdio>
using namespace std;
int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	printf("5");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
//Mingqi_H

