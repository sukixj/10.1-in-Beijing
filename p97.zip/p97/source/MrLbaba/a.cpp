#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
char a[1000001];
int b[1000001];
int c[27];
int main()
{
	int i,n,j,max=0,min=100000,ans=0,k,l;
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	cin>>n;
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
		b[i]=a[i]-97;
	}
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
		{
			max=0;
			min=100000;
			memset(c,0,sizeof(c));
			for(k=1;k<=j;k++)
			{
				c[b[k]+1]++;
			}
			for(l=1;l<=2;l++)
			{
				if(c[l]>max) max=c[l];
				else if((c[l]<min)&&(c[l]!=0)) min=c[l]; 
			}
			if(min==100000) min=0;
			if(max-min>ans) ans=max-min;
		}
	}
	cout<<ans;
	return 0;
}
