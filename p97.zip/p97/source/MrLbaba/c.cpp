#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	char a;
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	cin>>a;
	if(a=='G') cout<<5;
	if(a=='O') cout<<8;
	if(a=='R') cout<<11;
	if(a=='B') cout<<17;
	return 0;
}
