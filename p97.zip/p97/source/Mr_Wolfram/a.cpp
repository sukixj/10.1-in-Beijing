#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
char s[100005];
int n,tot;
int tong[200];
int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	//freopen("in.txt","r",stdin);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf(" %c ",&s[i]);
	}
	for(int i=1;i<=n;i++){
		memset(tong,0,sizeof(tong));
		for(int j=1;j<=n;j++){
			tong[s[j]]++;
			int mi=1000000,ma=0;
			for(int k='a';k<='z';k++){
				if(tong[k]&&tong[k]<mi) mi=tong[k];
				if(tong[k]>ma) ma=tong[k];
			}
			tot=max(tot,ma-mi);
		}
	}
	cout<<tot;
	fclose(stdin);
	fclose(stdout);
}
