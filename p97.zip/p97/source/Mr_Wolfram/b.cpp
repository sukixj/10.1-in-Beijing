#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;
bool chk(int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4){
	double a1=((double)y2-y1)/(x2-x1),a2=((double)y4-y3)/(x4-x3);
	double b1=y1-a1*x1,b2=y3-a2*x3;
	if(a1==a2){
		if(b1==b2) return 1;
		else return 0;
	}
	double jx=(b1-b2)/(a2-a1),jy=a1*jx+b1;
	if(jx>min(x1,x2)&&jx<max(x1,x2)) return 1;
	else return 0;
}
bool mchk(int x1,int y1,int x2,int y2,int x3,int y3,int x4,int y4){
	double a2=((double)y4-y3)/(x4-x3);
	double b2=y3-a2*x3;
	int t1=sqrt(1/(1+a2));
	int t2=a2*x1+b2;
	t2-=y1;
	t2/=t1;
	t2/=t1;
	y1+=2*t2;
	x1+=2*t2/a2;
	return chk(x1,y1,x2,y2,x3,y3,x4,y4);
}
int main(){
	//freopen("in.txt","r",stdin);
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	int x1,x2,y1,y2;
	int y1q,x1q,y1m,x1m,y2q,x2q,y2m,x2m;
	scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
	scanf("%d%d%d%d",&x1q,&y1q,&x2q,&y2q);
	scanf("%d%d%d%d",&x1m,&y1m,&x2m,&y2m);
	if(!chk(x1,y1,x2,y2,x1q,y1q,x2q,y2q)&&!chk(x1,y1,x2,y2,x1m,y1m,x2m,y2m)) cout<<"YES"<<endl;
	else if(chk(x1,y1,x2,y2,x1q,y1q,x2q,y2q)&&!chk(x1,y1,x2,y2,x1m,y1m,x2m,y2m)) {
		if(!mchk(x1,y1,x2,y2,x1q,y1q,x2q,y2q)&&mchk(x1,y1,x2,y2,x1m,y1m,x2m,y2m)) cout<<"YES"<<endl;
		else cout<<"NO"<<endl;
	}
	else if(!chk(x1,y1,x2,y2,x1q,y1q,x2q,y2q)&&chk(x1,y1,x2,y2,x1m,y1m,x2m,y2m)){
		if(!mchk(x1,y1,x2,y2,x1q,y1q,x2q,y2q)) cout<<"YES";
		else cout<<"NO";
	}
	else {
		cout<<"NO";
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
