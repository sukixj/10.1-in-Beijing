#include <iostream>
#include <cstdio>
using namespace std;
char n;
int main(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	while(scanf(" %c ",&n)!=EOF) ;
	cout<<11;
	return 0;
}
