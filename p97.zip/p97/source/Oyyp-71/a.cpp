#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#define LL long long
#define M 1000009
using namespace std;
int p[M],s[M][30],a[30],n,ans,last[26],m,x;
char h;
int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	getchar();
	for(int i=0;i<26;i++) last[i]=1;
	for(int i=1;i<=n;i++){
		p[i]=getchar()-'a';
		for(int j=0;j<26;j++) s[i][j]=s[i-1][j];
		s[i][p[i]]++;
	}
	for(int i=1;i<=n;i++){
		m=last[p[i]]-1;
		for(int j=0;j<26;j++){
			if(j==p[i]) continue;
			if(s[i][j]-s[m][j]==0) continue;
			ans=max(ans,s[i][p[i]]-s[m][p[i]]-(s[i][j]-s[m-1][j]));
		}
	    for(int j=0;j<26;j++){
	    	if(j==p[i]) continue;
	    	if(s[i][j]-s[m][j]>=s[i][p[i]]-s[m][p[i]]){
	    		last[p[i]]=i;
	    		break;
			}
		}
		for(int j=0;j<26;j++){
			if(j==p[i]) continue;
			m=last[j]-1;
			ans=max(ans,s[i][j]-s[m][j]-(s[i][p[i]]-s[m][p[i]]));
		}
	}
	printf("%d",ans);
	return 0;
}
