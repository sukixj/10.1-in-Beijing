#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#define LL long long
#define M
using namespace std;

struct pt{
	double x,y;
}a,b,ml,mr,wl,wr,tmp1,tmp2;
double k,t,k1,k2,k0,t1,t2,q1,q2;
void rs(int q){
	if(q==0) printf("NO");
	else printf("YES");
	exit(0);
}
double cj(pt p,pt p1,pt p2){
	int xx=p1.x-p2.x,yy=p1.y-p2.y;
	return (p.x-p2.x)*yy-xx*(p.y-p2.y);
}
bool cr(pt n1,pt n2,pt m1,pt m2){
	return cj(n1,m1,m2)*cj(n2,m1,m2)<0;
}
bool con(pt n1,pt n2,pt n3,pt n4){
	return cr(n1,n2,n3,n4)&&cr(n3,n4,n1,n2);
}
int main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
    scanf("%lf%lf%lf%lf",&a.x,&a.y,&b.x,&b.y);
    scanf("%lf%lf%lf%lf",&wl.x,&wl.y,&wr.x,&wr.y);
    scanf("%lf%lf%lf%lf",&ml.x,&ml.y,&mr.x,&mr.y);
    if(con(a,b,ml,mr)) rs(0);
	if((!con(a,b,ml,mr))&&(!con(a,b,wl,wr))) rs(1);
	if(con(a,ml,wl,wr)&&con(a,wr,wl,wr)) rs(0);
	if(ml.x==mr.x){
		tmp1.x=wl.x*2-a.x;
		tmp1.y=a.y;
		tmp2.x=wl.x*2-b.x;
		tmp2.y=b.y;
	}
	else{
		k=(mr.y-ml.y)/(mr.x-ml.x);
		t=mr.y-(mr.x*k);
		k0=-1.0/k;
		t1=a.y-(a.x*k0);
		t2=b.y-(b.x*k0);
		k1=(t1-t)/(k-k0);
		k2=(t2-t)/(k-k0);
		q1=k*k1+t;
		q2=k*k2+t;
		tmp1.x=2*k1-a.x;
		tmp2.x=2*k2-b.x;
		tmp1.y=2*q1-a.y;
		tmp2.y=2*q2-b.y;
	}
	if(con(tmp1,b,ml,mr)&&(!con(tmp1,b,wl,wr))&&con(a,tmp2,ml,mr)&&(!con(a,tmp2,wl,wr))) rs(1);
	rs(0);
	return 0;
}
