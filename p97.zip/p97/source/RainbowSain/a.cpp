#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,ans,k;
char s[1000010];
int num[27]={0},deal[27]={0};
int maxn=-1000,minn=1000000000;
int maxn1=-1000,minn1=1000000000;
int maxn_i,minn_i;
int maxn1_i,minn1_i;
int kill(int l,int r)
{
	memset(deal,0,sizeof(deal));
	 for(int i=l;i<=r;i++)
	 	deal[(int)(s[i]-'a')+1]++;
	maxn1=-1000,minn1=1000000000;
	for(int i=1;i<=26;i++)
	{
		if(deal[i])
		{
			if(deal[i]>maxn1)
		{
			maxn1=deal[i];
			maxn1_i=i;
		} 
		if(deal[i]<minn1) 
		{
			minn1=deal[i];
			minn1_i=i;
		}
		}
	}
	if(minn1_i==maxn1_i) k=0;
	else k=maxn1-minn1;
	return k;
}

int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	scanf("%c",&s[0]); 
	for(int i=1;i<=n;i++)
		scanf("%c",&s[i]);
	for(int i=1;i<=n;i++) 
		num[(int)(s[i]-'a')+1]++;
	for(int i=1;i<=26;i++)
	{
		if(num[i])
		{
			if(num[i]>maxn)
		{
			maxn=num[i];
			maxn_i=i;
		 } 
		if(num[i]<minn)
		{
			minn=num[i];
			minn_i=i;
		}  
		}
	}//Ԥ����
	if(minn_i==maxn_i) ans=0;
	else ans=maxn-minn;
	for(int i=n;i>=1;i--)
	{
		if((int)(s[i]-'a')+1==minn_i)
		ans++;
		else if((int)(s[n-i+1]-'a')+1==minn_i)
		ans++;
		else break;
	}
	
	for(int i=1;i<=n-1;i++)
		for(int j=i+1;j<=n;j++)
		 {
		 	int ass=kill(i,j);
		 	if(ans<ass) ans=ass;
		 }
	
	printf("%d",ans);
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}                
