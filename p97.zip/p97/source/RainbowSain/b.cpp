#include<cstdio>
using namespace std;
int read()
{
	char x=getchar();
	while(x>'9'||x<'0') x=getchar();
	int t=0;
	while(x<='9'&&x>='0')
	{
		t=t*10+x-'0';
		x=getchar();
	}
	return t;
}
int maps[20010][20010]={0};
int xv,yv,xp,yp;
int xw1,yw1,xw2,yw2;
int xm1,ym1,xm2,ym2;
int aabs(int x)
{
	if(x>=0) return x;
	else return (x+10000);
}
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	xv=read(),yv=read();
	xv=aabs(xv),yv=aabs(yv);
	maps[xv][yv]=1;
	xp=read(),yp=read();
	xp=aabs(xp),yp=aabs(yp);
	maps[xp][yp]=2;
	xw1=read(),yw1=read();
	xw1=aabs(xw1),yw1=aabs(yw1);
	xw2=read(),yw2=read();
	xw2=aabs(xw2),yw2=aabs(yw2);
	xm1=read(),ym1=read();
	xm1=aabs(xm1),ym1=aabs(ym1);
	xm2=read(),ym2=read();
	xm2=aabs(xm2),ym1=aabs(ym2);
	
	printf("NO");
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
