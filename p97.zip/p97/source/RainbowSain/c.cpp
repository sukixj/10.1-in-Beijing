#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<cmath>
#include<ctime>
using namespace std;
int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);   
	srand((unsigned)time(NULL));
        cout << rand()%30; 
	fclose(stdin);
	fclose(stdout);
	return 0;
}
