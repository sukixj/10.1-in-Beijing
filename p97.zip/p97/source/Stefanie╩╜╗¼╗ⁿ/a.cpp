#include<iostream>
#include<cstdio>
#include<iomanip>
#include<map>
#include<set>
#include<algorithm>
#include<ctime>
#include<cstring>
#include<string>
#include<queue>
#include<cctype>
#include<cmath>
#include<stack>
#include<vector>
#define N 100010
#define MOD 19360817
using namespace std;

int n,maxx=0;
int t[27];
char ch[N];
char c,mxpos,mnpos;

int main()
{	
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	
	std::ios::sync_with_stdio(false);
	std::cin.tie(0);
	
	memset(t,0,sizeof(t));
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>ch[i];
	for(int i=1;i<n;i++)
	{
		for(int k=1;k<=26;k++)
			t[k]=0;
		t[ch[i]-96]++;	
		mxpos=ch[i];mnpos=ch[i];
		for(int j=i+1;j<=n;j++)
		{
			t[ch[j]-96]++;
			if(t[ch[j]-96]>t[mxpos-96])	
				mxpos=ch[j];
			else if(t[mnpos-96]>t[ch[j]-96])
				mnpos=ch[j];
			maxx=max(t[mxpos-96]-t[mnpos-96],maxx);
		}
	}
	
	cout<<maxx<<"\n";	
	
	return 0;
}







