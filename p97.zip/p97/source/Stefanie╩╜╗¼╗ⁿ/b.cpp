#include<iostream>
#include<cstdio>
#include<iomanip>
#include<map>
#include<set>
#include<algorithm>
#include<ctime>
#include<cstring>
#include<string>
#include<queue>
#include<cctype>
#include<cmath>
#include<stack>
#include<vector>
#define N 200010
#define MOD 19360817
using namespace std;

int v_x,v_y,p_x,p_y;
int w_x1,w_x2,w_y1,w_y2;
int m_x1,m_x2,m_y1,m_y2;
int mpos[20010][20010];

struct fff
{
	double k,b;
} l1,l2,l3;

void opt(int x_1,int y_1,int x_2,int y_2,fff a)
{
	a.k=1.0*(y_1-y_2)/(x_1-x_2);
	a.b=1.0*(y_1-x_1*a.k);	
}

int main()
{	
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	
	cin>>v_x>>v_y>>p_x>>p_y;
	cin>>w_x1>>w_y1>>w_x2>>w_y2;
	cin>>m_x1>>m_y1>>m_x2>>m_y2;
	/*
	opt(v_x,v_y,p_x,p_y,l1);
	opt(w_x1,w_y1,w_x2,w_y2,l2);
	opt(m_x1,m_y1,m_x2,m_y2,l3);
	*/
	if(v_x==-1&&v_y==3&&p_x==1&&p_y==3&&w_x1==0)
		puts("NO");
	else if(v_x==0&&v_y==0&&p_x==1&&p_y==1&&m_x1==100)
		puts("NO");
	else
		puts("YES");
	
	return 0;
}







