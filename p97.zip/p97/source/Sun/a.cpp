#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;

int n,sss[150],ans;
char st[1010],ss[1010];

void strGetSubString(char* s) {
	char* p;
	char* q;
	int l;
	p=s;
	while(!(*p=='\0')) {
		q=p;
		l=0;
		while(!(*q=='\0')) {
			l++;
			q++;
		}
		q=p;
		int num=0;
		for(int i=0; i<l+1; i++) {
			for(int j=0; j<i; j++)
				ss[++num]=*(q+j);
			for(int k=1; k<=num; k++)
				sss[ss[k]]++;
			int maxn=0,minn=0x7fffffff;
			for(int l=97; l<=122; l++) {
				maxn=max(maxn,sss[l]);
				if(sss[l]!=0) minn=min(minn,sss[l]);
			}
			int dx=maxn-minn;
			if(dx>ans) ans=dx;
			num=0;
			memset(sss,0,sizeof(sss));
		}
		p++;
	}
}

int main() {
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	for(int i=0; i<n; i++)
		cin>>st[i];
	strGetSubString(st);
	printf("%d",ans);
	return 0;
}
