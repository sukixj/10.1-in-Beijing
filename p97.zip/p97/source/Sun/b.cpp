#include<cstdio>
#include<iostream>
using namespace std;

int main() {
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	printf("YES\n");
	return 0;
}
