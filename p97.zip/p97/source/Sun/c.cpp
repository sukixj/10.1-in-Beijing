#include<ctime>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
using namespace std;
int main() {
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	srand(time(0));
	printf("%d",rand()%20010623);
	return 0;
}
