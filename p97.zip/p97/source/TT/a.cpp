#include<iostream>
#include<fstream>
#include<string>
#include<math.h>
#include<algorithm>

using namespace std;

int l,maxx,minn,ans;
int a[27][1000003];
string str;


int main()
{
   
   ifstream fin("a.in");
   ofstream fout("a.out");	
   fin>>l;
   
   if(l==1){ fout<<"0";    fin.close(); fout.close();	return 0; }
   
   fin>>str;
   

   
   for(int i=1;i<=l;i++)
	{   
	
	   for(int j=1;j<=26;j++)
	    a[j][i]=a[j][i-1];
	   a[str[i-1]-'a'+1][i]++; 
	}
	
	for(int i=1;i<l;i++)
	   for(int j=i+1;j<=l;j++)
	   {
	   	 //   cout<<i<<"  ";
	   	    
	   	    maxx=0;
	   	    minn=999999;
			   for (int k=1;k<=26;k++)
	   	         {
	   	         	maxx=maxx>(a[k][j]-a[k][i-1])?maxx:(a[k][j]-a[k][i-1]);
	   	         	if((a[k][j]-a[k][i-1])<minn && (a[k][j]-a[k][i-1])!=0)minn=a[k][j]-a[k][i-1];
					}
		    ans=ans>(maxx-minn)? ans: (maxx-minn);
					
	   }
	
	
			fout<<ans;

  fin.close();
  fout.close();
	
	return 0;
}


