#include<iostream>
#include<fstream>
#include<string>
#include<math.h>
#include<algorithm>

using namespace std;

double x[3][2],y[3][2];
double xx,yy;

int mes(double x1,double y1,double x2,double y2,double x3,double y3,double x4,double y4)
{
	
	if(y1==y2)y1=y1+0.01;
	if(y3==y4)y3=y3+0.01;
	if(x1==x2)x1=x1+0.01;
	if(x3==x4)x3=x3+0.01;
	
	double k1=(y1-y2)/(x1-x2);
	double k2=(y3-y4)/(x3-x4);
	
//	cout<<k1<<k2<<endl;
	
	double b1=y1-k1*x1;
	double b2=y3-k2*x3;
	
	double x=(b2-b1)/(k1-k2);
//	cout<<x<<endl;
		
	xx=x;
	yy=x*k1+b1;
	
	
	if((x-x1)*(x-x2)<0 && (x-x3)*(x-x4)<0)
	return 1;
	return 0;
}


int fi(double x1,double y1,double x2,double y2,double x3,double y3,double x4,double y4)
{
	
	if(y1==y2)y1=y1+0.01;
	if(y3==y4)y3=y3+0.01;
	if(x1==x2)x1=x1+0.01;
	if(x3==x4)x3=x3+0.01;
	
	double k2=(y3-y4)/(x3-x4);

	double b2=y3-k2*x3;
	
	xx=(2*k2*y1-(k2*k2-1)*x1-2*k2*b2)/(k2*k2+1);
	yy=(2*k2*x1+(k2*k2-1)*y1+2*b2)/(k2*k2+1);
	
	
	if(mes(xx,yy,x2,y2,x3,y3,x4,y4)==1)
	return 1;
	return 0;
}


int main()
{
   
   ifstream fin("b.in");
   ofstream fout("b.out");	

  for(int i=0;i<=2;i++)
    for(int j=0;j<=1;j++)
   fin>>x[i][j]>>y[i][j];

  //cout<<mes(0,0,1,1,0,1,1,0);


if(mes(x[0][0],y[0][0],x[0][1],y[0][1],x[1][0],y[1][0],x[1][1],y[1][1])==0) {fout<<"YES"; fin.close();  fout.close();return 0;}

if(fi(x[0][0],y[0][0],x[0][1],y[0][1],x[2][0],y[2][0],x[2][1],y[2][1])==0) {fout<<"NO"; fin.close();  fout.close();return 0;}

if(mes(xx,yy,x[0][1],y[0][1],x[1][0],y[1][0],x[1][1],y[1][1])==0 && mes(x[0][0],y[0][0],xx,yy,x[1][0],y[1][0],x[1][1],y[1][1])==0)
{fout<<"YES"; fin.close();  fout.close();return 0;}
else
fout<<"NO";


  fin.close();
  fout.close();
	
	return 0;
}


