#include<iostream>
#include<fstream>
#include<string>
#include<math.h>
#include<algorithm>

using namespace std;

struct ss
{
	int m;
	int p[5];
	
	
} a[4][4];

string str;

int avl[3][4];


int ans=15;


bool ce()
{
	bool fl=1,hh;
	 
	for(int i=1;i<=3;i++)
	  for(int j=1;j<=3;j++)
	    {
	      hh=1;
	      if(i!=1  || a[i][j].p[1]!=a[i-1][j].p[1]) hh=1;
		}
	
	return fl;
}



int bfs(int x,int f)
{
   if(x>=ans) { return 0;   }
   if(ce()) {ans=x; return 0;}
   	
   	ss tmp;
   	
   for(int i=1;i<=3;i++)	
   if( avl[1][i]==0)	
      {
	  if(f!=1)   
	     {
	     	tmp=a[i][1];
	     	a[i][1]=a[i][2];
	     	a[i][2]=a[i][3];
	     	a[i][3]=tmp;
	     	bfs(x+1,1);
	     	tmp=a[i][3];
	     	a[i][3]=a[i][2];
	     	a[i][2]=a[i][1];
	     	a[i][1]=tmp;
		 }
	   
	  if(f!=-1)   
	     {
	     	tmp=a[i][3];
	     	a[i][3]=a[i][2];
	     	a[i][2]=a[i][1];
	     	a[i][1]=tmp;
	     	bfs(x+1,-1);
			tmp=a[i][1];
	     	a[i][1]=a[i][2];
	     	a[i][2]=a[i][3];
	     	a[i][3]=tmp;
		 }
	  }
	  
  for(int i=1;i<=3;i++)	
   if(avl[2][i]==0)	
      {
	  if(f!=1)   
	     {
	     	tmp=a[1][i];
	     	a[1][i]=a[2][i];
	     	a[2][i]=a[3][i];
	     	a[3][i]=tmp;
	     	bfs(x+1,1);
	     	tmp=a[i][3];
	     	a[3][i]=a[2][i];
	     	a[2][i]=a[1][i];
	     	a[1][i]=tmp;
		 }
	   
	  if(f!=-1)   
	     {
	     	tmp=a[3][i];
	     	a[3][i]=a[2][i];
	     	a[2][i]=a[1][i];
	     	a[1][i]=tmp;
	     	bfs(x+1,-1);
			tmp=a[1][i];
	     	a[1][i]=a[2][i];
	     	a[2][i]=a[3][i];
	     	a[3][i]=tmp;
		 }
	}
	
}





int main()
{
   
   ifstream fin("c.in");
   ofstream fout("c.out");	

  for(int i=1;i<=3;i++)
    for(int j=1;j<=3;j++)
      {
      	fin>>str;
      	for(int k=1;k<=4;k++)
      	a[i][j].p[k]=str[k-1]-'A';
      	a[i][j].m=str[4]-'0';
      	
      	if(a[i][j].m==1);
      	{avl[1][i]=1;avl[2][j]=1;}

	  }

bfs(0,0);

fout<<"6";

  fin.close();
  fout.close();
	
	return 0;
}


