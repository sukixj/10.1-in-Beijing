#include<fstream>
#define maxn 1000011
using namespace std;
ifstream cin("a.in");
ofstream cout("a.out");
int statis[maxn][27],n;
int f[27][27],jud[27][27],ans=0; //��xΪ���yΪ��С���Ƿ���ã�0=��ͷ��ʼ�����ô���1=ͷ��y���ã�2=ͷ��y���ã� 
char instr[maxn];
void input()
{
	cin>>n;
	for(int i=1;i<=n;i++) 
	{
		cin>>instr[i];
		for(int j=1;j<=26;j++) statis[i][j]=statis[i-1][j];
		statis[i][instr[i]-96]++;
		int curch=instr[i]-96;//��ǰ�ַ� 
		for(int j=1;j<=26;j++)
		{
			f[curch][j]++;
			f[j][curch]--;
			if(f[j][curch]>=0&&jud[j][curch]==0) jud[j][curch]=1;
			if(f[j][curch]>=0&&jud[j][curch]==2)
			{
				f[j][curch]++;
				jud[j][curch]=1;
			}
			if(f[j][curch]<0) 
			{
				f[j][curch]=-1;
				jud[j][curch]=2;
			}
			if(jud[curch][j]!=0)ans=max(ans,f[curch][j]);
		}
	}
	cout<<ans<<endl;
}
int main()
{
	input();
	return 0;
}
