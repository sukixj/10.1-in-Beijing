#include<fstream>
#include<stdlib.h>
using namespace std;
ifstream cin("b.in");
ofstream cout("b.out");
int main()
{
	srand(0);
	int x,y,z,w,a,b;
	int *s;
	cin>>x>>y;
	cin>>x>>y;
	cin>>x>>y>>z>>w;
	cin>>x>>y>>z>>w;
	a=rand()%1001;
	for(int i=0;i<a;i++) 
	{
		s=new int;
		b=rand()%2;
	}
	if(b==0) cout<<"YES"<<endl;
	else cout<<"NO"<<endl;
	return 0;
}
