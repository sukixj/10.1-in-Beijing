#include<fstream>
#include<string.h>
#include<map>
#include<queue>
using namespace std;
ifstream cin("c.in");
ofstream cout("c.out");
struct node
{
	int col[5];
	int num,state,hascol[5];
};
node nodes[10];
queue < pair<long long, int> > sq;
map <long long, int> hash;
int cgraph[9],coled[10][10],checked[10][10],dirx[5],diry[5];//�У���
int dfs(char curcol,int curx,int cury,int lastcol)
{
	int ret=0;
	if(checked[curx][cury]!=0||(coled[curx][cury]!=curcol&&coled[curx][cury]!=0)||(coled[curx][cury]==0&&lastcol==0)) return ret;
	checked[curx][cury]=1;
	if(curcol==coled[curx][cury]) ret++;
	if(curx>0) ret+=dfs(curcol,curx-1,cury,coled[curx][cury]);
	if(curx<8) ret+=dfs(curcol,curx+1,cury,coled[curx][cury]);
	if(cury>0) ret+=dfs(curcol,curx,cury-1,coled[curx][cury]);
	if(cury<8) ret+=dfs(curcol,curx,cury+1,coled[curx][cury]);
	return ret;
} 
bool checkcoled(long long curgraph)
{
	int tocheck[5]={1,0,0,0,0},ans=0;
	memset(coled,0,sizeof(coled));
	for(int i=2;i>=0;i--)
	{
		for(int j=2;j>=0;j--)
		{
			int st=curgraph%10;
			coled[i*3][j*3+1]=nodes[st].col[0];
			coled[i*3+2][j*3+1]=nodes[st].col[1];
			coled[i*3+1][j*3]=nodes[st].col[2];
			coled[i*3+1][j*3+2]=nodes[st].col[3];
			curgraph/=10;
		}
	}
	for(int i=0;i<9;i++)
	{
		for(int j=0;j<9;j++)
		{
			for(int k=1;k<=4;k++)
			{
				if(tocheck[k]==0&&coled[i][j]==k)
				{
					memset(checked,0,sizeof(checked));
					ans+=dfs(k,i,j,0);
					tocheck[k]=1;
				}
			}
		}
	}
	if(ans==36) return true;
	return false;
}
long long mult(int a,int b,int c,int d,int e,int f,int g,int h,int i)
{
	return (((((((a*10+b)*10+c)*10+d)*10+e)*10+f)*10+g)*10+h)*10+i;
}
void bfs()
{
	sq.push(make_pair(12345678,0));
	hash[12345678]=1;
	while(!sq.empty())
	{
		long long st=sq.front().first,nextpush;
		int dep=sq.front().second;
		sq.pop();
		if(checkcoled(st)) 
		{
			cout<<dep<<endl;
			break;
		}
		for(int i=8;i>=0;i--)
		{
			cgraph[i]=st%10;
			st/=10;
		}
		if(dirx[0]!=1) nextpush=mult(cgraph[1],cgraph[2],cgraph[0],cgraph[3],cgraph[4],cgraph[5],cgraph[6],cgraph[7],cgraph[8]);
		if(hash[nextpush]==0) 
		{
			hash[nextpush]=1;
			sq.push(make_pair(nextpush,dep+1));
		}
		if(dirx[0]!=1) nextpush=mult(cgraph[2],cgraph[0],cgraph[1],cgraph[3],cgraph[4],cgraph[5],cgraph[6],cgraph[7],cgraph[8]);
		if(hash[nextpush]==0) 
		{
			hash[nextpush]=1;
			sq.push(make_pair(nextpush,dep+1));
		}
		if(dirx[1]!=1) nextpush=mult(cgraph[0],cgraph[1],cgraph[2],cgraph[4],cgraph[5],cgraph[3],cgraph[6],cgraph[7],cgraph[8]);
		if(hash[nextpush]==0) 
		{
			hash[nextpush]=1;
			sq.push(make_pair(nextpush,dep+1));
		}
		if(dirx[1]!=1) nextpush=mult(cgraph[0],cgraph[1],cgraph[2],cgraph[5],cgraph[3],cgraph[4],cgraph[6],cgraph[7],cgraph[8]);
		if(hash[nextpush]==0) 
		{
			hash[nextpush]=1;
			sq.push(make_pair(nextpush,dep+1));
		}
		if(dirx[2]!=1) nextpush=mult(cgraph[0],cgraph[1],cgraph[2],cgraph[3],cgraph[4],cgraph[5],cgraph[7],cgraph[8],cgraph[6]);
		if(hash[nextpush]==0) 
		{
			hash[nextpush]=1;
			sq.push(make_pair(nextpush,dep+1));
		}
		if(dirx[2]!=1) nextpush=mult(cgraph[0],cgraph[1],cgraph[2],cgraph[3],cgraph[4],cgraph[5],cgraph[8],cgraph[6],cgraph[7]);
		if(hash[nextpush]==0) 
		{
			hash[nextpush]=1;
			sq.push(make_pair(nextpush,dep+1));
		}
		if(diry[0]!=1) nextpush=mult(cgraph[3],cgraph[1],cgraph[2],cgraph[6],cgraph[4],cgraph[5],cgraph[0],cgraph[7],cgraph[8]);
		if(hash[nextpush]==0) 
		{
			hash[nextpush]=1;
			sq.push(make_pair(nextpush,dep+1));
		}
		if(diry[0]!=1) nextpush=mult(cgraph[6],cgraph[1],cgraph[2],cgraph[0],cgraph[4],cgraph[5],cgraph[3],cgraph[7],cgraph[8]);
		if(hash[nextpush]==0) 
		{
			hash[nextpush]=1;
			sq.push(make_pair(nextpush,dep+1));
		}
		if(diry[1]!=1) nextpush=mult(cgraph[0],cgraph[4],cgraph[2],cgraph[3],cgraph[7],cgraph[5],cgraph[6],cgraph[1],cgraph[8]);
		if(hash[nextpush]==0) 
		{
			hash[nextpush]=1;
			sq.push(make_pair(nextpush,dep+1));
		}
		if(diry[1]!=1) nextpush=mult(cgraph[0],cgraph[7],cgraph[2],cgraph[3],cgraph[1],cgraph[5],cgraph[6],cgraph[4],cgraph[8]);
		if(hash[nextpush]==0) 
		{
			hash[nextpush]=1;
			sq.push(make_pair(nextpush,dep+1));
		}
		if(diry[2]!=1) nextpush=mult(cgraph[0],cgraph[1],cgraph[5],cgraph[3],cgraph[4],cgraph[8],cgraph[6],cgraph[7],cgraph[2]);
		if(hash[nextpush]==0) 
		{
			hash[nextpush]=1;
			sq.push(make_pair(nextpush,dep+1));
		}
		if(diry[2]!=1) nextpush=mult(cgraph[0],cgraph[1],cgraph[8],cgraph[3],cgraph[4],cgraph[2],cgraph[6],cgraph[7],cgraph[5]);
		if(hash[nextpush]==0) 
		{
			hash[nextpush]=1;
			sq.push(make_pair(nextpush,dep+1));
		}
	}
}
void input()
{
	for(int i=0;i<9;i++)
	{
		nodes[i].num=i;
		for(int j=0;j<4;j++)
		{
			char st;
			cin>>st;
			if(st=='R') 
			{
				nodes[i].col[j]=1;
				nodes[i].hascol[1]=1;
			}
			if(st=='G') 
			{
				nodes[i].col[j]=2;
				nodes[i].hascol[2]=1;
			}
			if(st=='B') 
			{
				nodes[i].col[j]=3;
				nodes[i].hascol[3]=1;
			}
			if(st=='O') 
			{
				nodes[i].col[j]=4;
				nodes[i].hascol[4]=1;
			}
		}	
		cin>>nodes[i].state;
		if(nodes[i].state==1)
		{
			dirx[i/3]=1;
			diry[i%3]=1;
		}
	}
}
int main()
{
	input();
	bfs();
	return 0;
}
