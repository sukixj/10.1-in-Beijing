#include <iostream>
#include <cstring>
#include <cstdio>
#define INF 0x7fffffff
using namespace std;

const int Ms = 1011;
const int Ys = 26;
int n,ans,p,maxx,minn=INF;
char sr[Ms];
int s[Ys];

int max(int a,int b) 
{ return a > b ? a : b; } 

int dfs(int op,int ed,int now) {
	if(ed==n)
		return ans;
	s[now]++;
	maxx=0,minn=INF;
	for(int i=0; i<Ys; ++i) {
		if(s[i]==0) continue;
		if(s[i]>maxx)
			maxx=s[i];
		if(s[i]<minn)
			minn=s[i];
	}
	if(maxx-minn>ans)
		ans=maxx-minn;
	ed++;
	dfs(op,ed,sr[ed]-97);
}

int main() {
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	for(int i=0; i<n; ++i)
		cin>>sr[i];
	for(int i=0; i<n; ++i) {
		p=max(p,dfs(i,i,sr[i]-97));
		memset(s,0,sizeof(s));
		maxx=0,minn=INF,ans=0;
	}
	printf("%d",p);
	return 0;
}
/*
1000
abcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxyabcdefghijklmnopqrstuvwxy
*/
