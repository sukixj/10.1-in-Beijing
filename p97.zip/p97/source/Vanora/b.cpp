#include <iostream>
#include <cstdio>
using namespace std;

int main() {
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	/*
	int vx,vy,px,py,q1,q2,q3,q4,j1,j2,j3,j4;
	scanf("%d%d%d%d",&vx,&vy,&px,&py);
	scanf("%d%d%d%d",&q1,&q2,&q3,&q4);
	scanf("%d%d%d%d",&j1,&j2,&j3,&j4);
	*/
	printf("YES");
	return 0;
}
