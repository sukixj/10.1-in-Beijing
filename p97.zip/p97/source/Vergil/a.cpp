#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int n,maxn,minn,ans;
int num[27];
char s[1000001];
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	cin>>s;
	for(int i=0;i<n;i++)
	{
		memset(num,0,sizeof(num));
		for(int j=i;j<n;j++)
		{
			minn=0x3fffffff;maxn=0;
			num[s[j]-'a'+1]++;
			for(int k=1;k<=26;k++)
				if(num[k])
				{
					maxn=max(maxn,num[k]);
					minn=min(minn,num[k]);
				}
			ans=max(ans,maxn-minn);
		}
	}
	printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
/*
*/
