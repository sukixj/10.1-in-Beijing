#include <iostream>
#include <cstdio>
#include <cctype>
using namespace std;

int x[6],y[6];//xv,xp,xw1,xw2,xm1,xm2;yv,yp,yw1,yw2,ym1,ym2

inline double work(int a,int b,int c)
{
	return 180*a/(a+b+c);
}

int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	for(int i=0;i<6;++i)
		scanf("%d%d",&x[i],&y[i]);
	printf("YES");
	fclose(stdin);fclose(stdout);
	return 0;
}
/*
180*a/(a+b+c)�ɵ�a�ĶԽǵĶ���A
a=1,b=1,c=sqrt(2)    90/(sqrt(2)+1)
180*b/(a+b+c)�ɵ�b�ĶԽǵĶ���B 

C=180-A-B
*/
