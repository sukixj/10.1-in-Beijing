#include <iostream>
#include <cstdio>
#include <ctime>
#include <algorithm>
using namespace std;

int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	printf("5");
	fclose(stdin);fclose(stdout);
	return 0;
}
/*
*/
