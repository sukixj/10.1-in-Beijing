#include<iostream>
#include<algorithm>
#include<memory.h>
#include<cstring>
using namespace std;
char a[100001];
int stat[26][100001];
int getweight(int s,int e)
{
	int maxn=0,minn=1e6;
	for(int i=0;i<26;i++)
	{
		if(stat[i][e]-stat[i][s]>0)
		{
			maxn=max(maxn,stat[i][e]-stat[i][s]);
			minn=min(minn,stat[i][e]-stat[i][s]);
		}
	}
	return maxn-minn;
}
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	int n;
	scanf("%d",&n);
	scanf("%s",a);
	memset(stat,0,sizeof(stat));
	for(int i=1;i<=n;i++)
	{
		for(int j=0;j<26;j++)
		{
			stat[j][i]=stat[j][i-1];
		}
		stat[a[i-1]-'a'][i]++;
	}
//ok
	int maxans=0;
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			//cout<<getweight(i,j)<<endl;
			maxans=max(maxans,getweight(i,j));
		}
	}
	printf("%d\n",maxans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
