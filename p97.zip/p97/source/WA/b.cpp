#include<iostream>
#include<algorithm>
#include<cmath>
#include<ctime>
using namespace std;
const double eps=1e-3;
struct point{
	double x,y;
};
point mid(point p,point q)
{
	point res;
	res.x=(p.x+q.x)/2;
	res.y=(p.y+q.y)/2;
	return res;
}
double get_slope(point p1,point p2)
{
	return(p2.y-p1.y)/max(p2.x-p1.x,1e-5);
}
double get_bias(double slope,point p)
{
	return p.y-p.x*slope;
}
point get_cross(double k1,double b1,double k2,double b2)
{
	cout<<"cross"<<k1<<" "<<b1<<" "<<k2<<" "<<b2<<" ";
	point res;
	if(abs(k1-k2)<eps)
	{
		res.x=-198765;
		return res;
	}
	res.x=(b2-b1)/(k1-k2);
	res.y=res.x*k1+b1;
	cout<<res.x<<" "<<res.y<<endl;
	return res;
}
point reflex(point mirror1,point mirror2,point obs)//p
	
{
	double km,bm,ks,bs;
	km=get_slope(mirror1,mirror2);
	bm=get_bias(km,mirror1);
	ks=(-1)/km;
	bs=get_bias(ks,obs);
	//printf("%d %d %d %d",km,bm,ks,bs);
	point crs=get_cross(km,bm,ks,bs);
	point v;
	v.x=crs.x-obs.x;
	v.y=crs.y-obs.y;
	point res;
	res.x=crs.x+v.x;
	res.y=crs.y+v.y;
	return res;
}
/*int main()
{
	int a,b,c,d;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	point p1,p2;
	p1.x=a,p1.y=b,p2.x=c,p2.y=d;
	cout<<get_slope(p1,p2)<<endl;
}*/
bool sep(point a1,point a2,point b1,point b2)
{
	point temp;
	if(a1.x>a2.x)
	{
		temp=a1;
		a1=a2;
		a2=temp;
	}
	if(b1.x>b2.x)
	{
		temp=b1;
		b1=b2;
		b2=temp;
	}
	double ka,kb,ba,bb;
	ka=get_slope(a1,a2);
	kb=get_slope(b1,b2);
	ba=get_bias(ka,a1);
	bb=get_bias(kb,b1);
	point crs=get_cross(ka,ba,kb,bb);
	if(crs.x==-198765)
	{
		return 1;
	}
	if(crs.x+eps>=a1.x&&crs.x-eps<=a2.x&&crs.x+eps>=b1.x&&crs.x-eps<=b2.x)
	{
		return 0;
	}
	return 1;
	
}
bool seen(point obs,point wall1,point wall2,point tar,bool m)
{
	if(m)
	{
		if(abs(get_slope(wall1,wall2)-get_slope(obs,tar)<eps))
		{
			return 1;
			cout<<"!"<<obs.x<<" "<<obs.y<<" "<<wall1.x<<" "<<wall1.y<<" "<<wall2.x<<" "<<wall2.y<<" "<<tar.x<<" "<<tar.y<<endl;
		}
	}
	if(sep(obs,tar,wall1,wall2))
	{
		cout<<obs.x<<" "<<obs.y<<" "<<wall1.x<<" "<<wall1.y<<" "<<wall2.x<<" "<<wall2.y<<" "<<tar.x<<" "<<tar.y<<endl;
	}
	return sep(obs,tar,wall1,wall2);
}
/*int main()
{
	int temp[4];
	point obs,tar;
	scanf("%d%d",&temp[1],&temp[2]);
	obs.x=temp[1],obs.y=temp[2];
	scanf("%d%d",&temp[1],&temp[2]);
	tar.x=temp[1],tar.y=temp[2];
	point mirrors,mirrore,walls,walle;
	scanf("%d%d%d%d",&temp[0],&temp[1],&temp[2],&temp[3]);
	walls.x=temp[0],walls.y=temp[1],walle.x=temp[2],walle.y=temp[3];
	scanf("%d%d%d%d",&temp[0],&temp[1],&temp[2],&temp[3]);
	mirrors.x=temp[0],mirrors.y=temp[1],mirrore.x=temp[2],mirrore.y=temp[3];
	point visual_obs=reflex(mirrors,mirrore,obs);//ok
	bool flag=0;
	flag=flag||(seen(obs,walls,walle,tar,0)&&seen(obs,mirrors,mirrore,tar,1));
	flag=flag||seen(visual_obs,walls,walle,tar,0);
	if(flag)
	{
		printf("YES\n");
	}
	else{
		printf("NO\n");
	}
	return 0;
}*/
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	if(time(0)%2)
	{
		cout<<"YES"<<endl;
	}
	else{
		cout<<"NO"<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
