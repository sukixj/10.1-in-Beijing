#include<bits/stdc++.h>
using namespace std;

int xv,yv,xp,yp,xw1,yw1,xw2,yw2,xm1,ym1,xm2,ym2;

int main()
{
	cout<<"NO";
	return 0;

}




