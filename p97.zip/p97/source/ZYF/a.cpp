#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,cur,ans,pre;
char s[1000005];
bool ch[30];
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d%s",&n,&s);
	for(int i=0;i<n;i++)
	  ch[s[i]-'a']=1;
	for(int i=0;i<=25;i++)
	  if(ch[i])
	    {
	    	cur=0,pre=0;
	    	for(int j=0;j<n;j++)
	    	  {
	    	  	if(s[j]-'a'==i) 
				  {
				  	cur++;
					if(j-pre+1==cur) ans=max(ans,cur-1);
					else ans=max(ans,cur);
				  }
	    	  	else 
	    	  	  {
	    	  	  	cur--;
	    	  	  	if(cur<0) cur=0,pre=j+1;
				  }
			  }
		}
	printf("%d",ans);
	return 0;
}
