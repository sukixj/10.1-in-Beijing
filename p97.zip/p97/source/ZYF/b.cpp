#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#define db(x) (double)(x)
using namespace std;
int x1,x2,y1,y2,wx1,wx2,wy1,wy2,mx1,mx2,my1,my2;
bool ok;
bool check(double aa,double bb,int cc,int dd,int ee,int ff)
{
	double maa=max(cc,ee),mia=min(cc,ee);
	double mab=max(cc,ff),mib=min(cc,ff);
	if(aa<db(maa)+0.005&&aa>db(mia)-0.005&&bb<db(mab)+0.005&&bb>db(mib)-0.005) return 1;
	else return 0;
}
bool same(double kk,double bb)
{
	double aa=db(x1)*kk-bb;
	double dd=db(x2)*kk-bb;
	if((aa-db(y1))*(dd-db(y2))>0) return 0;
	else return 1; 
}
bool wallman()
{
	double km=db(y2-y1)/db(x2-x1),kw=db(wy2-wy1)/db(wx2-wx1);
	if(km>20000) km=20000;if(kw>20000) kw=20000;
	double bbb=-kw*db(wx1)+db(wy1);
	if(!same(kw,bbb)) return 1;
	double xx=db(wy1-my1+km*my1-kw*wx1)/(km-kw);
	double yy=km*xx-km*db(x1)+db(y1);
	if(check(xx,yy,wx1,wy1,wx2,wy2)) return 1;
	else return 0;
}
bool mirman()
{
	double km=db(my2-my1)/db(mx2-mx1);                          //jingzi k
	if(km>20000) km=20000;
	double bb=-km*db(mx1)+db(my1);                               //jingzi b
	if(same(km,bb)) return 0;
	double dcy=(2*km*db(x1)+km*db(y1)+2*bb-db(y1))/(km*km+1);
	double dcx=db(x1)-km*dcy+km*db(y1);
	double kk=(dcy-db(y2))/(dcx-db(x2));                        //ren k
	if(kk>20000) kk=20000;
	double bbb=-kk*dcx+dcy;                                   //ren b
	double xx=(bbb-bb)/(kk-km);
	double yy=kk*xx+bbb;
	if(check(xx,yy,mx1,my1,mx2,my2)) return 1;
	else return 0;
}
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%d%d%d%d%d%d%d%d%d%d%d%d",&x1,&y1,&x2,&y2,&wx1,&wy1,&wx2,&wy2,&mx1,&my1,&mx2,&my2);
	if(!wallman()) ok=1;
	else if(mirman()) ok=1;
	if(ok) printf("YES");
	else printf("NO");
	return 0;
}
/*
-1 3
1 3
0 2 0 4
0 0 0 1
*/
/*
0 0
1 1
0 1 1 0
-100 -100 -101 -101
*/
/*
0 0
1 1
0 1 1 0
-1 1 1 3
*/
/*
0 0
10 0
100 100 101 101
1 0 3 0
*/
