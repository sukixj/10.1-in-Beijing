#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;
int i,j,n,leng;
char c;
int num[27],ans,maxx,minn;
int min(int a,int b)
{
    if(a>b)return b;
    else return a;
}
int max(int a,int b)
{
    if(a>b)return a;
    else return b;
}
int main()
{
    freopen("a.in","r",stdin);
    freopen("a.out","w",stdout);
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        scanf("%c",&c);
        num[c-'a'+1]++;
        maxx=max(maxx,num[c-'a'+1]);
        minn=100007;
        for(j=1;j<=26;j++)
        if(num[j])
        minn=min(minn,num[j]);
        ans=max(ans,maxx-minn);
    }
    printf("%d\n",ans);
    fclose(stdin);fclose(stdout);
    return 0;
}
        
