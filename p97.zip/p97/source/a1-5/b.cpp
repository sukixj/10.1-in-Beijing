#include<iostream>
#include<cstring>
#include<cstdio>
#include<algorithm>
using namespace std;
int x1,x2,y1,y2,xc1,yc1,xc2,yc2,xp1,yp1,xp2,yp2;
int main()
{
    freopen("b,in","r",stdin);
    freopen("b.out","w",stdout);
    scanf("%d%d",&x1,&y1);
    scanf("%d%d",&x2,&y2);
    scanf("%d%d%d%d",&xc1,&yc1,&xc2,&yc2);
    scanf("%d%d%d%d",&xp1,&yp1,&xp2,&yp2);
    printf("NO\n");
    fclose(stdin);fclose(stdout);
    return 0;
}
