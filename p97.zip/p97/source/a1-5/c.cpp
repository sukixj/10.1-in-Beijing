#include<iostream>
#include<cstring>
#include<algorithm>
#include<cstdio>
using namespace std;
struct node
{
       char l,r,h,b;
       int v;
}e[10];
int ans,map[4][4];
int start,i,j,x,y;
void chang(int line,int cole,int dirt)
{
     int t;
     if(line==0)
     {
         if(dirt==1)
         {t=map[1][cole];map[1][cole]=map[2][cole];map[2][cole]=map[3][cole];map[3][cole]=t;}
         else 
         {t=map[3][cole];map[3][cole]=map[2][cole];map[2][cole]=map[1][cole];map[1][cole]=t;}
     }
     else
     {
         if(dirt==1)
         {t=map[line][1];map[line][1]=map[line][2];map[line][2]=map[line][3];map[line][3]=t;}
         else 
         {t=map[line][3];map[line][3]=map[line][2];map[line][2]=map[line][1];map[line][1]=t;}
     }
}
void dfs(int s,int p,int q)
{
     if(e[map[p][q-1]].r==e[start].l){e[map[p][q-1]].v=1;dfs(map[p][q-1],p,q-1);}
     else 
     {
          if(q-1>=1)
          {
              ans++;
              chang(0,q-1,1);
              dfs(start,p,q);
              chang(0,q-1,0);
              chang(0,q-1,0);
              dfs(start,p,q);
          }
     }         
     if(e[map[p][q+1]].l==e[start].r){e[map[p][q+1]].v=1;dfs(map[p][q+1],p,q+1);}
      else 
     {
          if(q+1<=3)
          {
              ans++;
              chang(0,q+1,1);
              dfs(start,p,q);
              chang(0,q+1,0);
              chang(0,q+1,0);
              dfs(start,p,q);
          }
     }         
     if(e[map[p-1][q]].b==e[start].h){e[map[p-1][q]].v=1;dfs(map[p-1][q],p-1,q);}
      else 
     {
          if(p-1>=1)
          {
              ans++;
              chang(p-1,0,1);
              dfs(start,p,q);
              chang(p-1,0,0);
              chang(p-1,0,0);
              dfs(start,p,q);
          }
     }         
     if(e[map[p+1][q]].h==e[start].b){e[map[p+1][q]].v=1;dfs(map[p+1][q],p+1,q);}
      else 
     {
          if(p+1<=3)
          {
              ans++;
              chang(p+1,0,1);
              dfs(start,p,q);
              chang(p+1,0,0);
              chang(p+1,0,0);
              dfs(start,p,q);
          }
     }
}
int main()
{
    freopen("c.in","r",stdin);
    freopen("c.out.","w",stdin);
    for(i=1;i<=9;i++)
    {
        scanf("%c%c%c%c",&e[i].h,&e[i].b,&e[i].l,&e[i].r);
        scanf("%d",&e[i].v);
        map[i/3][i%3+1]=i;
        if(e[i].v==1)
        {start=i;x=i/3;y=i%3+1;}
    }
    dfs(start,x,y);
    printf("%d\n",ans);
    fclose(stdin);fclose(stdout);
    return 0;
}
