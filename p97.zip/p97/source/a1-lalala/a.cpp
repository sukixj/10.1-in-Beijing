#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n;
char a[10000];
int s[120];
int check(int x,int y)
{
	int max=-1,min=0x3f;
	for(int i=x;i<=y;i++)
	{
		int k=(int)a[i];
		s[k]++;
		if(s[k]>max) max=s[k];
		if(s[k]<min) min=s[k];
	}
	memset(s,0,sizeof(s));
	return max-min;
}
int ans=-1;
void f(int d)
{
	if(d==n) return;
	for(int i=0;i<n;i++)
	{
		if(i<=d){
			if(check(i,d)>ans) ans=check(i,d);
		}
		
		f(d+1);
	}
}
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.in","w",stdout);
	cin>>n;
	gets(a);
	f(0);
	cout<<ans;
        return 0;
}