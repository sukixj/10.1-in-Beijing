#include<iostream>
#include<fstream>
#include<string>
#include<stdlib.h>
#include<math.h>
using namespace std;

int main()
{
	ifstream in;
	ofstream out;
	in.open("a.in");
	out.open("a.out");
    int i,n;
    n=in.get();
	out<<"YES";
    in.close();
	out.close();
	system("pause");
	return 0;
}
