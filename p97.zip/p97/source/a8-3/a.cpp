#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;

char s[1000100];
int vis[110],len[1000100];

int main() {
	
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	
	int tmp,n,ans = 0,mx,mn,te;
	bool flag;
	
	scanf("%d",&n);
	scanf("%s",s);
	
	
		for (int i=0; i<n; ++i) {
			memset(vis,0,sizeof(vis));
			memset(len,0,sizeof(len));
			mx = 1;mn = 1;
			tmp = s[i]-96;
			
			vis[tmp] ++;
			len[vis[tmp]] ++;
			flag = false;
			te = tmp;
			
			for (int j=i+1; j<n; ++j) {
				tmp = s[j]-96;
				if (!flag&&tmp!=te) flag = true;
				
				len[vis[tmp]] --;
				vis[tmp] ++;
				len[vis[tmp]] ++;
				
				if (vis[tmp]>mx) mx = vis[tmp];
				int k = 1;
				if (!flag) k = mx;
				else while (!len[k]) k++;
				mn = k;
				
				ans = max(ans,mx-mn);
			}
		}
	
	printf("%d",ans);
	
	return 0;
}



