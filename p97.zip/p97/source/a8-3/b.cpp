#include<cstdio>
#include<algorithm>


using namespace std;

struct xiand{
	int k2,k1,d1,d2;
	double b;
	bool sh;
}qn,jn,rn;


int read() {
	int x = 0,f = 1;char ch = getchar();
	for (; ch<'0'||ch>'9'; ch = getchar()) 
		if (ch=='-') f = -1;
	for (; ch>='0'&&ch<='9'; ch = getchar())
		x = x*10+ch-'0';
	return x*f;
}
xiand gj(int x,int y,int xx,int yy) {
	xiand t;
	if (x==xx) {	
		t.sh = true;
		t.d1 = t.d2 = 0;
		t.k1 = min(y,yy);
		t.k2 = max(y,yy);
		return t;
	}	
	t.sh = false;
	t.k2 = yy - y;
	t.k1 = xx - x;
	t.b = (double)(y-(yy-y)/(xx-x)*x);
	t.d1 = min(x,xx);
	t.d2 = max(x,xx);
	return t;
}

inline bool pd(xiand a,xiand b) {
	int g1 = max(a.d1,b.d1),g2 = min(a.d2,b.d2);
	if (g2<g1) return false;
	double t1,t2,t3,t4;
	
	if (a.sh) {
		t1 = a.k1;
		t2 = a.k2;
	}
	else {
		t1 = (a.k2)/(a.k1)*g1+a.b;
		t2 = (a.k2)/(a.k1)*g2+a.b;
		if (t1>t2) swap(t1,t2);
	}
	if (b.sh) {
		t3 = b.k1;
		t4 = b.k2;
	}
	else {
		t3 = (b.k2)/(b.k1)*g1+b.b;
		t4 = (b.k2)/(b.k1)*g2+b.b;
		if (t3>t4) swap(t3,t4);
	}
	
	if (t1>t4||t3>t2) return false;
	if (t1>t3&&t2>t4) return false;
	if (t3>t1&&t4>t2) return false;
	if (t1<=t3&&t2>=t4) return true;//�ཻ 
	if (t1>=t3&&t2<=t4) return true;
}

inline void Work() {
	bool rj = true,rq = false;
	if (rn.sh&&jn.sh) rj = false;
	else if (!rn.sh&&!jn.sh) {
		if ((rn.k2/rn.k1)==(jn.k2/jn.k1)&&rn.b==jn.b) rj = false;
	}
	if (rj) rj = pd(rn,jn);//�˾� 
	
	if (rj) {
		printf("NO");
		return ;
	}
	
	if (rn.sh&&qn.sh) rq = true;
	else if (!rn.sh&&!qn.sh) {
		if ((rn.k2/rn.k1)==(qn.k2/qn.k1)&&rn.b==qn.b&&(rn.d1<qn.d2||qn.d1<rn.d2)) rq = true;
	}
	if (!rq) rq = pd(rn,qn);//��ǽ 
	
	if (rj&&rq) {printf("NO"); return ;}
	if (!rj&&!rq) {printf("YES");return ;}
	if (rq&&!rj) {
		printf("YES"); return ;
	}
}


int main() {
	
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	
	int a = read(), b = read(),c = read(),d = read();
	rn = gj(a,b,c,d);
	a = read(), b = read(),c = read(),d = read();
	qn = gj(a,b,c,d);
	a = read(), b = read(),c = read(),d = read();
	jn = gj(a,b,c,d);
	
	Work();
	
	return 0;
	
}
/*
-1 3
1 3
0 2 0 4
0 0 0 1


0 0
1 1
0 1 1 0
-100 -100 -101 -101

0 0
1 1
0 1 1 0
-1 1 1 3


0 0
10 0
100 100 101 101
1 0 3 0



*/
