#include<cstdio>



int main() {
	
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	
	char t[100];
	int f = 1;
	char v;
	
	scanf("%s",t);
	v = t[0];
	for (int i=1; i<4; ++i) {
		if (t[i]!=v) f = 0;
	}
	for (int i=1; i<=8; ++i) {
		scanf("%s",t);
		for (int i=0; i<4; ++i) {
			if (t[i]!=v) f = 0;
		}
	}
	
	if (f==1) printf("0");
	else printf("6");
	
	return 0;
}
