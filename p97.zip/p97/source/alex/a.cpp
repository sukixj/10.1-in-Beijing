#include <cstdio>
#include <cstring>

using namespace std;

const int maxn = 1e6 + 1;

int get(void);
void shift(int x);

int n,ans = -1,count[26];
char buf[maxn];
int a[26],place[26];

int main(int argc,char *argv[])
{
	int maxus,t;
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",buf);
	for (int i = 0;i < n;i++)
	{
		memset(count,0,sizeof count);
		for (int j = 0;j < 26;j++)
		{
			a[j] = j;
			place[j] = j;
		}
		maxus = 0;
		for (int j = i;j < n;j++)
		{
			if (++count[(t = buf[j] - 'a')] > maxus)
			{
				maxus = count[t];
			}
			shift(place[t]);
			if (maxus - get() > ans)
			{
				ans = maxus - get();
			}
		}
	}
	printf("%d\n",ans);
	return 0;
}

inline int get(void)
{
	return count[a[0]];
}

void shift(int x)
{
	int t;
	while (x && (!count[a[x / 2]] || count[a[x / 2]] > count[a[x]]))
	{
		place[a[x]] = x / 2;
		place[a[x / 2]] = x;
		t = a[x];
		a[x] = a[x / 2];
		x /= 2;
		a[x] = t;
	}
}
