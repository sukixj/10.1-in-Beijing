#include <cstdio>

using namespace std;

struct point{
	double x,y;
};

struct line{
	double a,b,c;
};

struct point pa,pb,wall_1,wall_2,mirror_1,mirror_2;

int aline(struct line l1,struct line l2);
struct line getline(struct point p1,struct point p2);
struct point getpoint(struct line l1,struct line l2);
struct point shadow(struct point p,struct line l);
struct point reflect(struct point p,struct line l);
int isNAN(double x);

int main(int argc,char *argv[])
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%lf%lf",&pa.x,&pa.y);
	scanf("%lf%lf",&pb.x,&pb.y);
	scanf("%lf%lf%lf%lf",&wall_1.x,&wall_1.y,&wall_2.x,&wall_2.y);
	scanf("%lf%lf%lf%lf",&mirror_1.x,&mirror_1.y,&mirror_2.x,&mirror_2.y);
	struct point t;
	if (pa.x > pb.x)
	{
		t = pa;
		pa = pb;
		pb = t;
	}
	if (wall_1.x > wall_2.x)
	{
		t = wall_1;
		wall_1 = wall_2;
		wall_2 = t;
	}
	if (mirror_1.x > mirror_2.x)
	{
		t = mirror_1;
		mirror_1 = mirror_2;
		mirror_2 = t;
	}
	struct line wall = getline(wall_1,wall_2),mirror = getline(mirror_1,mirror_2),straight = getline(pa,pb);
	if (aline(wall,straight))
	{
		if (pb.x < wall_1.x || pa.x > wall_2.x)
		{
			printf("YES\n");
			return 0;
		}
	}
	else
	{
		t = getpoint(wall,straight);
		if (t.x < wall_1.x || t.x > wall_2.x)
		{
			if (aline(mirror,straight))
			{
				printf("YES\n");
				return 0;
			}
			else
			{
				t = getpoint(mirror,straight);
				if (t.x < mirror_1.x || t.x > mirror_2.x)
				{
					printf("YES\n");
					return 0;
				}
			}
		}
	}
	double xj1 = (mirror_2.x - mirror_1.x) * (pa.y - mirror_1.y) - (pa.x - mirror_1.x) * (mirror_2.y - mirror_1.y),xj2 = (mirror_2.x - mirror_1.x) * (pb.y - mirror_1.y) - (pb.x - mirror_1.x) * (mirror_2.y - mirror_1.y);
	if (xj1 * xj2 <= 0)
	{
		printf("NO\n");
		return 0;
	}
	t = getpoint(mirror,getline(pa,reflect(pb,mirror)));
	if (t.x < mirror_1.x || t.x > mirror_2.x)
	{
		printf("NO\n");
		return 0;
	}
	struct point t2 = getpoint(getline(pa,t),wall);
	if (isNAN(t2.x) || isNAN(t2.y) || (wall_1.x <= t2.x && t2.x <= wall_2.x))
	{
		printf("NO\n");
		return 0;
	}
	t2 = getpoint(getline(pb,t),wall);
	if (isNAN(t2.x) || isNAN(t2.y) || (wall_1.x <= t2.x && t2.x <= wall_2.x))
	{
		printf("NO\n");
		return 0;
	}
	printf("YES\n");
	return 0;
}

int aline(struct line l1,struct line l2)
{
	return l1.a * l2.b - l2.a * l1.b == 0;
}

inline struct line getline(struct point p1,struct point p2)
{
	double a = p2.y - p1.y,b = p1.x - p2.x;
	return (struct line){a,b,-(p1.x * a + p1.y * b)};
}

inline struct point getpoint(struct line l1,struct line l2)
{
	double x = (l2.c * l1.b - l1.c * l2.b) / (l1.a * l2.b - l2.a * l1.b);
	return (struct point){x,-(l1.a * x + l1.c) / l1.b};
}

inline struct point shadow(struct point p,struct line l)
{
	return getpoint(l,getline(p,(struct point){p.x+l.a,p.y+l.b}));
}

inline struct point reflect(struct point p,struct line l)
{
	struct point sh = shadow(p,l);
	return (struct point){2 * sh.x - p.x,2 * sh.y - p.y};
}

inline int isNAN(double x)
{
	return x != x;
}
