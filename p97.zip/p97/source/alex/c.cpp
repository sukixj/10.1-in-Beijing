#include <cstdio>
#include <cstring>

using namespace std;

struct block{
	char color[4],moveable;
};

int test(int deep,struct block now[3][3]);
int check(struct block ans[3][3]);

int maxdeep,queue[3 * 3 * 4 + 3][3];
char buf[10];
struct block map[3][3];
bool vis[3][3][4],lock[4];

int main(int argc,char *argv[])
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	for (int i = 0;i < 3;i++)
	{
		for (int j = 0;j < 3;j++)
		{
			scanf("%s",buf);
			for (int k = 0;k < 4;k++)
			{
				switch (buf[k])
				{
					case 'R':{
						map[i][j].color[k] = 0;
						break;
					}
					case 'B':{
						map[i][j].color[k] = 1;
						break;
					}
					case 'G':{
						map[i][j].color[k] = 2;
						break;
					}
					case 'O':{
						map[i][j].color[k] = 3;
						break;
					}
					default:{
						break;
					}
				}
			}
			switch(buf[4])
			{
				case '0':{
					map[i][j].moveable = 1;
					break;
				}
				case '1':{
					map[i][j].moveable = 0;
					break;
				}
				default:{
					break;
				}
			}
		}
	}
	for (maxdeep = 0;!test(0,map);maxdeep++);
	printf("%d\n",maxdeep);
	return 0;
}

int test(int deep,struct block now[3][3])
{
	if (deep == maxdeep)
	{
		return check(now);
	}
	else
	{
		
	}
}

int check(struct block ans[3][3])
{
	int head,tail,x,y,z;
	memset(vis,false,sizeof vis);
	memset(lock,false,sizeof lock);
	for (int i = 0;i < 3;i++)
	{
		for (int j = 0;j < 3;j++)
		{
			for (int k = 0;k < 4;k++)
			{
				if (!vis[i][j][k])
				{
					if (lock[ans[i][j].color[k]])
					{
						return 0;
					}
					vis[i][j][k] = true;
					lock[ans[i][j].color[k]] = true;
					head = 0,tail = 1;
					queue[tail][0] = i;
					queue[tail][1] = j;
					queue[tail][2] = k;
					while (head < tail)
					{
						head++;
						x = queue[head][0];
						y = queue[head][1];
						z = queue[head][2];
						switch (z)
						{
							case 0:{
								if (ans[x][y].color[2] == ans[x][y].color[0] && !vis[x][y][2])
								{
									tail++;
									queue[tail][0] = x;
									queue[tail][1] = y;
									queue[tail][2] = 2;
									vis[x][y][2] = true;
								}
								if (ans[x][y].color[3] == ans[x][y].color[0] && !vis[x][y][3])
								{
									tail++;
									queue[tail][0] = x;
									queue[tail][1] = y;
									queue[tail][2] = 3;
									vis[x][y][3] = true;
								}
								if (x && ans[x - 1][y].color[1] == ans[x][y].color[0] && !vis[x - 1][y][1])
								{
									tail++;
									queue[tail][0] = x - 1;
									queue[tail][1] = y;
									queue[tail][2] = 1;
									vis[x - 1][y][1] = true;
								}
								break;
							}
							case 1:{
								break;
							}
							case 2:{
								break;
							}
							case 3:{
								break;
							}
						}
					}
				}
			}
		}
	}
	return 1;
}
