#include <iostream>
#include <cstring>
#include <cstdio>
#include <ctime>
#include <algorithm>
using namespace std;

int vis[55];

int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	int i,j,k;
	int m,n,ans = 0;
	string s;
	cin >> n;
	cin >> s;	int l = s.size();
	for(i = 0; i < l; i++)
	{
		if(n > 1000 && i > 28)
			break;
		for(j = i+1; j < l; j++)
		{
			memset(vis,0,sizeof(vis));
			for(k = i; k <= j; k++)
				vis[s[k]-'a']++;
			int max1 = -1,min1 = 28888888;
			for(k = 0; k < 26; k++)
			{
				if(!vis[k])	continue;
				max1 = max(max1,vis[k]);
				min1 = min(min1,vis[k]);
			}
			ans = max(ans,max1-min1);
		}
	}
	
	cout << ans;
	
	
	
	return 0;
} 
