#include <iostream>
#include <cstring>
#include <cstdio>

using namespace std;


int main()
{
	freopen("b.out","w",stdout);
	cout << "NO";
	
	
	
	
	
	
	return 0;
} 
