#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <map>
#include <queue>
#include <algorithm>
using namespace std;
#define cp(a,b) memcpy(a,b,sizeof(a))
const int mod = 107293473;
struct node{
	int a[15][7];
	friend bool operator < (node a1,node a2)
	{
		long long num_a1 = 0,num_a2 = 0;
		for(int i = 0; i < 9; i++)
		for(int j = 0; j < 4; j++)
		{
			num_a1 = num_a1*11+a1.a[i][j]; 
			num_a2 = num_a2*11+a2.a[i][j]; 
			if(num_a1 > mod)
				num_a1 -= mod;
			if(num_a2 > mod)
				num_a2 -= mod;
		}
		return num_a1 < num_a2;
	}
};

int avai[15],vis[55][55],color[5];
int sum_color = 0;
char rgbo[35];
vector <int> choose;
map <node,int> mapn;

void dfs(node e,int x,int y)
{
	int i,j,k;
	vis[x][y] = 1;
	if(y == 0 || y == 1)
	{
		if(e.a[x][2] == e.a[x][y] && !vis[x][2])
			dfs(e,x,2);
		if(e.a[x][3] == e.a[x][y] && !vis[x][3])
			dfs(e,x,3);
		if(y == 0 && x/3)
			if(e.a[x-3][1] == e.a[x][y] && !vis[x-3][1])
				dfs(e,x-3,1);
		
		if(y == 1 && x < 6)
			if(e.a[x+3][0] == e.a[x][y] && !vis[x+3][0])
				dfs(e,x+3,0);
	}
	else
	{
		if(e.a[x][0] == e.a[x][y] && !vis[x][0])
			dfs(e,x,0);
		if(e.a[x][1] == e.a[x][y] && !vis[x][1])
			dfs(e,x,1);
		if(y == 2 && j%3)
			if(e.a[x-1][3] == e.a[x][y] && !vis[x-1][3])
				dfs(e,x-1,3);
		if(y == 3 && j%3 != 2)
			if(e.a[x+1][2] == e.a[x][y] && !vis[x+1][2])
				dfs(e,x+1,2);
	}
}

bool check(node p)
{
	int i,j,k,cnt = 0;	memset(vis,0,sizeof(vis));
	for(i = 0; i < 9; i++)
	for(j = 0; j < 4; j++)
	{
		if(!vis[i*6+j])
			dfs(p,i,j),cnt++;
	}
	if(cnt == sum_color)
		return 1;
	else
		return 0;
}

void print(node e)
{
	int i,j,k;
	for(i = 0; i < 9; i++)
	{
		for(j = 0; j < 4; j++)
			cout << e.a[i][j] << " ";
		cout << endl;
	}
}

int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	rgbo['R'] = 1;	rgbo['G'] = 2;	rgbo['B'] = 3;	rgbo['O'] = 4;
	int i,j,k;	int m,n;
	node p;	memset(p.a,0,sizeof(p.a));
	for(i = 0; i < 9; i++)
	{
		char c;	int mov;
		for(j = 0; j < 4; j++)
		{
			cin >> c;
			p.a[i][j] = rgbo[c];
			if(!color[rgbo[c]])
			{
				color[rgbo[c]] = 1;
				sum_color++;
			}
		}
		cin >> mov;
		if(mov)
		{
			int row = i/3,col = j%3;
			avai[row*2+1] = avai[row*2+2] = 1;
			avai[2*j+7] = avai[2*j+8] = 1;
		}
	}
	for(i = 1; i <= 12; i++)
		if(!avai[i])	choose.push_back(i);
	
	print(p);
	queue <node> q;
	q.push(p);	
	mapn[p] = 1;

	while(!q.empty())
	{
		node e = q.front();	q.pop();
		
		print(e);
		
		int step = mapn[e];
		if(check(e))	{cout << step-1; break;}
		for(i = 0; i < choose.size(); i++)
		{
			int num = choose[i],ex[7];
			node e2 = e;
	
			if(num == 1)
				cp(ex,e2.a[0]),cp(e2.a[0],e2.a[2]),cp(e2.a[2],e2.a[1]),cp(e2.a[1],ex);
			if(num == 3)
				cp(ex,e2.a[3]),cp(e2.a[3],e2.a[5]),cp(e2.a[5],e2.a[4]),cp(e2.a[4],ex);
			if(num == 5)
				cp(ex,e2.a[6]),cp(e2.a[6],e2.a[8]),cp(e2.a[8],e2.a[7]),cp(e2.a[7],ex);
			if(num == 2)
				cp(ex,e2.a[0]),cp(e2.a[0],e2.a[1]),cp(e2.a[1],e2.a[2]),cp(e2.a[2],ex);
			if(num == 4)
				cp(ex,e2.a[3]),cp(e2.a[3],e2.a[4]),cp(e2.a[4],e2.a[5]),cp(e2.a[5],ex);
			if(num == 6)
				cp(ex,e2.a[6]),cp(e2.a[6],e2.a[7]),cp(e2.a[7],e2.a[8]),cp(e2.a[8],ex);
			if(num == 7)
				cp(ex,e2.a[0]),cp(e2.a[0],e2.a[3]),cp(e2.a[3],e2.a[6]),cp(e2.a[6],ex);
			if(num == 9)
				cp(ex,e2.a[1]),cp(e2.a[1],e2.a[4]),cp(e2.a[4],e2.a[7]),cp(e2.a[7],ex);
			if(num == 11)
				cp(ex,e2.a[2]),cp(e2.a[2],e2.a[5]),cp(e2.a[5],e2.a[8]),cp(e2.a[8],ex);
			if(num == 8)
				cp(ex,e2.a[0]),cp(e2.a[0],e2.a[6]),cp(e2.a[6],e2.a[3]),cp(e2.a[3],ex);
			if(num == 10)
				cp(ex,e2.a[1]),cp(e2.a[1],e2.a[7]),cp(e2.a[7],e2.a[4]),cp(e2.a[4],ex);
			if(num == 12)
				cp(ex,e2.a[2]),cp(e2.a[2],e2.a[8]),cp(e2.a[8],e2.a[5]),cp(e2.a[5],ex);
			
			if(mapn.count(e2))	continue;
			mapn[e2] = step+1;
			q.push(e2);
		}
	}
	
	
	
	
	
	return 0;
} 
