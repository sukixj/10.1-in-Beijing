#include <iostream>
#include <cstdio>
#include <cstring>
#define maxn 1000000
using namespace std;
int  n, maxx = -0x7f, minn = 0x7fffffff, q = 0;
int ans, ch, sum, f[27][maxn] = {0};
string s;
bool flag;
int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	cin >> s;
	for(int a = 0; a < n; ++ a){
		ch = int (s[a]) - 'a';
		for(int b = 0; b < 26; ++ b){
			f[b][a] = f[b][a - 1];
		}
		f[ch][a] ++;
	}
	for(int a = 0; a < n; ++ a){
		for(int b = a; b < n; ++ b){
			maxx = -0x7f,minn = 0x7fffffff,flag = 1;
			for(int c = 0; c < 26; c ++){
				flag = 1;
				sum = f[c][b] - f[c][a - 1];
				if(sum > maxx &&flag)flag = 0,maxx = sum;
				if(sum < minn && sum && flag)flag = 0,minn = sum;
			}
			ans = maxx - minn;
			if(ans > q) q = ans;
		}
	}
	printf("%d",q);
}
