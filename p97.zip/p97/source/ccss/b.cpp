#include <cstdio>
#include <iostream>
using namespace std;
struct qq{
	double x1, x2, y1, y2;
	double k, b;
	bool isx,isy;
} l1, l2, l3, l4, l5;
double a;
	
int is(qq q1,qq q2){
	int x = (q1.b - q2.b) / (q1.k - q2.k);
	if(q1.isx = 1)x = (q1.y1 - q2.b) / q2.k;
	if(q2.isx = 1)x = (q2.y1 - q1.b) / q1.k;
	if(q1.isy = 1)x = q1.x1;
	if(q2.isy = 1)x = q2.x1;
	int y = q1.k * x + q1.b;

	if((x >= min(q1.x1, q1.x2)&& x <= max(q1.x1, q1.x2)) && (x >= min(q2.x1, q2.x2) && x <= max(q2.x1,q2.x2)) && (y >= min(q2.y1, q2.y2) && y <= max(q2.y1, q2.y2)) && (y >= min(q1.y1, q1.y2) && y <= max(q1.y1, q1.y2))){
		return 1; 
	}
			
	return 0;
}

int judge(qq q1,qq q2){
	double x = (q1.x1 + q1.x2) / 2;
	double y = (q1.y1 + q1.y2) / 2;
	double k = 1.0 / q1.k;
	if(q1.k == 0)k = 0;
	double b = y - k * x;
	double fx = (b - l3.b) / (k - l3.k);
	double fy = q2.k * fx + q2.b;
	l4.x1 = q1.x1, l4.y1 = q1.y1;
	l4.x2 = fx, l4.y2 = fy;
	l4.k = (l4.x1 - l4.x2) / (l4.y1 - l4.y2);
	l4.b = l4.y1 - l4.x1 * l4.k;
	l5.x1 = q1.x2, l5.y1 = q1.y2;
	l5.x2 = fx, l5.y2 = fy;
	l5.k = (l5.x1 - l5.x2) / (l5.y1 - l5.y2);
	l5.k = l5.y1 - l5.x1 *l5.k;
	if(is(l5,q2) || is(l4,q2)){
		return 1;
	}
	return 0;
}
int main(){
//	freopen("b.in","r",stdin);
//	freopen("b.out","w",stdout);
	scanf("%lf %lf %lf %lf", &l1.x1, &l1.y1, &l1.x2, &l1.y2);
	l1.k = (l1.y2 - l1.y1) / (l1.x2 - l1.x1);
	l1.b = l1.y1 - l1.k * l1.x1;
	if(l1.y1 == l1.y2)l1.isx = 1, l1.k = 0;
	if(l1.x1 == l1.x2)l1.isy=1, l1.k = 0, l1.b = 0;
	
	scanf("%lf %lf %lf %lf", &l2.x1, &l2.y1, &l2.x2, &l2.y2);
	l2.k = (l2.y2 - l2.y1) / (l2.x2 - l2.x1);
	l2.b = l2.y1 - l2.k * l2.x1;
	if(l2.y1 == l2.y2)l2.isx = 1, l2.k = 0;
	if(l2.x1 == l2.x2)l2.isy=1, l2.k = 0, l2.b = 0;
	
	scanf("%lf %lf %lf %lf", &l3.x1, &l3.y1, &l3.x2, &l3.y2);
	l3.k = (l3.y2 - l3.y1) / (l3.x2 - l3.x1);
	l3.b = l3.y1 - l3.k * l3.x1;
	if(l3.y1 == l3.y2)l3.isx = 1, l3.k = 0;
	if(l3.x1 == l3.x2)l3.isy=1, l3.k = 0, l3.b = 0;
	
	if(is(l1,l2)){
		if(judge(l1, l3) || is(l1, l3)){
			printf("NO");
			return 0;
		}
		else{
			printf("YES");
			return 0;
		}
	}
	
	if(is(l1,l3)){
		if(l1.k == l3.k){
			printf("YES");
			return 0;
		}
		else{
			printf("NO");
			return 0;
		}
	}
	else{
		if(judge(l1,l3)){
			printf("NO");
			return 0;
		}
		else{
			printf("YES");
			return 0;
		}
	}
}
