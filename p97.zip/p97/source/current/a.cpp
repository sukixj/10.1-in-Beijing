#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
int n;
char s[105000];
int chr[60];
int main() {
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	cin>>n;
	scanf("%s",&s);
	int ans=0;
	for(int ls=0;ls<n;ls++){
		for(int le=ls+1;le<n;le++){
			memset(chr,0,sizeof(chr));
			for(int i=ls;i<=le;i++){
				chr[s[i]-'a']++;
			}
			int maxl=0,minl=0x7fffffff;
			for(int i=0;i<=25;i++){
				maxl=max(chr[s[i]-'a'],maxl);
				if(chr[s[i]-'a']!=0)
				minl=min(chr[s[i]-'a'],minl);
			}
			ans=max(ans,maxl-minl);
		}
	}
	cout<<ans;
	return 0;
}
