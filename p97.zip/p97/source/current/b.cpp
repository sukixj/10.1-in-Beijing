#include <iostream>
#include <cstdio>
using namespace std;
double xa,ya,xb,yb,xw1,yw1,xw2,yw2,xm1,ym1,xm2,ym2;
double k,b,jx,jy;
void ffcc(double x1,double y1,double x2,double y2){
//	cout<<x1<<' '<<x2<<endl;
	k=(y1-y2)/(x1-x2);
//	cout<<k<<endl;
	b=-(k*x1)+y1;
}
double abss(double kkk){
	if(kkk>0) return kkk;
	else return -kkk;
}
double minn(double a,double b){
	if(a<b) return a;
	else return b;
}
double maxn(double a,double b){
	if(a>b) return a;
	else return b;
}
int jjdd(double k1,double b1,double k2,double b2){
	if(abss(k1-k2)<=0.0000001) return 0;
	jx=(b2-b1)/(k1-k2);
	jy=k1*jx+b1;
	return 1;
}
bool check(){
	ffcc(xa,ya,xb,yb);
	double kk1=k,bb1=b;
	ffcc(xm1,ym1,xm2,ym2);
	double kk2=k,bb2=b;
	bool v=jjdd(kk1,bb1,kk2,bb2);
	if(v){
		if(jx<=maxn(xa,xb)&&jx>=minn(xa,xb)&&jx<=maxn(xm1,xm2)&&jx>=minn(xm1,xm2)){
			return 1;
		}
	}
	return 0;
}
//cout<<"test "<<
int main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	cin>>xa>>ya>>xb>>yb>>xw1>>yw1>>xw2>>yw2>>xm1>>ym1>>xm2>>ym2;
//	cout<<xa<<ya<<xb<<yb<<xw1<<yw1<<xw2<<yw2<<xm1<<ym1<<xm2<<ym2<<endl;
	if(xw1==xw2) xw2+=0.0000001;
	if(xm1==xm2) xm2+=0.0000001;
	if(xa==xb) xb+=0.0000001;
	if(check()) {
		cout<<"NO";
		return 0;
	}
	double dcx,dcy;
	ffcc(xm1,ym1,xm2,ym2);
	dcx=double(2*yb-k*xb-2*b+xb/k)/(k+1/k);
	dcy=yb-(1/k)*(dcx-xb);
//	cout<<"test "<<(xb-xa)/(yb-ya)<<' '<<dcy<<endl;
	double mk=k,mb=b;
	ffcc(dcx,dcy,xa,ya);
	double hk=k,hb=b;
	jjdd(mk,mb,hk,hb);
	double mjx=jx,mjy=jy;
	ffcc(xw1,yw1,xw2,yw2);
	double kw=k,bw=b;
	ffcc(xa,ya,mjx,mjy);
	double ka=k,ba=b;
	ffcc(xb,yb,mjx,mjy);
	double kb=k,bb=b;
	int res=1;
	res=jjdd(ka,ba,kw,bw);
	if(res!=0){
		if(jx<=maxn(xw1,xw2)&&jx>=minn(xw1,xw2)&&jx<=maxn(xa,mjx)&&jx>=minn(xa,mjx)){
			cout<<"NO";
			return 0;
		}
	}
	res=1;
	res=jjdd(kb,bb,kw,bw);
	if(res!=0){
//		cout<<jx<<endl;
		if(jx<=maxn(xw1,xw2)&&jx>=minn(xw1,xw2)&&jx<=maxn(xb,mjx)&&jx>=minn(xb,mjx)){
			cout<<"NO";
			return 0;
		}
	}
	cout<<"YES";
	return 0;
}
