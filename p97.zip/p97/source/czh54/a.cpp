#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,ans=0;
char str[1020];
int letter[27],mx=0,mi=2000;
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	cin>>n;
	for (int i=1;i<=n;i++)	scanf("%c",&str[i]);
	memset(letter,0,sizeof(letter));
	if (n<=2)
		printf("0");
	else
	{
		for (int i=3;i<=n;i++)
		{
			for (int j=1;j<=n-i+1;j++)
			{
				for (int k=j;k<=j+i-1;k++)
				{
					int save;
					save=str[k]-96;
					letter[save]++;
				}
				for (int k=1;k<=26;k++)
				{
					if (letter[k]>mx) mx=letter[k];
					if (letter[k]!=0&&letter[k]<mi) mi=letter[k];
				} 
				if (mx-mi>ans) ans=mx-mi;
				mx=0;mi=2000;memset(letter,0,sizeof(letter));
			}
		}
		printf("%d",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
