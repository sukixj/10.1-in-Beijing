#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<ctime>
using namespace std;
int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	srand(time(0));
	cout<<rand()%10+1<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
