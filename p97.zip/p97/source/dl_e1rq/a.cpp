#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#include<map>
using namespace std;
template<class T>void read(T &x)
{
	int f = 0;
	x = 0;
	char ch = getchar();
	while(ch < '0' || ch >'9')
	  {
	  	f |= (ch == '-');
	  	ch = getchar();
	  }
	while(ch >= '0' && ch <='9')
	  {
	  	x = (x << 1) + (x << 3) + (ch ^ 48);
	  	ch = getchar();
	  }
	x = f? -x : x;
}
void write(int x)
{
	if(x < 0)
	  {
	  	putchar('-');
	  	x = -x;
	  }
	if(x > 9)
	  {
	  	write(x / 10);
	  }
	putchar(x % 10 + '0');
}
string s;
int a[28];
int n;
int maxx()
{
	int maxn = -1;
	for(int i = 1; i <= 26; i++)
	  {
	  	if(a[i] > maxn)  maxn = a[i];
	  }
	return maxn;
}
int minn()
{
	int maxn = 1000007;
	for(int i = 1; i <= 26; i++)
	  {
	  	if(a[i] != 0)
	  	if(a[i] < maxn)  maxn = a[i];
	  }
	if(maxn == 1000007) return 0;
	return maxn;
}
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	read(n);
	int t;
	int nmax = 0;
	cin >> s;
	for(int i = 0; i < n; i++)
	  {
	  	for(int j = 0; j < i; j++)
	  	  {
	  	  	  memset(a, 0, sizeof(a));
	  	  	  for(int k = j; k <= i; k++)
	  	  	    {
	  	  	    	  a[(int)s[k] - 96]++;
				}
			  t = minn();
			  if(t != 0)
			    {
			        nmax = max(maxx() - t, nmax);
				}
		  }
	  }
	write(nmax);
	fclose(stdin);fclose(stdout);
	return 0;
}
