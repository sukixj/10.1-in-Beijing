#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#include<map>
using namespace std;
template<class T>void read(T &x)
{
	int f = 0;
	x = 0;
	char ch = getchar();
	while(ch < '0' || ch >'9')
	  {
	  	f |= (ch == '-');
	  	ch = getchar();
	  }
	while(ch >= '0' && ch <='9')
	  {
	  	x = (x << 1) + (x << 3) + (ch ^ 48);
	  	ch = getchar();
	  }
	x = f? -x : x;
}
void write(int x)
{
	if(x < 0)
	  {
	  	putchar('-');
	  	x = -x;
	  }
	if(x > 9)
	  {
	  	write(x / 10);
	  }
	putchar(x % 10 + '0');
}


int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	
	fclose(stdin);fclose(stdout);
}
