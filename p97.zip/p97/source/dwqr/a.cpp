#include <cstdio>
#define N 1000005

template<typename S> inline S max(S a,S b) {return a>b?a:b;}
template<typename Y> inline Y min(Y a,Y b) {return a>b?b:a;}
int n,sum[26][N],ans;
int Main()
{
    freopen("a.in","r",stdin);
    freopen("a.out","w",stdout);
    scanf("%d",&n);
    char ch=getchar();
    for(int i=1;i<=n;++i)
    {
    	ch=getchar();
    	sum[ch-'a'+1][i]=sum[ch-'a'+1][i-1]+1;
    	for(int j=1;j<=26;++j)
    	 if(j!=ch-'a'+1) sum[j][i]=sum[j][i-1];
	}
	for(int i=1;i<=n;++i)
	 for(int j=i;j<=n;++j)
	 {
	 	int maxn=0,minn=0x3f3f3f3f;
	 	for(int k=1;k<=26;++k)
	 	 if(sum[k][j]-sum[k][i-1]>0) maxn=max(maxn,sum[k][j]-sum[k][i-1]),minn=min(minn,sum[k][j]-sum[k][i-1]);
	 	ans=max(maxn-minn,ans);
	 }
	printf("%d\n",ans);
    return 0;
    fclose(stdin);
    fclose(stdout);
}
int sb=Main();
int main(int argc,char *argv[])
{;}
