#include <iostream>
#define op operator

using namespace std;

const double eps = 1e-9;
int sgn(double a,double b=0)
{
	a-=b;
	return (a>eps)-(a<-eps);
}
struct node
{
	double x, y;
	void r() { cin>>x>>y;}
	node op-(node p)
	{
		return(node){x-p.x, y-p.y};
	}
	node op+(node p)
	{
		return(node){x+p.x, y+p.y};
	}
	node op*(double d)
	{
		return(node){x*d, y*d};
	}
	double dot(node p)
	{
		return x*p.x+y*p.y;
	}
	double cross(node p)
	{
		return x*p.y-y*p.x;
	}
	node proj(node a, node b)
	{
		double s=(*this - a).dot(b-a)/(b-a).dot(b-a);
		return a+(b-a)*s;
	}
};
double xmul(node a,node b,node c)
{
	return (b-a).cross(c-a);
}
bool judge1(node a,node b,node p,node q)
{
	if(sgn(xmul(a, b, p))*sgn(xmul(a, b, q))>=0) return false;
	double t=(p-a).cross(q-p)/(b-a).cross(q-p);
	return sgn(t)>0&&sgn(t, 1)<0;
}

bool judge2(node a,node b,node p,node q)
{
	if(sgn(xmul(a, b, p))*sgn(xmul(a, b, q))>0) return false;
	if(sgn((b-a).cross(q-p))==0)
	{
		double s=(p-a).dot(b-a);
		double t=(q-a).dot(b-a);
		if(s>t) swap(s,t);
		if(sgn(s,1)>0||sgn(t)<0) return false;
		return true;
	}
	double t=(p-a).cross(q-p)/(b-a).cross(q-p);
	return sgn(t)>0&&sgn(t, 1)<0;
}

int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	node p1, p2, w1, w2, m1, m2;
	p1.r();p2.r();
	w1.r();p2.r();
	m1.r();m2.r();
	if((!judge2(p1,p2,m1,m2)||sgn((m2-m1).cross(p2-p1))==0)&&!judge2(p1,p2,w1,w2)) cout<<"YES\n";
	else if(sgn(xmul(m1, m2, p1))*sgn(xmul(m1, m2, p2))>0)
	{
		node proj=p1.proj(m1, m2);
		node sym=proj+proj-p1;
		double t=(sym-m1).cross(p2-sym)/(m2-m1).cross(p2-sym);
		node ref=m1+(m2-m1)*t;
		if(sgn(t)>=0&&sgn(t, 1)<=0&&!judge2(p1,ref,w1,w2)&&!judge2(ref,p2,w1,w2)) cout<<"YES\n";
		else cout<<"NO\n";
	}
	else cout<<"NO\n";
	return 0;
	fclose(stdin);
	fclose(stdout);
}
