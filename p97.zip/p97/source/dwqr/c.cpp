#include <algorithm>
#include <cstdlib>
#include <cstdio>
#include <ctime>

using namespace std;
int ans=0x3f3f3f3f,num,x,y,col[3][3][5],fx[5]={1,-1,0,0},fy[5]={0,0,-1,1};
bool judge()
{
	return true;
}
int Main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	srand(time(NULL));
	for(int i=1;i<=3;++i)
	{
		char str[6];
		for(int j=1;j<=3;++j)
		{
			scanf("%s",str);
			num+=str[4]-'0';
			if(str[4]-'0'==1) x=i,y=j;
			for(int k=0;k<5;++k)
			{
				if(str[k]=='R') col[i][j][1]=1;
				else if(str[k]=='G') col[i][j][2]=2;
				else if(str[k]=='B') col[i][j][3]=3;
				else if(str[k]=='O') col[i][j][4]=4;
			}
		}
	}
	printf("%d",rand()%6*6*6);
	return 0;
	fclose(stdin);
	fclose(stdout);
}
int sb=Main();
int main(int argc,char *argv[]){;}
