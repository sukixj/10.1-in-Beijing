#include<cstdio>
#include<string>
#include<cstring>
#include<iostream>
#include<algorithm>
#define R register
#define inf 707406378
using namespace std;

inline void in(int &x){
	static int ch; static bool flag;
	for(flag=0,ch=getchar(); ch>'9'||ch<'0'; ch=getchar())flag|= ch=='-';
	for(x=0;isdigit(ch);ch=getchar())x=(x<<1)+(x<<3)+ ch-48;
	x= flag?-x:x;
}

inline void write(int x){
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+48);
}

int n;
char s[1000005];
int cnt[28];
int ans;

inline int dy(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	in(n);
	scanf("%s",s+1);
	for(int i=1;i<n;++i)
		for(int j=i+2;j<=n;++j){
			R int maxn=0,minn=inf;
			for(int k=i;k<=j;++k)cnt[s[k]-'a']++;
			R int tot=j-i+1;
			for(int k=0;k<26 && tot;++k){
				if(!cnt[k])continue;
				if(cnt[k]>maxn)maxn=cnt[k];
				if(cnt[k]<minn)minn=cnt[k];
				tot-=cnt[k];
				cnt[k]=0;
			}
			ans=max(ans,maxn-minn);
		}
	write(ans);
}

int QAQ = dy();

int main(){;}
