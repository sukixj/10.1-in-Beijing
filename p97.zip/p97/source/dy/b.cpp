#include<cstdio>
#include<string>
#include<cstring>
#include<iostream>
#include<algorithm>
#define R register
#define inf 707406378
using namespace std;

inline void in(int &x){
	static int ch; static bool flag;
	for(flag=0,ch=getchar(); ch>'9'||ch<'0'; ch=getchar())flag|= ch=='-';
	for(x=0;isdigit(ch);ch=getchar())x=(x<<1)+(x<<3)+ ch-48;
	x= flag?-x:x;
}

int xv,yv;
int xp,yp;
int xw1,xw2,yw1,yw2;
int xm1,xm2,ym1,ym2;

inline int dy(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	in(xv),in(yv);
	in(xp),in(yp);
	in(xw1),in(yw1),in(xw2),in(yw2);
	in(xm1),in(ym1),in(xm2),in(ym2);
	double km=(ym2-ym1)*1.0/(xm2-xm1);
	double bm=ym2-km*xm2;
//	printf("YES");
	
	
	
	R double kw=(yw2-yw1)*1.0/(xw2-xw1);
	R double bw=yw2-kw*xw2;
	R double kr=(yv-yp)*1.0/(xv-xp);
	R double br=yv-kr*xv;
	R double jx=(br-bw)*1.0/(kr-kw);
	R double jy=kr*jx+br;
	if(jx>=min(xw1,xw2) && jx<=max(xw1,xw2) && jy>=min(yw1,yw2) && jy<=max(yw1,yw2))
		if(jx>=min(xv,xp) && jx<=max(xv,xp) && jy>=min(yv,yp) && jy<=max(yv,yp))
			printf("NO"),exit(0);
	printf("YES");
}

int QAQ = dy();

int main(){;}
