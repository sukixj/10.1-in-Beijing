#include<cstdio>
#include<string>
#include<cstring>
#include<iostream>
#include<algorithm>
#define R register
#define inf 707406378
using namespace std;

inline void write(int x){
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar(x%10+48);
}

int bh[4][4]={0,0,0,0,
              0,1,2,3,
			  0,4,5,6,
			  0,7,8,9};
char ss[11][7];
int s[11][7];
int t[4][7];
int cnt[6];

bool vis[4][4][6];
int cnt_check[6];
inline void Dfs(int x,int y,int num,int col){
	vis[x][y][num]=1;
	cnt_check[col]++;
	if(!num){
		if(!vis[x][y][2] && s[bh[x][y]][2]==col)Dfs(x,y,2,col);
		if(!vis[x][y][3] && s[bh[x][y]][3]==col)Dfs(x,y,3,col);
		if(bh[x-1][y] && !vis[x-1][y][1] && s[bh[x-1][y]][1]==col)Dfs(x-1,y,1,col);
		return;
	}
	if(num==1){
		if(!vis[x][y][2] && s[bh[x][y]][2]==col)Dfs(x,y,2,col);
		if(!vis[x][y][3] && s[bh[x][y]][3]==col)Dfs(x,y,3,col);
		if(bh[x-1][y] && !vis[x+1][y][0] && s[bh[x+1][y]][0]==col)Dfs(x+1,y,0,col);
		return;
	}
	if(num==2){
		if(!vis[x][y][1] && s[bh[x][y]][1]==col)Dfs(x,y,1,col);
		if(!vis[x][y][0] && s[bh[x][y]][0]==col)Dfs(x,y,0,col);
		if(bh[x][y-1] && !vis[x][y-1][3] && s[bh[x][y-1]][3]==col)Dfs(x,y-1,3,col);
		return;
	}
	if(num==3){
		if(!vis[x][y][0] && s[bh[x][y]][0]==col)Dfs(x,y,0,col);
		if(!vis[x][y][1] && s[bh[x][y]][1]==col)Dfs(x,y,1,col);
		if(bh[x][y+1] && !vis[x][y+1][2] && s[bh[x][y+1]][2]==col)Dfs(x,y+1,2,col);
		return;
	}
}

inline bool check(){
	for(int i=0;i<5;++i)cnt_check[i]=0;
	for(int i=1;i<4;++i)
		for(int j=1;j<4;++j)
			for(int k=0;k<5;++k)vis[i][j][k]=0;
	for(int i=1;i<4;++i)
		for(int j=1;j<4;++j)
			for(int k=0;k<5;++k)
				if(!vis[i][j][k]){
					R char d=s[bh[i][j]][k];
					R int dd;
					if(d=='R')dd=0;
					else if(d=='G')dd=1;
					else if(d=='B')dd=2;
					else dd=3;
					Dfs(i,j,k,dd);
					if(cnt_check[dd]!=cnt[dd])return 0;
				}
	return 1;
}

int no,No[5];
inline void dfs(int step){
	for(int hang=1;hang<4;++hang){
		no=0;
		for(int i=1;i<3;++i){
			for(int j=1;j<4;++j)t[i][j]=s[bh[hang][i]][j];
			if(t[i][4])No[++no]=i;
		}
		if(no>=2)continue;
		else if(!no){
			for(int j=0;j<4;++j){
				s[bh[hang][1]][j]=t[2][j];
				s[bh[hang][2]][j]=t[3][j];
				s[bh[hang][3]][j]=t[1][j];
			}
			if(check())write(step),exit(0);
			dfs(step+1);
			for(int j=0;j<4;++j){
				s[bh[hang][1]][j]=t[3][j];
				s[bh[hang][2]][j]=t[1][j];
				s[bh[hang][3]][j]=t[2][j];
			}
			if(check())write(step),exit(0);
			dfs(step+1);
			for(int i=1;i<=3;++i)
				for(int j=0;j<5;++j)s[bh[hang][i]][j]=t[i][j];
		}
		else {
			R int fl;
			if(No[1]!=1 && No[2]!=1){
				for(int j=0;j<4;++j){
					s[bh[hang][2]][j]=t[3][j];
					s[bh[hang][3]][j]=t[2][j];
				}
				fl=1;
			}
			else if(No[1]!=2 && No[2]!=2){
				for(int j=0;j<4;++j){
					s[bh[hang][1]][j]=t[3][j];
					s[bh[hang][3]][j]=t[1][j];
				}
				fl=2;
			}
			else {
				for(int j=0;j<4;++j){
					s[bh[hang][1]][j]=t[2][j];
					s[bh[hang][2]][j]=t[1][j];
				}
				fl=3;
			}
			if(check())write(step),exit(0);
			dfs(step+1);
			for(int i=1;i<=3;++i)
				for(int j=1;j<5;++j)s[bh[hang][i]][j]=t[i][j];
		}
	}
	
	for(int lie=1;lie<4;++lie){
		no=0;
		for(int i=1;i<3;++i){
			for(int j=1;j<4;++j)t[i][j]=s[bh[i][lie]][j];
			if(t[i][4])No[++no]=i;
		}
		if(no>=2)continue;
		else if(!no){
			for(int j=0;j<4;++j){
				s[bh[1][lie]][j]=t[2][j];
				s[bh[2][lie]][j]=t[3][j];
				s[bh[3][lie]][j]=t[1][j];
			}
			if(check())write(step),exit(0);
			dfs(step+1);
			for(int j=0;j<4;++j){
				s[bh[1][lie]][j]=t[3][j];
				s[bh[2][lie]][j]=t[1][j];
				s[bh[3][lie]][j]=t[2][j];
			}
			if(check())write(step),exit(0);
			dfs(step+1);
			for(int i=1;i<=3;++i)
				for(int j=0;j<5;++j)s[bh[i][lie]][j]=t[i][j];
		}
		else {
			R int fl;
			if(No[1]!=1 && No[2]!=1){
				for(int j=0;j<4;++j){
					s[bh[2][lie]][j]=t[3][j];
					s[bh[3][lie]][j]=t[2][j];
				}
				fl=1;
			}
			else if(No[1]!=2 && No[2]!=2){
				for(int j=0;j<4;++j){
					s[bh[1][lie]][j]=t[3][j];
					s[bh[3][lie]][j]=t[1][j];
				}
				fl=2;
			}
			else {
				for(int j=0;j<4;++j){
					s[bh[1][lie]][j]=t[2][j];
					s[bh[2][lie]][j]=t[1][j];
				}
				fl=3;
			}
			if(check())write(step),exit(0);
			dfs(step+1);
			for(int i=1;i<=3;++i)
				for(int j=0;j<5;++j)s[bh[i][lie]][j]=t[i][j];
		}
	}
}


inline int dy(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	for(int i=1;i<10;++i){
		scanf("%s",ss[i]);
		if(ss[i][4]=='1')s[i][4]=1;
		for(int j=0;j<4;++j)
			if(ss[i][j]=='R')cnt[0]++;
			else if(ss[i][j]=='G')s[i][j]=1,cnt[1]++;
			else if(ss[i][j]=='B')s[i][j]=2,cnt[2]++;
			else s[i][j]=3,cnt[3]++;
	}
	dfs(1);
}

int QAQ = dy();

int main(){;}
