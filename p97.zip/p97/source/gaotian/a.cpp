#include <iostream>
#include <cstdio>
#include <algorithm>
#include <string>
#include <string.h>
#include <memory.h>
#include <fstream>

using namespace std;
#define xh(i,l,r) for(int i = l; i <= r; i++)
const int INF = 0x3f3f3f3f;
char a[1000005] = {};
int cnt[1008][30] = {};
int f[30][30] = {};
int b[30] = {};
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	int n;
	scanf("%d",&n);
	scanf("%s",a);
	if(n == 1)
	{
		printf("0");
		return 0;
	}
	if(n <= 1000)
	{
		xh(i,0,n-1)
		{
			xh(j,1,26)
			{
				cnt[i+1][j] = cnt[i][j];
			}
			cnt[i+1][a[i]-'a'+1]++;
		}
		int ans = 0;
		xh(i,0,n)
		{
			xh(j,i+1,n)
			{
				int m1 = 0;
				int m2 = INF;
				xh(k,1,26)
				{
					int t = cnt[j][k]-cnt[i][k];
					if(t)
					{
						m1 = max(m1,t);
						m2 = min(m2,t);
					}
				}
				ans = max(m1-m2,ans);
			}
		}
		printf("%d",ans);
	}
	else
	{
		int ans = 0;
		int cnt = 0;
		int c = 1;
		memset(b,0x3f,sizeof(b));
		xh(i,0,n-1)
		{
			if(b[a[i]-'a'+1] == INF)
				b[a[i]-'a'+1] = i;
			if(i && a[i] == a[i-1])
			{
				cnt++;
				c = max(c,cnt);
			}
			else
				cnt = 1;
		}
		xh(i,0,n-1)
		{
			int t = a[i]-'a'+1;
			xh(j,1,26)
			{
				if(j!=t && i >= b[j])
				{
					f[t][j] = f[t][j]+1;
					f[j][t] = max(0,f[j][t]-1);
					ans = max(f[t][j],ans);
				}
			}
		}
		printf("%d",max(ans,c-1));
	}
	return 0;
}
