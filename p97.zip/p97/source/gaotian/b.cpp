#include <iostream>
#include <cstdio>
#include <algorithm>
#include <string>
#include <cmath>
#include <string.h>
#include <memory.h>
#include <fstream>

using namespace std;
#define xh(i,l,r) for(int i = l; i <= r; i++)
const int INF = 0x3f3f3f3f;
const int e = 0.00000001;
bool b1 = 0;
bool b2 = 0;
int jiao(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4)
{
	if(x2 == x1 || x4 == x3)
		return 4;
	double k1 = (y2-y1)/(x2-x1);
	double k2 = (y4-y3)/(x4-x3);
	if(abs(k1-k2)>e)
	{
		double x = (k1*x2-k2*x4+y4-y2)/(k1-k2);
		if(x-max(x1,x2)<e && min(x1,x2)-x<e && x-max(x3,x4)<e && min(x3,x4)-x<e)
			return 1;
		else
			return 0;
	}
	else
	{
		return 3;
	}
}
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	double xa,ya,xq,yq,xw1,yw1,xw2,yw2,xm1,ym1,xm2,ym2;
	scanf("%lf%lf%lf%f%lf%lf%lf%lf%lf%lf%lf%lf",
			&xa,&ya,&xq,&yq,&xw1,&yw1,&xw2,&yw2,&xm1,&ym1,&xm2,&ym2);
	if(jiao(xa,ya,xq,yq,xw1,yw1,xw2,yw2)!=1)
		printf("YES");
	else if(jiao(xa,ya,xq,yq,xm1,ym1,xm2,ym2)==1)
		printf("NO");
	else if(jiao(xa,ya,xq,yq,xm1,ym1,xm2,ym2) == 3)
		printf("YES");
	else if(jiao(xa,ya,xq,yq,xw1,yw1,xw2,yw2)==3)
		printf("NO");
	else
		printf("NO");
	return 0;
}
