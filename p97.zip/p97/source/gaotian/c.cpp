#include <iostream>
#include <cstdio>
#include <algorithm>
#include <string>
#include <string.h>
#include <memory.h>
#include <fstream>

using namespace std;
#define xh(i,l,r) for(int i = l; i <= r; i++)
const int INF = 0x3f3f3f3f;
int f[30][30] = {};
int b[30] = {};
int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	xh(i,1,9)
	{
		char t[10];
		scanf("%s",t);
	}
	cout << 10;
	return 0;
}
