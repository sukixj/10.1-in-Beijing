#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<map>
#include<ctime>
using namespace std;
map <char,int> a;
string s;
int n;
int maxn=0,minn=100000000;
int ans=0;
string c;
clock_t st,et;
void work()
{
	srand(time(NULL));
	st=clock();
	int l,len;
	while(double(et-st)/CLOCKS_PER_SEC<0.9)
	{
		l=rand()%n;
		len=rand()%(n-l);
		c=s.substr(l,len);
		for(int p=0;p<len;p++)
		a[c[p]]++;
		for(char k='a';k<='z';k++)
		{
			if(maxn<a[k])
			maxn=a[k];
			if(minn>a[k]&&a[k]!=0)
			minn=a[k];
		}
		a.erase(a.begin(),a.end());
		ans=max(maxn-minn,ans);
		maxn=0;minn=354357321;
		et=clock();
	}
	cout<<ans;
}
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	cin>>n;
	cin>>s;
	st=clock();
	if(n<=150)
	{
		for(int i=0;i<n;i++)
		{
			for(int j=1;j<n-i;j++)
			{
				c=s.substr(i,j);
				for(int p=0;p<j;p++)
				a[c[p]]++;
				for(char k='a';k<='z';k++)
				{
					if(maxn<a[k])
					maxn=a[k];
					if(minn>a[k]&&a[k]!=0)
					minn=a[k];
				}
				a.erase(a.begin(),a.end());
				ans=max(maxn-minn,ans);
				maxn=0;minn=354357321;
				et=clock();
				if(double(et-st)/CLOCKS_PER_SEC>0.9)
				{
					cout<<ans;
					return 0;
				}
			}
		}
		cout<<ans;
	}
	else
	work();
	return 0;
}
