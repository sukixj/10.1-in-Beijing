#include<iostream>
#include<cstdio>
#include<iomanip>
#include<map>
#include<set>
#include<algorithm>
#include<ctime>
#include<cstring>
#include<string>
#include<queue>
#include<cctype>
#include<cmath>
#include<stack>
#include<vector>
#define N 200010
#define MOD 19360817
using namespace std;

string s;

int main()
{	
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	srand(time(NULL));
	cin>>s;
	if(s[0]=='G')
		cout<<5<<"\n";
	else
		cout<<rand()%30+1<<"\n";
	
	return 0;
}
