#include<cstdio>
#include<cctype>
#include<cstring>
using namespace std;
const int N=1e6+5,M=28;

int n,nxt[M],las[M],Min,Max,Ans,tc[M],tn[N];
char s[N];

inline int read()
{
	int now=0,f=1;register char c=getchar();
	for(;!isdigit(c);c=getchar())
	  if(c=='-') f=-1;
	for(;isdigit(c);now=now*10+c-'0',c=getchar());
	return f*now;
}

int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	n=read();
	scanf("%s",s);
//	for(int i=0;i<26;++i)
//		las[i]=n;
//	for(int i=n-1;i>=0;--i)
//	{
//		int id=s[i]-'a';
//		nxt[i]=las[id], las[id]=i;
//	}
	for(int i=0;i<n;++i)
	{
		Min=1,Max=0;
		memset(tn,0,sizeof tn);
		memset(tc,0,sizeof tc);
		for(int j=i;j<n;++j)
		{
			int id=s[j]-'a';
			--tn[tc[id]];
			++tc[id];
			++tn[tc[id]];
			if(!tn[Min] && tc[id])
				++Min;
			if(tc[id]<Min)
				Min=tc[id];
			if(tc[id]>Max)
				Max=tc[id];
			if(Max-Min>Ans)
				Ans=Max-Min;
//			printf("%d %d:%d %d\n",i,j,Max,Min);
		}
	
	}
	printf("%d",Ans);
	
	fclose(stdin);fclose(stdout);
	return 0;
}
