#include<cstdio>
#include<cctype>
#include<cstdlib>
#include<algorithm>
using namespace std;

int xa,xb,ya,yb;
bool f,vic,mr;
int read();
struct Edge
{
	int x1,y1,x2,y2;
	double k,b;
	inline int Init()
	{
		x1=read(),y1=read(),x2=read(),y2=read();
		if(!(x1-x2)||!(y1-y2))
			k=0.0;
		else
			k=(double)(y1-y2)/(x1-x2);
		b=(double)(y1-k*x1);
	}
	void Solve()
	{
		if(!(x1-x2)||!(y1-y2))
			k=0.0;
		else
			k=(double)(y1-y2)/(x1-x2);
		b=(double)(y1-k*x1);
	}
//	void Print()
//	{
//		printf("k:%.2lf  b:%.2lf\n",k,b);
//	}
}wall,mirr,peo,sym,l1,l2;//symmetry axis

inline int read()
{
	int now=0,f=1;register char c=getchar();
	for(;!isdigit(c);c=getchar())
	  if(c=='-') f=-1;
	for(;isdigit(c);now=now*10+c-'0',c=getchar());
	return f*now;
}

void Judge(Edge p,Edge w,double c1,double c2)
{
	if(p.k==w.k)
	{
		if(w.b==p.b)
		{
			printf("NO");
			exit(0);
		}
		else if((!(p.x1-p.x2)&&!(w.x1-w.x2))||(!(p.y1-p.y2)&&!(w.y1-w.y2)))
		{
			printf("YES");
			exit(0);
		}
	}
	double xj;
	if(!(w.b-p.b)||!(p.k-w.k))
		xj=0.0;
	else
		xj=(w.b-p.b)/(p.k-w.k);
//	printf("Jiao:%.2lf\n",xj);
	if(!f && ((xj>c1 && xj>c2)||(xj<c1 && xj<c2)))
	{//��ͨ�����ӣ�ֱ�ӿ� 
//		printf("Can directly.\n");
		printf("YES");
		exit(0);
	}
	if(f && !mr && p.k==w.k)
		return;
	if(f && !mr && !((xj>c1 && xj>c2)||(xj<c1 && xj<c2)))
	{
//		printf("Mirror prevent.\n");
		printf("NO");
		exit(0);
	}
	if(vic && (xj>c1 && xj>c2)||(xj<c1 && xj<c2))
	{
//		printf("Can by mirror\n");
		printf("YES");
		exit(0);
	}
	if(f && mr)
	{
		if((xj>=c1 && xj>=c2)||(xj<=c1 && xj<=c2))
			vic=1;
		else
		{
//			printf("%.2lf %.2lf %.2lf\n",xj,c1,c2);
//			printf("Wall prevents Mirror.\n");
			printf("NO");
			exit(0);
		}
	}
}
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
//	xa=read(),ya=read(),xb=read(),yb=read();
	peo.Init();
	xa=min(peo.x1,peo.x2), ya=min(peo.y1,peo.y2);
	xb=max(peo.x1,peo.x2), yb=max(peo.y1,peo.y2);
	wall.Init();//, wall.SolveKB();
	mirr.Init();//, mirr.SolveKB();
//	wall.Print();
//	mirr.Print();
	Judge(peo,wall,xa,xb);
	f=1;
	Judge(peo,mirr,xa,xb);
//	if(peo.k==wall.k)
//	{
//		if(wall.b==peo.b)
//			printf("NO");
//		else
//			printf("YES");
//		return 0;
//	}
//	double xj1=(wall.b-peo.b)/(peo.k-wall.k);
//	if((xj1>xa && xj1>xb)||(xj1<xa && xj1<xb))
//	{
//		printf("YES");
//		return 0;
//	}
	if(peo.b==mirr.b && peo.k==mirr.k)
	{//��ͨ�����Ӳ��У�ͬʱ�����뾵���غ� 
		printf("NO");
		return 0;
	}
	mr=1;
	sym.k= -mirr.k;
	double yt=(double)(ya+yb)/2,xt=(double)(xa+xb)/2;
	sym.b= (yt - sym.k*xt);
	double xj2=(mirr.b-sym.b)/(sym.k-mirr.k);
	double yj2=xj2*mirr.k+mirr.b;
	
	l1.x1=xa, l1.y1=ya, l1.x2=xj2, l1.y2=yj2;
	l1.Solve();
	Judge(l1,wall,xa,xj2);
	l2.x1=xj2, l2.y1=yj2, l2.x2=xb, l2.y2=yb;
	l2.Solve();
	Judge(l2,wall,xj2,xb);
	
	printf("NO");
	
	fclose(stdin);fclose(stdout);
	return 0;
}/*
-1 3
1 3
0 2 0 4
0 0 0 1
*/
