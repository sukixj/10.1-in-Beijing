#include<cstdio>
#include<cctype>
#include<algorithm>
using namespace std;

int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	
	printf("%d",rand()%666);
	
	fclose(stdin);fclose(stdout);
	return 0;
}
