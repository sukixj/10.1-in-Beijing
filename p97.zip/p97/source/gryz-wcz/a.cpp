#include<iostream>
#include<cstdiO>
#define N 1000005
using namespace std;

void read(int & s){
	char ch=getchar();
	for(;!isdigit(ch);ch=getchar());
	for(s=0;isdigit(ch);s=s*10+ch-'0',ch=getchar());
}

int n,ans;
int num;
char ch[N];
int maxl,minl;
int sum[27][N];

int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",ch+1);
	for(int i=1;i<=n;++i){
		for(int j=0;j<27;++j)
			sum[j][i]=sum[j][i-1];
		if(!islower(ch[i]))continue;
		else sum[ch[i]-'a'][i]+=1;
	}
	for(int i=1;i<=n;++i)
		for(int j=i;j<=n;++j){
			maxl=0,minl=0x3f3f3f3f;
			for(int k=0;k<26;++k){
				num=sum[k][j]-sum[k][i-1];
				if(!num)continue;
				maxl=max(maxl,num);
				minl=min(minl,num);
			}
			ans=max(ans,maxl-minl);
		}
	printf("%d",ans);
	return 0;
}
