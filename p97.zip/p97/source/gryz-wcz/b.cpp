#include<iostream>
#include<cstdio>
using namespace std;

struct point{
	double x,y;
}a,b;
struct segment{
	point p1,p2;
	int ve;
	double k,b;
	int isver,islev;
	segment(){
		k=b=isver=islev=0;
	}
}wall,mirror,line;
void read(int & s){
	char ch=getchar();
	for(;!isdigit(ch);ch=getchar());
	for(s=0;isdigit(ch);s=s*10+ch-'0',ch=getchar());
}
bool ans(bool TF){
	if(TF)printf("YES\n");
	else printf("NO\n");
	return TF;
}
double mult(point a, point b, point c){  
    return (a.x-c.x)*(b.y-c.y)-(b.x-c.x)*(a.y-c.y);  
}  
bool intersect(segment s1,segment s2){
	point aa(s1.p1);point bb(s1.p2);
	point cc(s2.p1);point dd(s2.p2);
    if(max(aa.x,bb.x)<min(cc.x,dd.x))return false;  
    if(max(aa.y,bb.y)<min(cc.y,dd.y))return false;  
    if(max(cc.x,dd.x)<min(aa.x,bb.x))return false;  
    if(max(cc.y,dd.y)<min(aa.y,bb.y))return false;  
    if(mult(cc,bb,aa)*mult(bb,dd,aa)<0)return false;  
    if(mult(aa,dd,cc)*mult(dd,bb,cc)<0)return false;
    return true;  
}  
void Analytic(segment s){
	int dx=s.p1.x-s.p2.x;
	int dy=s.p1.y-s.p2.y;
	if(!dy){
		s.k=0;s.b=s.p1.y;
		s.islev=1;
		return ;
	}
	if(!dx){
		s.isver=1;
		s.ve=s.p1.x;
		return ;
	}
	else {
		s.k=(double)dy/dx;
		s.b=(double)s.p1.y-s.k*s.p1.x;
	}
}
segment versegment(segment s,point s1){
	segment vers;
	if(s.islev){
		vers.isver=1;
		vers.ve=s1.x;
	}
	else if(s.isver){
		vers.islev=0;
		vers.b=s1.y;
	}
	else {
		double kkk=(double)1/s.k;
		double bbb=s1.y-kkk*s1.x;
		vers.k=kkk;
		vers.b=bbb;
	}
	vers.p1=s1;
	return vers;
}
point Qinter(segment s1,segment s2){
	double xxx=(s2.b-s1.b)/(s1.k-s2.k);
	double yyy=s1.k*xxx+s1.b;
	point s={xxx,yyy};
	return s;
}
int main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	int P[20];
	for(int i=1;i<=12;++i)read(P[i]);
	a={P[1],P[2]};
	b={P[3],P[4]};
	wall.p1={P[5],P[6]};
	wall.p2={P[7],P[8]};
	mirror.p1={P[9],P[10]};
	mirror.p2={P[11],P[12]};
	line.p1=a,line.p2=b;
	if(!intersect(wall,line)&&!intersect(mirror,line))return ans(1);
	else return ans(0);
	if(intersect(mirror,line))return ans(0);
	Analytic(mirror);
	segment Verm=versegment(mirror,a);
	point sss=Qinter(mirror,Verm);
	double dx=sss.x-a.x;
	double sssx=sss.x+dx;
	point syma={sssx,sssx*Verm.k+Verm.b};
	segment seg;
	seg.p1=syma;seg.p2=b;
	Analytic(seg);
	point im=Qinter(seg,mirror);
	segment as1,as2;
	as1.p1=a;as1.p2=im;
	as1.p2=b;as2.p2=im;
	if(intersect(as1,wall)||intersect(as2,wall))ans(0);
	return ans(1);
}
