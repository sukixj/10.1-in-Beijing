#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<ctime>
using namespace std;

int main(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
		srand(time(NULL));
	cout<<rand()%5+1;
	return 0;
}
