#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<map>
using namespace std;
int t[26];
char a[1000001];
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	int n,l,maxn=0,minn=1000000,maxa=0,maxp=0,minp=26;
	scanf("%d",&n);
	cin>>a;
	l=strlen(a);
	for(int k=3; k<=l; k++)
	{
		for(int j=0; k+j<l; j++)
		{
			memset(t,0,sizeof(t));
			maxn=0,minn=1000000,maxp=0,minp=26;
			for(int i=j; i<k+j; i++)
			{
				t[int(a[i]-97)]++;
				maxp=max(a[i]-97,maxp);
				minp=min(a[i]-97,minp);
			}
			for(int i=minp; i<=maxp; i++)
			{
				if(t[i]!=0)
				{
					maxn=max(maxn,t[i]);
					minn=min(minn,t[i]);
				}
			}
			maxa=max(maxa,maxn-minn);
		}
	}
	printf("%d",maxa);
	return 0;
}
