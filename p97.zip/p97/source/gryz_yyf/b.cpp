#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<map>
using namespace std;
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	cout<<"NO";
	return 0;
}
