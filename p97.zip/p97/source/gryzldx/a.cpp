#include<iostream>
#include<cstring>
#include<cstdio>
#define N 1000005
using namespace std;
int readin(){
	int now=0;bool flag=false;char c=getchar();
	while((c<'0'||c>'9')&&c!='-')c=getchar();
	while((c>='0'&&c<='9')||c=='-'){
		if(c=='-')flag=true;
		else now=now*10+c-'0';
	}
	return flag?-now:now;
}
int a[N][27];
int n;
int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	string ss;
	cin>>ss;
	for(int i=1;i<=n;i++){
		int tmp=ss[i-1]-'a'+1;
		for(int j=1;j<=26;j++){
			if(tmp==j)a[i][j]=a[i-1][j]+1;
			else a[i][j]=a[i-1][j];
		}
	}
	int ans=0;
	for(int i=1;i<=n;i++){
		for(int j=1;j<i-1;j++){
//			printf("%d~%d :",j,i);
			int maxx=0,minn=1e9;
			for(int k=1;k<=26;k++){
//				printf("%d-%d  ",a[i][k],a[j-1][k]);
				if(a[i][k]-a[j-1][k]>0)minn=min(minn,a[i][k]-a[j-1][k]);
				maxx=max(maxx,a[i][k]-a[j-1][k]);
			}
			ans=max(ans,maxx-minn);
//			printf("%d %d\n",maxx,minn);
		}
	}
	printf("%d\n",ans);
//	fclose(stdin);fclose(stdout);
	return 0;
}
