#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
struct node{
	double x,y;
}S,E,m1,m2,w1,w2;
//double S[2],E[2],m1[2],m2[2],
bool exist(node a,node b){
	if(a.x==b.x)return false;
}
inline void qswap(node a,node b){
	swap(a.x,b.x);swap(a.y,b.y);
}
inline double k(node a,node b){
	if(!exist(a,b))return 1e9;
	else return (b.y-a.y)/(b.x-a.x);
}
bool cross(node a,node b){
	if(k(a,w1)>k(w1,b)&&k(a,w2)>k(w2,b))return true;
	if(k(a,w1)<k(w1,b)&&k(a,w2)<k(w2,b))return true;
	return false;
}
int main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%lf%lf%lf%lf",&S.x,&S.y,&E.x,&E.y);
//	if(S.x==E.x)if(S.y>E.y)swap(S,E);
//	else if(S.x>E.x)swap(S,E);
	scanf("%lf%lf%lf%lf%lf%lf%lf%lf",&w1.x,&w1.y,&w2.x,&w2.y,&m1.x,&m1.y,&m2.x,&m2.y);
	if(cross(S,E)){
//		node aim;aim.x=
		printf("NO\n");
	}else{
		printf("YES\n");
	}
//	fclose(stdin);fclose(stdout);
	return 0;
}
