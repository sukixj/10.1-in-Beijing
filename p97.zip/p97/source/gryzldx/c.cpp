#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
#include<map>
using namespace std;
map<int,string>q;
map<string,bool>vis;
//char a[4][4][6];
struct node{
	int x,y;
	int up,down,left,right;
	int pos;
	bool mob;
}a[10];
bool line[3],row[3];
bool judge(int now){
	string ss=q[now];
	for(int i=1;i<=3;i++){
		for(int j=1;j<=3;j++){
			if(i>1){
				if(a[q[now][(i-1)*3+j-1]-'0'].up!=a[q[now][(i-2)*3+j-1]-'0'].down)return false;
			}
			if(j>1){
				if(a[q[now][(i-1)*3+j-1]-'0'].left!=a[q[now][(i-1)*3+j-1-1]-'0'].right)return false;
			}
			if(i<3){
				if(a[q[now][(i-1)*3+j-1]-'0'].down!=a[q[now][i*3+j-1]-'0'].up)return false;
			}
			if(j<3){
				if(a[q[now][(i-1)*3+j-1]-'0'].right!=a[q[now][(i-1)*3+j+1-1]-'0'].left)return false;
			}
		}
	}
	return true;
}
int step[100000];
int bfs(){
	int head=1,tail=1;
	while(head<=tail){
		if(judge(head)){
			return step[head];
		}
		memset(line,false,sizeof(line));
		memset(row,false,sizeof(row));
		for(int i=1;i<=3;i++){
			for(int j=1;j<=3;j++){
				if(a[q[head][(i-1)*3+j-1]-'0'].mob){
					line[i]=true;row[j]=true;
				}
			}
		}
		for(int i=1;i<=3;i++){
			if(line[i])	continue;
			string ss=q[head];
			for(int j=1;j<3;j++)swap(ss[(i-1)*3+j-1],ss[(i-1)*3+j]);
			if(!vis[ss])q[++tail]=ss,vis[ss]=true,step[tail]=step[head]+1;
			for(int j=3;j>1;j--)swap(ss[(i-1)*3+j-1],ss[(i-1)*3+j-1-1]);
			for(int j=3;j>1;j--)swap(ss[(i-1)*3+j-1],ss[(i-1)*3+j-1-1]);
			if(!vis[ss])q[++tail]=ss,vis[ss]=true,step[tail]=step[head]+1;
			for(int j=1;j<3;j++)swap(ss[(i-1)*3+j-1],ss[(i-1)*3+j]);
		}
		for(int j=1;j<=3;j++){
			if(row[j]) continue;
			string ss=q[head];
			for(int i=1;i<3;i++)swap(ss[(i-1)*3+j-1],ss[i*3+j-1]);
			if(!vis[ss])q[++tail]=ss,vis[ss]=true,step[tail]=step[head]+1;
			for(int i=3;i>1;i--)swap(ss[(i-1)*3+j-1],ss[(i-2)*3+j-1]);
			for(int i=3;i>1;i--)swap(ss[(i-1)*3+j-1],ss[(i-2)*3+j-1]);
			if(!vis[ss])q[++tail]=ss,vis[ss]=true,step[tail]=step[head]+1;
			for(int i=1;i<3;i++)swap(ss[(i-1)*3+j-1],ss[i*3+j-1]);
		}
	}
}
int main(){
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	for(int i=1;i<=3;i++){
		for(int j=1;j<=3;j++){
			string ss;
			cin>>ss;
			if(ss[4]-'0'==1){
				a[(i-1)*3+j].mob=false;
			}else{
				a[(i-1)*3+j].mob=true;
			} 
			a[(i-1)*3+j].up=ss[0];
			a[(i-1)*3+j].down=ss[1];
			a[(i-1)*3+j].left=ss[2];
			a[(i-1)*3+j].right=ss[3];
			a[(i-1)*3+j].x=i;
			a[(i-1)*3+j].y=j;
			a[(i-1)*3+j].pos=(i-1)*3+j;
		}
	}
	string ss="";
	for(int i=1;i<=3;i++){
		for(int j=1;j<=3;j++){
			ss+=a[(i-1)*3+j].pos+'0';
		}
	}
	vis[ss]=true;
	q[1]=ss;
	int ans=bfs();
	printf("%d\n",ans);
	return 0;
}
