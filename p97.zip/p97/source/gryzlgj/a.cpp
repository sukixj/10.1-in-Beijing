#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
const int MAXN=1001;
inline void read(int &n)
{
	char c=getchar();n=0;bool flag=0;
	while(c<'0'||c>'9')	c=='-'?flag=1,c=getchar():c=getchar();
	while(c>='0'&&c<='9')	n=n*10+c-48,c=getchar(); flag==1?n=-n:n=n;
}
string a;
int happen[MAXN];
int happenmax[MAXN][MAXN];
int happenmin[MAXN][MAXN];
int ans=0;
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	int meiyong;
	cin>>meiyong;
	cin>>a;
	for(int i=0;i<a.length();i++)
	{
		memset(happen,0,sizeof(happen));
		for(int j=i;j<a.length();j++)
		{
			int nowmax=0,nowmin=0x7fff;
			happen[a[j]]++;
			for(register int k=97;k<=122;k++)
			{
				if(happen[k]>nowmax)	nowmax=happen[k];
				if(happen[k]<nowmin&&happen[k])	nowmin=happen[k];
			}
			if(nowmax-nowmin>ans)	ans=nowmax-nowmin;
		}
	}
	printf("%d",ans);
	return 0;
}
