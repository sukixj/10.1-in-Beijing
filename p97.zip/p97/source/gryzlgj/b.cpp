#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#define Vector Point
using namespace std;
inline void read(int &n)
{
	char c=getchar();n=0;bool flag=0;
	while(c<'0'||c>'9')	c=='-'?flag=1,c=getchar():c=getchar();
	while(c>='0'&&c<='9')	n=n*10+c-48,c=getchar(); flag==1?n=-n:n=n;
}
const double PI=acos(-1);
const double eps=1e-10;
int dcmp(double x)    {return (fabs(x)<eps)?0:(x<0?-1:1);}
struct Point
{
    double x,y;
    Point(double x=0,double y=0):x(x),y(y){};
}pa,pb,qa,qb,ja,jb;
Vector operator + (Vector A,Vector B) {return Vector(A.x + B.x,A.y + B.y);}
Vector operator - (Vector A,Vector B) {return Vector(A.x - B.x,A.y - B.y);}
Vector operator * (Vector A,double P) {return Vector(A.x * P,A.y * P);}
Vector operator / (Vector A,double P) {return Vector(A.x / P,A.y / P);}
bool operator < (const Point &a,const Point &b){return a.x < b.x || (a.x == b.x && a.y < b.y);}
bool operator == (const Point &a,const Point &b){return dcmp(a.x - b.x)==0 && dcmp(a.y - b.y)==0;}

double Cross(Vector A,Vector B){return A.x * B.y-A.y * B.x;}
bool SPI(Point a1, Point a2, Point b1,Point b2)//�ж����߶��Ƿ��ཻ 
{
    double c1 = Cross(a2-a1,b1-a1) , c2 = Cross(a2-a1,b2-a1),
           c3 = Cross(b2-b1,a1-b1) , c4 = Cross(b2-b1,a2-b1);
    return dcmp(c1)*dcmp(c2)<0 && dcmp(c3)*dcmp(c4)<0;
}
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	cin>>pa.x>>pa.y>>pb.x>>pb.y>>qa.x>>qa.y>>qb.x>>qb.y>>ja.x>>ja.y>>jb.x>>jb.y;
	if(SPI(pa,pb,ja,jb))	{cout<<"NO";return 0;}// ���߱����ӷ��� 
	if(SPI(pa,pb,qa,qb)==0&&SPI(pa,pb,ja,jb)==0)	{cout<<"YES";return 0;}//��û��ס 
	if(pa.x>pb.x)	swap(pa,pb);
	if(ja.x>jb.x)	swap(ja,jb);
	if(SPI(pa,pb,qa,qb))// ǽ��ס������û��ס 
	{
		if( (pa.x<ja.x&&pa.x<jb.x) && (pb.x>ja.x&&pb.x>jb.x) )	{cout<<"NO";return 0;}
		if( (pa.y<ja.y&&pa.y<jb.y) && (pb.y>ja.y&&pb.y>jb.y) )	{cout<<"NO";return 0;}
		if(SPI(pa,ja,qa,qb)||SPI(pb,jb,qa,qb))	{cout<<"NO";return 0;}
	}
	cout<<"YES";
	return 0;
}
