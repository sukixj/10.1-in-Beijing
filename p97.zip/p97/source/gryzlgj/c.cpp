#include<cstdio>
#include<cstring>
#include<cmath>
#include<iostream>
#include<ctime>
#include<cstdlib>
#include<queue>
#include<map>
using namespace std;
inline void read(int &n)
{
	char c=getchar();n=0;bool flag=0;
	while(c<'0'||c>'9')	c=='-'?flag=1,c=getchar():c=getchar();
	while(c>='0'&&c<='9')	n=n*10+c-48,c=getchar(); flag==1?n=-n:n=n;
}
struct node
{
	int up,down,left,right,can;
	node(){	up=down=left=right=can=0;	}
};
struct JUMIAN
{
	node a[4][4];
	int step;
}fr;
int canhang[4],canlie[4];
map<string,bool>vis;
int VIS(JUMIAN p)
{
	string s;s.clear();
	for(int i=1;i<=3;i++)
		for(int j=1;j<=3;j++)
		{
			s+=(char)p.a[i][j].up;
			s+=(char)p.a[i][j].down;
			s+=(char)p.a[i][j].left;
			s+=(char)p.a[i][j].right;
			s+=(char)p.a[i][j].can;
		}
	if(vis[s]==1)	return 1;
	vis[s]=1; return 0;
}
void Input()
{
	for(int i=1;i<=3;i++)
		for(int j=1;j<=3;j++)
		{
			for(int k=1;k<=6;k++)
			{
				char c=getchar();int how=0;
				if(c=='R') how=1;	if(c=='G') how=2;
				if(c=='B') how=3;	if(c=='O') how=4;
				if(k==1)	fr.a[i][j].up=how;	if(k==2)	fr.a[i][j].down=how;
				if(k==3)	fr.a[i][j].left=how;	if(k==4)	fr.a[i][j].right=how;
				if(k==5)	fr.a[i][j].can=c=='0'?1:-1;
				if(fr.a[i][j].can==-1)	canhang[i]=1,canlie[j]=1;
			}
		}
}
int num[5];
JUMIAN vis2;
void dfs(int i,int j,int how,int color,JUMIAN p)
{
	// 1�� 2�� 3�� 4�� 
	if(how==1)
	{
		if(p.a[i-1][j].down==color)
			num[color]++,dfs(i-1,j,2,color,p);
	}
	if(how==2)
	{
		if(p.a[i+1][j].up==color)
			num[color]++,dfs(i+1,j,1,color,p);
	}
	if(how==3)
	{
		if(p.a[i][j-1].right==color)
			num[color]++,dfs(i,j-1,4,color,p);
	}
	if(how==4)
	{
		if(p.a[i][j+1].left==color)
			num[color]++,dfs(i,j+1,3,color,p);
	}
}
void pd(JUMIAN p)
{
	JUMIAN kong;
	vis2=kong;
	int vis3[5];
	memset(num,0,sizeof(num));
	for(int i=1;i<=3;i++)
	{
		for(int j=1;j<=3;j++)
		{
			if(vis3[p.a[i][j].up]==0)
				vis3[p.a[i][j].up]=1,dfs(i,j,1,p.a[i][j].up,p),num[p.a[i][j].up]++;
			if(vis3[p.a[i][j].down]==0)
				vis3[p.a[i][j].down]=1,dfs(i,j,2,p.a[i][j].down,p),num[p.a[i][j].down]++;
			if(vis3[p.a[i][j].left]==0)
				vis3[p.a[i][j].left]=1,dfs(i,j,3,p.a[i][j].left,p),num[p.a[i][j].left]++;
			if(vis3[p.a[i][j].right]==0)
				vis3[p.a[i][j].right]=1,dfs(i,j,4,p.a[i][j].right,p),num[p.a[i][j].right]++;
		}
	}
	int sum=0;
	for(int i=1;i<=4;i++)	sum+=num[i];
	if(sum==36)	
	{
		printf("%d",p.step);
		exit(0);
	}
}
void BFS()
{
	queue<JUMIAN>q;
	q.push(fr);
	fr.step=0;
	int hh=VIS(fr);
	while(q.size()!=0)
	{
		JUMIAN p=q.front();
		q.pop();
		if(p.a[1][3].down==4&&p.a[3][1].down==4&&p.a[1][3].up==4&&p.a[3][1].up==4&&p.a[1][3].left==4&&p.a[3][1].left==4&&p.a[1][3].right==4&&p.a[3][1].right==4)
		{
			cout<<1;
		}
		pd(p);
		for(int i=1;i<=3;i++)
		{
			if(canhang[i]==0)
			{
				JUMIAN nxt;nxt=p;
				nxt.step=p.step+1;
				nxt.a[i][1]=p.a[i][3];
				nxt.a[i][2]=p.a[i][1];
				nxt.a[i][3]=p.a[i][2];
				if(VIS(nxt)==0)	q.push(nxt);
				nxt.a[i][1]=p.a[i][2];
				nxt.a[i][2]=p.a[i][3];
				nxt.a[i][3]=p.a[i][1];
				if(VIS(nxt)==0)	q.push(nxt);
			}
		}
		for(int i=1;i<=3;i++)
		{
			if(canlie[i]==0)
			{
				JUMIAN nxt;nxt=p;
				nxt.a[1][i]=p.a[3][i];
				nxt.a[2][i]=p.a[1][i];
				nxt.a[3][i]=p.a[2][i];
				if(VIS(nxt)==0)	
					q.push(nxt);
				nxt.a[1][i]=p.a[2][i];
				nxt.a[2][i]=p.a[3][i];
				nxt.a[3][i]=p.a[1][i];
				if(VIS(nxt)==0)	q.push(nxt);
			}
		}
	}
}
int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	Input();
	BFS();
	cout<<8;
	return 0;
}
