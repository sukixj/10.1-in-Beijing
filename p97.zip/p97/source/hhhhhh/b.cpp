#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<cstdlib>
#include<algorithm>
using namespace std;
int x[8],y[8],xx,yy,xx2,yy2;
int k[10],b[10];//1r,2q,3j;
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
    for(int i=1;i<=3;i++)
	{
		scanf("%d%d%d%d",&x[i*2-1],&y[i*2-1],&x[i*2],&y[i*2]);
		if(x[i*2-1]>x[i*2]) {swap(x[i*2-1],x[i*2]),swap(y[i*2-1],y[i*2]);}
		if(x[i*2-1]!=x[i*2]) k[i]=(y[i*2-1]-y[i*2])/(x[i*2-1]-x[i*2]);
		else k[i]==0;
		b[i]=y[i*2-1]-x[i*2-1]*k[i];
	}
	if(k[1]==k[2])
	{
		if(x[2]<x[3]||x[4]<x[1])
		{
			printf("YES");
		    system("pause");
		    return 0;
	    }
	    else
	    {
	    	printf("NO");
	    	system("pause");
	    	return 0;
		}
	}
	xx2=(b[2]-b[1])/(k[1]-k[2]);//rqjd
	if(k[1]==k[3]&&k[1]==0)
	{
		printf("YES");
		system("pause");
		return 0;
	}
	if(k[1]!=k[3])
	{
	    xx=(b[3]-b[1])/(k[1]-k[3]);//rjjd
	    if(xx>=x[1]&&xx<=x[2]&&xx>=x[5]&&xx<=x[6]) //rjj
	    {
	        printf("NO");
		    system("pause");
	        return 0;
	    }	
    }    
	xx2=(b[2]-b[1])/(k[1]-k[2]);//rqjd
	if(xx2<x[1]||xx2>x[2]||xx2<x[3]||xx2>x[4]) 
	{
		printf("YES");
		system("pause");
		return 0;
	}
	else
	{
		int dis1,dis2;
		k[4]=-1/k[2];
		b[4]=y[1]-k[4]*x[1];//1rj
		xx=(b[4]-b[3])/(k[3]-k[4]);
		yy=k[4]*xx+b[4];
		dis1=abs(k[4]*x[1]-y[1]+b[4])/sqrt(k[4]*k[4]+1);
		b[5]=y[2]-k[4]*x[2];//1rj
		dis2=abs(k[4]*x[2]-y[2]+b[4])/sqrt(k[4]*k[4]+1);		
		xx2=(b[5]-b[3])/(k[3]-k[4]);
		yy2=k[4]*xx2+b[5];
		x[7]=min(xx,xx2)+(max(xx,xx2)-min(xx,xx2))*dis1/dis2;
		y[7]=x[7]*k[3]+b[3];
		int ak1,ak2,ab1,ab2,ax1,ax2;
		ak1=(y[7]-yy)/(x[7]-xx);
		ab1=y[7]-x[7]*ak1;		
		ak2=(y[7]-yy2)/(x[7]-xx2);
		ab2=y[7]-x[7]*ak2;
		ax1=(b[2]-ab1)/(ak1-k[2]);
		ax2=(b[2]-ab2)/(ak2-k[2]);
		if(x[7]<x[1]) swap(x[1],x[7]);
		if(x[7]<x[2]) swap(x[2],x[7]);
		if((ax1>=x[1]&&ax1<=x[7]&&ax1>=x[3]&&ax1<=x[4])||(ax2>=x[2]&&ax2<=x[7]&&ax2>=x[3]&&ax2<=x[4]))
		{
			printf("NO");
		    system("pause");
			return 0;
		}
		else 
		{
	        printf("YES");
			system("pause");		
			return 0;
	    }
	}
	
	
}

