#include <cstdio>
#include <cctype>

const int INF=0x3f3f3f3f;
const int MAXN=1000010;

int n,ans,mx,mn;

int sum[30][MAXN],p[MAXN];

char s[MAXN];

int hh() {
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",s+1);
	for(int i=1;i<=n;++i) {
		sum[s[i]-'a'][i]=sum[s[i]-'a'][i-1]+1;
		mx=-0x3f3f3f3f;mn=0x3f3f3f3f;
		for(int j=0;j<27;++j) 
			if(j!=s[i]-'a') sum[j][i]=sum[j][i-1];
	}
	for(int i=1;i<=n;++i) 
	  for(int j=i;j<=n;++j) {
	  	  mx=-INF;mn=INF;
		  for(int k=0;k<27;++k) {
	  		mx=mx>sum[k][j]-sum[k][i-1]?mx:sum[k][j]-sum[k][i-1];
	  		if(sum[k][j]-sum[j][i-1]!=0) mn=mn<sum[k][j]-sum[k][i-1]?mn:sum[k][j]-sum[k][i-1];
		  }
		ans=ans>mx-mn?ans:mx-mn;
	  } 
	printf("%d\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

int sb=hh();
int main(int argc,char**argv) {;}

