#include <cctype>
#include <cstdio>

int x1,y1,x2,y2;

int xw1,yw1,xw2,yw2,xm1,ym1,xm2,ym2;

int hh() {
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%d%d%d%d",&x1,&y1,&x2,&y2);
	scanf("%d%d%d%d",&xw1,&yw1,&xw2,&yw2);
	scanf("%d%d%d%d",&xm1,&ym1,&xm2,&ym2);
	int Y=(y2-y1),X=(x2-x1);
	int Xw=(xw2-xw1),Yw=(yw2-yw1);
	int Xm=(xm2-xm1),Ym=(ym2-ym1);
	if(y1==0&&y2==0) {
		if((yw1>0&&yw2>0)||(yw1<0&&yw2<0)) printf("YES\n");
		else {
			double l=(double)xw1-(double)yw1*Xw/Yw;
			if((xw1>xw2&&xw2>l)||(xw1<xw2&&xw2<l)) printf("Yes\n");
			else printf("NO\n");
		}
	}
	else {
		double k1,k2,k3;
		k1=(double)Y/X;
		k2=(double)Yw/Xw;
		k3=(double)Ym/Xm;
		if(k1==k3) printf("YES\n");
		else printf("NO\n");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

int sb=hh();
int main(int argc,char**argv) {;}
