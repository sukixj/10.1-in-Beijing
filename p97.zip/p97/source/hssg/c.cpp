#include <cctype>
#include <cstdio>
#include <cstring>

const int INF=0x3f3f3f3f;
const int MAXN=400000;

int n,m,cnt;

struct node {
	int m[5];
};
node re[3][3];

node que[MAXN][3][3];

int dx[]={1,0,-1,0};  
int dy[]={0,1,0,-1};  

int mx[10],my[10],hash[MAXN],color[5],c[10];

bool v[4][4][4];

char s[10];

inline int Hash(int *s,int l) {
	int num=0,t=1,Ss=1;
	for(int i=0;i<l;++i) {
		num+=s[i]*t;
		++Ss,t*=Ss;
	}
	return num;
}

inline int cal(char c) {
	if(c=='R') return 0;
	if(c=='G') return 1;
	if(c=='B') return 2;
	if(c=='O') return 3;
}

inline void zhuanhuan(node t[3][3]) {
	for(int i=0;i<3;++i)
	  for(int j=0;j<3;++j)
	    c[i*3+j]=t[i][j].m[4];
}

void DFS(node t[3][3],int x,int y,int z,int c) {
	if(v[x][y][z]) return;
	v[x][y][z]=true;
	if(t[x][y].m[(z+1)%4]==c) DFS(t,x,y,(z+1)%4,c);
	if(t[x][y].m[(z+3)%4]==c) DFS(t,x,y,(z+3)%4,c);
	int tx=x+dx[z],ty=y+dy[z];
	if(tx<0||tx>=3||y<0||ty>=3) return;
	if(t[tx][ty].m[(z+2)%4]==c) DFS(t,tx,ty,(z+2)%4,c);
}

bool judge(node t[3][3]) {
	memset(v,false,sizeof v);
	memset(color,0,sizeof color);
	for(int i=0;i<3;++i)
	  for(int j=0;j<3;++j)
	    for(int k=0;k<4;++k) {
	    	if(!v[i][j][k]) {
	    		if(color[t[i][j].m[k]]) return false;
	    		color[t[i][j].m[k]]=true;
	    		DFS(t,i,j,k,t[i][j].m[k]);
			}
		}
	return true;
}

void bfs() {
	memset(hash,INF,sizeof(hash));
	int head=0,tail=0;
	memcpy(que[++tail],re,sizeof re);
	hash[0] = 0;  
    node e[3][3],t[3][3];  
    while(head<tail)  
    {  
        memcpy(e,que[head++],sizeof(e));  
        zhuanhuan(e);  
        int ee = Hash(c,9);  
       // cout<<"ee= "<<ee<<endl;  
        //cout<<"can"<<endl;  
        int dd = hash[ee];  
        if(judge(e))  
        {  
            printf("%d\n",hash[ee]);  
           // cout<<"ok"<<endl;  
            break;  
        }  
  
        node tmp;  
        for(int i=0;i<3;i++)  
        if(mx[i]==0)  
        {  
            //cout<<" row"<<i<<endl;  
            memcpy(t,e,sizeof(e));  
            tmp = t[i][0];  
            t[i][0] = t[i][1];t[i][1] = t[i][2] ;t[i][2] = tmp;  
            zhuanhuan(t);  
            int tc = Hash(c,9);  
            //cout<<"tc="<<tc<<endl;  
            if(hash[tc]>dd+1)  
            {  
                hash[tc]= dd+1;  
                memcpy(que[tail++],t,sizeof(t));  
            }  
            memcpy(t,e,sizeof(e));  
            tmp = t[i][2];  
            t[i][2] = t[i][1];t[i][1] = t[i][0] ;t[i][0] = tmp;  
            zhuanhuan(t);  
            tc = Hash(c,9);  
            if(hash[tc]>dd+1)  
            {  
                hash[tc]= dd+1;  
                memcpy(que[tail++],t,sizeof(t));  
            }  
        }  
        for(int i=0;i<3;i++)  
        if(my[i]==0)  
        {  
            memcpy(t,e,sizeof(e));  
            tmp = t[0][i];  
            t[0][i] = t[1][i];t[1][i] = t[2][i] ;t[2][i] = tmp;  
            zhuanhuan(t);  
            int tc = Hash(c,9);  
            if(hash[tc]>dd+1)  
            {  
                hash[tc]= dd+1;  
                memcpy(que[tail++],t,sizeof(t));  
            }  
            memcpy(t,e,sizeof(e));  
            tmp = t[2][i];  
            t[2][i] = t[1][i];t[1][i] = t[0][i] ;t[0][i] = tmp;  
            zhuanhuan(t);  
            tc = Hash(c,9);  
            if(hash[tc]>dd+1)  
            {  
                hash[tc]= dd+1;  
                memcpy(que[tail++],t,sizeof(t));  
            }  
        }  
    }
}

int hh() {
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	scanf("%d",&n);
	for(int i=0;i<3;++i)
	  for(int j=0;j<3;++j) {
	  	scanf("%s",s);
	  	re[i][j].m[0]=cal(s[1]);
	  	re[i][j].m[1]=cal(s[3]);
	  	re[i][j].m[2]=cal(s[0]);
	  	re[i][j].m[3]=cal(s[2]);
	  	re[i][j].m[4]=++cnt;
	  	int t=s[4]='0';
	  	if(t==1) mx[i]=1,my[j]=1;
	  }
	bfs();
	fclose(stdin);
	fclose(stdout);
	return 0;
}

int sb=hh();
int main(int argc,char**argv) {;}
