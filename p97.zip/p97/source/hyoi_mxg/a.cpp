
#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;

void read(int &x){
	int f=1; x=0;char c=getchar();
	while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
	while(isdigit(c)){x=(x<<3)+(x<<1)+c-'0';c=getchar();}
	x*=f;
}

void out(int x){
	if(!x){putchar('0');return;}
	if(x<0){x=~x+1;putchar('-');}
	char c[30]={0};
    while(x)c[++c[0]]=x%10+48,x/=10;
    while(c[0])putchar(c[c[0]--]);
}

int i,j,k;
const int inf=1e6+29;
int a[inf][27],f[inf];
int n,cnt=0;
char ch;
int ans=-1,maxn=0,minn=0x7fffffff;

int query(int l,int r){
	int x=0,y=0x7fffffff;
	for(k=1;k<=26;k++){
		if(a[r][k]-a[l-1][k]==0)continue;
		x=max(x,a[r][k]-a[l-1][k]);
		
		y=min(y,a[r][k]-a[l-1][k]);
		
	}
	int ans=x-y;
	return ans;
}

int main(){

    freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	read(n);
	for(i=1;i<=n;i++){
		ch=getchar();
		for(j=i;j<=n;j++){
			a[j][ch-'a'+1]++;
		}
		maxn=max(maxn,a[i][ch-'a'+1]);
		minn=min(minn,a[i][ch-'a'+1]);
		if(ans!=maxn-minn){
			ans=maxn-minn;
			f[++cnt]=i;
		}
	}
	
	ans=0;
	
	
	for(i=1;i<=cnt;i++){
		for(j=i+1;j<=cnt;j++){
			ans=max(ans,query(f[i],f[j]));
		}
	}
	out(ans);
	

	return 0;
}

