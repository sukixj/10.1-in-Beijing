#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
using namespace std;






int main(){
	
	
    freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	printf("YES");
	
	return 0;
}

