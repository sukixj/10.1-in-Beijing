# include <cstdio>
# include <algorithm>
# include <cstring>
# include <cmath>
using namespace std;
# define N 28
# define M 100008
char b[M]={0};
int sum=0,all=0,max1=0,min1=0;
int main()
{
	//freopan("a.in","r",stdin);
	//freopen("a.in","w",stdout);
	int n=0;
	scanf("%d",&n);
	scanf("%s",b);
	/*for(int i=0;i<n;i++)
	{
		printf("%c",b[i]);
	}
	printf("\n");*/
	for(int i=0;i<n;i++)
	{
		for(int j=i;j<n;j++)
		{
			int a[N]={0};
			for(int k=i;k<=j;k++)
			{
				a[b[k]-'a'+1]++;
			}
			//printf("%d %d %d\n",a[1],a[2],a[3]);
			min1=100050;
			max1=0;
			for(int k=1;k<=26;k++)
			{
				if(a[k]>max1)
				{
					max1=a[k];
				}
				if(a[k]<min1&&a[k]!=0)
				{
					min1=a[k];
				}
			}
			sum=max1-min1;
			if(sum>all)
			{
				all=sum;
			}
			min1=0;
			max1=0;
		}
	}
	printf("%d",all);
	return 0;
}
