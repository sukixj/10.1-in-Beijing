# include <cstdio>
# include <cstring>
# include <cmath>
# include <algorithm>
using namespace std;
int main()
{
	double xv=0,yv=0;
	double xp=0,yp=0;
	double xw1=0,yw1=0,xw2=0,yw2=0;
	double xm1=0,ym1=0,xm2=0,ym2=0;
	double x=0,y=0,x1=0,y1=0;
	double k1=0,k2=0,k3=0,k4=0,b1=0,b2=0,b3=0,b4=0;
	scanf("%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf%lf",&xv,&yv,&xp,&yp,&xw1,&yw1,&xw2,&yw2,&xm1,&ym1,&xm2,&ym2);
	if(xv!=xp)
	{
		k1=(yv-yp)/(xv-xp);
	    b1=yp-k1*xp;
	}
	if(xw2!=xw1)
	{
	    k2=(yw2-yw1)/(xw2-xw1);
	    b2=yw1-k2*xw1; 
    } 
	if(xm2!=xm1)
    {
	    k3=(ym2-ym1)/(xm2-xm1);
	    b3=ym1-k3*xm1;
	}
	x=(b2-b1)/(k2-k1);
	y=x*k1+b1;
	if((x<fmin(xv,xp)||x>fmax(xv,xp)||x<fmin(xw1,xw2)||x>fmax(xw1,xw2)||y<fmin(yv,yp)||y>fmax(yv,yp)||y<fmin(yw1,yw2)||y>fmax(yw1,yw2))&&xw1!=xw2&&xv!=xp)
	{
		x1=(b3-b1)/(k3-k1);
	    y1=x1*k1+b1;
	    if((x1<fmin(xv,xp)||x1>fmax(xv,xp)||x1<fmin(xm1,xm2)||x1>fmax(xm1,xm2)||y1<fmin(yv,yp)||y1>fmax(yv,yp)||y1<fmin(ym1,ym2)||y1>fmax(ym1,ym2))&&xm1!=xm2)
	    {
	    	printf("YES");
	    	return 0;
		}
		else
		{
			printf("NO");
			return 0;
		}
	}
	/*if((x>=fmin(xv,xp)&&x<=fmax(xv,xp)&&x>=fmin(xw1,xw2)&&x<=fmax(xw1,xw2)&&y>=fmin(yv,yp)&&y<=fmax(yv,yp)&&y>=fmin(yw1,yw2)&&y<=fmax(yw1,yw2))&&xw1!=xw2&&xv!=xp)
	{
		printf("NO");
		return 0;
	}*/
	if(xv!=xp&&xw1==xw2) 
	{
		if(xw1<=max(xv,xp)&&xw1>=min(xv,xp)&&(min(yw1,yw2)<=k1*xw1+b1)&&max(yw1,yw2)>=k1*xw1+b1)
		{
			printf("NO");
			return 0;
		}
		else
		{
			printf("YES");
			return 0;
		}
	}
	if(xv==xp&&xw1!=xw2)
	{
		if(xv<=max(xw1,xw2)&&xv>=min(xw1,xw2)&&(min(yv,yp)<=k1*xv+b1)&&max(yv,yp)>=k1*xv+b1)
		{
			printf("NO");
			return 0;
		}
		else
		{
			printf("YES");
			return 0;
		}
	}
	if(xv==xp&&xw1==xw2)
	{
		if(xv==xw1)
		{
			printf("NO");
			return 0;
		}
		else
		{
			printf("YES");
			return 0;
		}
	}
	//printf("NO");
	return 0;                                                                                                                                                                                             
}
