# include <cstdio>
# include <algorithm>
using namespace std;
char a[8][8]={0};
int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	for(int i=0;i<5;i++)
	{
		for(int j=0;j<5;j++)
		{
			scanf("%c",a[i][j]);
		}
	}
	printf("8");
	return 0;
}
