#include<cstdio>
#include<iostream>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
string s;
int num[100005],sum[26];
int maxx,minn=666666;
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	int n,i,j;
	scanf("%d",&n);
	cin>>s;
	for(i=1;i<=n;i++)
	{
		num[i]=s[i-1]-'0'-48;
		sum[num[i]]++;
	}
	for(i=1;i<=26;i++)
	{
		if(sum[i]==0)sum[i]=-1;
		if(sum[i]>maxx)maxx=sum[i];
	}i=1;
	while(i<=n)
	{
		if(sum[num[i]]!=maxx&&sum[sum[num[i]]!=1])sum[num[i]]--;
		if(sum[num[i]]==maxx)break;
		if(sum[num[i]]==1)
		{
			cout<<maxx-1;return 0;
		}
		i++;
	}j=n;
	while(j>=i)
	{
		if(sum[num[j]]!=maxx&&sum[num[j]]!=1)sum[num[j]]--;
		if(sum[num[j]]==maxx)break;
		if(sum[num[j]]==1)
		{
			cout<<maxx-1;return 0;
		}
		j--;
	}
	for(i=1;i<=26;i++)
	  if(sum[i]<minn&&sum[i]!=-1)minn=sum[i];
	cout<<maxx-minn;
    return 0;
}
