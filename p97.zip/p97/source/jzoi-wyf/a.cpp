#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <string>
#include <cmath>

using namespace std;

const int int_max=1000000000;

char zf[1000002];
int ttl[1000002];
char tzf[1000002];
int num,js;

void check_max();
int get_max();

int main()
{
//	ios::sync_with_stdio(false);
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	cin>>num;
	for(int i=1;i<=num;i++)
		scanf("%c",&zf[i]);
	check_max();
	cout<<get_max();
	fclose(stdin);
	fclose(stdout);
	return 0;
}

void check_max()
{
	int j=1;
	for(int i=1;i<num;i++)
	{
		if(zf[i]==zf[i+1])
		{
			ttl[j]++;
		}
		else
		{
			j++;
			ttl[j]++;
		}
		if(i==num-1)
		{
			if(zf[i]!=zf[i+1])
			{
				j++;
				ttl[j]++;
				js=j;
			}
		}
	}
}

int get_max()
{
	int a=0;
	for(int i=2;i<=js;i++)
		a=max(a,max(ttl[i],ttl[i-1])-min(ttl[i],ttl[i-1]));
	return a;
}
