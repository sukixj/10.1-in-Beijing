#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <string>
#include <cmath>

using namespace std;

bool land[20002][20002];
//bool chkb[20002][20002];

int lengthx,lengthy;

struct str1
{
	int x;
	int y;
}	hja,yjq,dchja;

struct line_eq
{
	int a;
	int b;
	int c;
	int k;
} mline,wline,eline;

struct str2
{
	int sx,sy;
	int ex,ey;
}	mirror,wall,dcwall;

void check_seeable();
void init_str();
void solve_line_eq();
void solve_dcd();
bool check_lineable();
void solve_line_eq_end();

int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	init_str();
	solve_line_eq();
	solve_dcd();
	if(check_lineable()==0)
		cout<<"YES";
	else
		cout<<"NO"; 
	fclose(stdin);
	fclose(stdout);
	return 0;
}
void init_str()
{
	cin>>hja.x>>hja.y;
	hja.x+=10000;hja.y+=10000;
	cin>>yjq.x>>yjq.y;
	yjq.x+=10000;yjq.y+=10000;
	cin>>wall.sx>>wall.sy>>wall.ex>>wall.ey;
	wall.sx+=10000;wall.sy+=10000;wall.ex+=10000;wall.ey+=10000;
	cin>>mirror.sx>>mirror.sy>>mirror.ex>>mirror.ey;
	mirror.sx+=10000;mirror.sy+=10000;mirror.ex+=10000;mirror.ey+=10000;
}

void solve_line_eq()
{
	mline.a=mirror.ey-mirror.sy;
	mline.b=mirror.sx-mirror.ex;
	mline.c=mirror.sx*mirror.sy-mirror.sx*mirror.ey+mirror.sy*mirror.ex-mirror.sy*mirror.sx;
	mline.k=-mline.a/mline.b;
	wline.a=wall.ey-wall.sy;
	wline.b=wall.sx-wall.ex;
	wline.c=wall.sx*wall.sy-wall.sx*wall.ey+wall.sy*wall.ex-wall.sy*wall.sx;
	wline.k=-wline.a/wline.b;
}

void solve_dcd()
{
	dchja.x=((mline.b*mline.b-mline.a*mline.a)*hja.x-2*mline.a*mline.b*hja.y-2*mline.a*mline.c)/(mline.a*mline.a+mline.b*mline.b);
	dchja.y=((mline.a*mline.a-mline.b*mline.b)*hja.y-2*mline.a*mline.b*hja.x-2*mline.b*mline.c)/(mline.a*mline.a+mline.b*mline.b);
	dcwall.sx=((mline.b*mline.b-mline.a*mline.a)*wall.sx-2*mline.a*mline.b*wall.sy-2*mline.a*mline.c)/(mline.a*mline.a+mline.b*mline.b);
	dcwall.sy=((mline.a*mline.a-mline.b*mline.b)*wall.sy-2*mline.a*mline.b*wall.sx-2*mline.b*mline.c)/(mline.a*mline.a+mline.b*mline.b);
	dcwall.ex=((mline.b*mline.b-mline.a*mline.a)*wall.ex-2*mline.a*mline.b*wall.ey-2*mline.a*mline.c)/(mline.a*mline.a+mline.b*mline.b);
	dcwall.ey=((mline.a*mline.a-mline.b*mline.b)*wall.ey-2*mline.a*mline.b*wall.ex-2*mline.b*mline.c)/(mline.a*mline.a+mline.b*mline.b);
} 

bool check_lineable()
{
	int midx,midy;
	midx=(dcwall.ex+dcwall.sx)/2;
	midy=(dcwall.sy+dcwall.ey)/2;
	land[midx][midy]=1;
	while(midx!=dcwall.ex&&midx!=dcwall.sx&&midy!=dcwall.sy&&midy!=dcwall.ey)
	{
		midx+=1,midy+=wline.k;
		land[midx][midy]=1;
	}
	midx=(dcwall.ex+dcwall.sx)/2;
	midy=(dcwall.sy+dcwall.ey)/2;
	while(midx!=wall.ex&&midx!=wall.sx&&midy!=dcwall.sy&&midy!=dcwall.ey)
	{
		midx-=1,midy-=wline.k;
		land[midx][midy]=1;
	}
	solve_line_eq();
	midx=(dchja.x+yjq.x)/2;
	midy=(dchja.y+yjq.y)/2;
	while(midx!=wall.ex&&midx!=wall.sx&&midy!=dcwall.sy&&midy!=dcwall.ey)
	{
		midx-=1,midy-=eline.k;
		if(land[midx][midy]=1)	return 0;
	}
	midx=(dchja.x+yjq.x)/2;
	midy=(dchja.y+yjq.y)/2;
	while(midx!=wall.ex&&midx!=wall.sx&&midy!=dcwall.sy&&midy!=dcwall.ey)
	{
		midx+=1,midy+=eline.k;
		if(land[midx][midy]=1)	return 0;
	}
	return 1;
}

void solve_line_eq_end()
{
	eline.a=dchja.y-yjq.y;
	eline.b=yjq.x-dchja.x;
	eline.c=yjq.x*yjq.y-yjq.x*dchja.y+yjq.y*dchja.x-yjq.y*yjq.x;
	eline.k=-eline.a/eline.b;
}

