#include <stdio.h>
#include <cstring>
#include <iostream>
#include <ctime>
using namespace std;

inline int read( );
int work(int,int);

int ans=0,n;
string s;
int op[1000099];

int main( )
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	ios::sync_with_stdio(false);
	n=read( );
	cin>>s;
	for(register int i=0;i<n;i++)
	{
		for(register int j=i+1;j<n;j++)
		{
			
			int g=work(i,j);
			if(g>ans) ans=g;
		}
	}

	printf("%d\n" ,ans);
	return 0;
}

int work(int start,int end)
{
	int maxl=0,minl=0x7fffff;
	memset(op,0,sizeof(op));
	for(register int i=start;i<=end;i++)
	{
		op[s[i]]++;
	}
	for(register int i=start;i<=end;i++)
	{
		if(op[s[i]]<minl) minl=op[s[i]];
		if(op[s[i]]>maxl) maxl=op[s[i]]; 
	}
	return maxl-minl;
}

inline int read( )
{
	int f=1,p=0;char c=getchar( );
	while(c<'0'||c>'9'){if(c=='-') f=-1;c=getchar( );}
	while(c>='0'&&c<='9'){p=p*10+c-'0';c=getchar( );}
	return f*p;
}
