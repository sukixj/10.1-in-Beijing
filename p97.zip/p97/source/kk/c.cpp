#include <stdio.h>

int main( )
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	printf("233\n");
	return 0;
}