 #include<cstdio>
 #include<cstring>
 #include<string>
 #include<iostream>
 #include<algorithm>
 using namespace std;
 const int MAXN=1005;
 int a[200];
 int n;

 string s;
 int ans=0;

 
 int get_w(string s)
 {
 	memset(a,0,sizeof(a));
 	for(int i=0;i<s.size();i++)
 		a[ s[i] ]++;
 	int maxx=0;
 	int minn=999999999;
 	
 	for(int i='a';i<='z';i++)
 	{	
 		if(a[i]>maxx)
 			maxx=a[i];
 		if(a[i]!=0&&a[i]<minn)
 			minn=a[i];
	}
	return maxx-minn;
 }

 
 int main()
 {
 	freopen("a.in","r",stdin)
 	freopen("a.out","w",stdout)
 	int i,j,k;
	cin>>n;
 	cin>>s;
	n=s.size();//length
	
	for(i=0;i<n;i++)
		for(k=1;k<=n-i;k++)
		{
//			j=i+k-1;
			string str=s.substr(i,k);	//try every substr
	//		cout<<str<<endl;
	//		cout<<get_w(str)<<endl; 
			ans=max(ans,get_w(str));	
		}

	cout<<ans;
	 
	return 0; 
 }
