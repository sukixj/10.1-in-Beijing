 #include<cstdio>
 #include<cstring>
 #include<string>
 #include<iostream>
 #include<algorithm>
 using namespace std;
 
 int main()
 {
 	freopen("b.in","r",stdin)
	freopen("b.out","w",stdout)
	
 	int a,b,c,d,e,f,g,h,i,j,k,l;
 	cin>>a>>b>>c>>d>>e>>f>>g>>h>>i>>j>>k>>l;
 	
 	cout>>"YES";
 	return 0;
 }
