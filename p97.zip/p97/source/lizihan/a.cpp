#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
using namespace std;
int n,m;
int f[1010];
char c[1001000];
int maxx=0,minn=1001000,a[1000],t1,b[1000],t2,ans;
int te[1001000],s,w;
bool key;
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%1s",&c[i]);
		m=max(int(c[i]),m);
		f[int(c[i])]++;
	}
	for(int i=1;i<=m;i++)
	{
		if(!f[i])continue;
		if(maxx<f[i])maxx=f[i];
		if(minn>f[i])minn=f[i];
	}
	for(int i=1;i<=m;i++)
	{
		if(maxx==f[i])a[++t1]=i;
		if(minn==f[i])b[++t2]=i;
	}
	maxx=minn=0;
	for(int ii=1;ii<=t1;ii++)
	{
		for(int jj=1;jj<=t2;jj++)
		{
			memset(te,0,sizeof(te));
			key=0;
			maxx=minn=0;
			w=0;
			for(int i=1;i<=n;i++)
			{
				if(int(c[i])==a[ii])te[++w]=a[ii],maxx++;
				if(int(c[i])==b[jj])te[++w]=b[jj],minn++,key=1;
				if(key)ans=max(ans,maxx-minn);
				if(maxx==minn)maxx=minn=0;
			}
		}
	}
	cout<<ans;
	return 0;
}
/*
6
aaaaab
*/
