#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
using namespace std;
long double xh,yh,xy,yy;
long double x1q,y1q,x2q,y2q;
long double x1j,x2j,y1j,y2j;
long double aa,bb;
bool pd(long double x1,long double y1,long double x2,long double y2,
long double x3,long double y3,long double x4,long double y4,
 long double &a,long double &b)
{
	long double k1,b1,c1,k2,b2,c2;
	bool h1=0;bool hh2=0;
	if(x2==x1)c1=x1,h1=1;
	else k1=(y2-y1)/(x2-x1),b1=y2-k1*x2;
	if(x3==x4)c2=x3,hh2=1;
	else k2=(y3-y4)/(x3-x4),b2=y3-k2*x3;
	if(h1&&hh2)return 0;
	if(h1)
	{
		if(c1>=min(x3,x4)&&c1<=max(x3,x4))
		{
			a=c1,b=a*k2+b2;
			return 1;
		}
		else return 0;
	}
	if(hh2)
	{
		if(c2>=min(x1,x2)&&c2<=max(x1,x2))
		{
			a=c2,b=a*k1+b1;
			return 1;
		}
		else return 0;
	}
	if(k1==k2)return 0;
	else a=(b2-b1)/(k1-k2),b=k1*a+b1;
	if(a>=min(x3,x4)&&a<=max(x3,x4)&&a>=min(x1,x2)&&a<=max(x1,x2))return 1;
	else return 0;
}
bool kk()
{
	long double k1,b1;
	if(x2j==x1j)
	{
		if((xh-x1j)>0&&(xy-x1j)<0)return 0;
		if((xh-x1j)<0&&(xy-x1j)>0)return 0;
		//if(xh==x1j&&xy==x1j)return 0;
		return 1;
	}
	k1=(x1j-x2j)/(y1j-y2j);
	b1=y1j-k1*x1j;
	if((xh*k1+b1-yh)>0&&(xy*k1+b1-yy)<0)return 0;
	if((xh*k1+b1-yh)<0&&(xy*k1+b1-yy)>0)return 0;
	//if(xh*k1+b1-yh==0&&xy*k1+b1-yy==0)return 0;
	return 1;
}
void ljtm()
{
	long double x,y; 
	long double k1,b1,k2,b2;
	if(x1j==x2j)
	{
		x=x1j,y=yh;
	}
	if(y1j==y2j)
	{
		y=y1j,x=xh;
	}
	else
	{
		k2=(x1j-x2j)/(y1j-y2j);
		k1=-1/k2;
		b1=yh-k1*xh;
		b2=y1j-k2*x1j;
		x=(b2-b1)/(k1-k2);
		y=k1*x+b1;
	}
	x=2*x-xh,y=2*y-yh;
	if(!pd(x,y,xy,yy,x1j,y1j,x2j,y2j,aa,bb))
	{
		cout<<"NO";
		return ;
	}
	x=aa,y=bb;
	if(!pd(xh,yh,aa,bb,x1q,y1q,x2q,y2q,aa,bb)&&!pd(xy,yy,aa,bb,x1q,y1q,x2q,y2q,aa,bb))
	{
		cout<<"YES";
		return ;
	}
	else
	{
		cout<<"NO";
		return ;
	}
}
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	cin>>xh>>yh>>xy>>yy;
	cin>>x1q>>y1q>>x2q>>y2q;
	cin>>x1j>>y1j>>x2j>>y2j;
	if(!kk())
	{
		if(!pd(xh,yh,xy,yy,x1q,y1q,x2q,y2q,aa,bb)&&!pd(xh,yh,xy,yy,x1j,y1j,x2j,y2j,aa,bb))
		{
			cout<<"YES";
			return  0;
		}
		cout<<"NO";
		return 0;
	}
	else
	{
		if(!pd(xh,yh,xy,yy,x1q,y1q,x2q,y2q,aa,bb))
		{
			cout<<"YES";
			return  0;
		}
	}
	ljtm();
	return 0;
}
/*
0 0
10 0
100 101 101 101
1 0 3 0

0 0
1 1
0 1  1 0
-1 1 1 3

-1 3
1 3
0 2 0 4
0 0 0 1 NO

0 0
1 1
0 1 1 0
-100 -100 -101 -101 NO
*/
