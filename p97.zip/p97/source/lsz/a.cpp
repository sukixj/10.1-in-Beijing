#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;
char s[1000010];
int gs[30]={0},maxx,minn;
int zhi[1001][1001];
int quanzhi(int l,int r)
 {
  int i;
  for(i=0;i<=25;i++) gs[i]=0;
  for(i=l;i<=r;i++) gs[(int)(s[i]-'a')]++;
  maxx=0;minn=1000001;
  for(i=0;i<=25;i++)
   {
    if(maxx<gs[i]&&gs[i]!=0) maxx=gs[i];
	if(minn>gs[i]&&gs[i]!=0) minn=gs[i]; 
   }
  return maxx-minn;
 }
int main()
 {
  int i,j,k,n,l,as=0;
  freopen("a.in","r",stdin);
  freopen("a.out","w",stdout);
  scanf("%d\n",&n);
  for(i=1;i<=n;i++) scanf("%1c",&s[i]);
  k=quanzhi(1,n);
  if(minn==1) {printf("%d",k);return 0;}
  for(i=1;i<=n;i++)
   {
    minn=26;maxx=27;
    for(j=0;j<=25;j++) gs[j]=0;
    gs[26]=1000001;gs[27]=0;
    for(j=i;j<=n;j++)
     {
      gs[s[j]-'a']++;
      if(gs[maxx]<gs[s[j]-'a']) maxx=s[j]-'a';
      if(gs[minn]>gs[s[j]-'a']) minn=s[j]-'a';
      zhi[i][j]=gs[maxx]-gs[minn];//printf("%d ",gs[maxx]);
      if(zhi[i][j]>as) {as=zhi[i][j];} 
	 }
   }
  printf("%d",as);
  return 0;
 }
