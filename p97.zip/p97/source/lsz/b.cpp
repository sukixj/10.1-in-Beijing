#include <stdio.h>
#include <stdlib.h>
#include <iostream>
using namespace std;
int xv,yv,xp,yp,xn1,yn1,xn2,yn2,xm1,ym1,xm2,ym2;
int main()
 {
  int i,j;
  freopen("b.in","r",stdin);
  freopen("b.out","w",stdout);
  double xielv1,xielv2;
  scanf("%d%d%d%d",&xv,&yv,&xp,&yp);
  scanf("%d%d%d%d",&xn1,&yn1,&xn2,&yn2);
  scanf("%d%d%d%d",&xm1,&ym1,&xm2,&ym2);
  if(xv==xp&&xn1==xn2) {printf("YES");return 0;}
  if(yv==yp&&yn1==yn2) {printf("YES");return 0;}
  if(xv==xp)
   {
   	xielv1=(yn2-yn1)*1.0/(xn2-xn1);
   	printf("NO");
   }
  if(xn1==xn2)
   {
    printf("NO");
   }printf("NO");
 }
