#include <iostream>
#include <stdio.h>
#include <stdlib.h>
int main()
 {
  printf("5");
 }
