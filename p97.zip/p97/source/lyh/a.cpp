#include <fstream>
#include <algorithm>
#include <cmath>
#include <queue>
using namespace std;
ifstream cin ("a.in");
ofstream cout ("a.out");
char a[1000050];
int f[1000050];
int n,i,j;
int ans1,ans2,ans;
int main()
{
    cin>>n;
    cin>>a;
    f[0]=1;
    if(a[0]='b')
    f[0]=-1;
    ans1=0;
    ans2=2100000000;
    for(i=1;a[i]!='\0';i++)
    {
    	if(a[i]=='a')
    	f[i]=f[i-1]+1;
    	else
    	f[i]=f[i-1]-1;
    	ans1=max(ans1,f[i]);
    	ans2=min(ans2,f[i]);
	}
	if(ans1>ans2)
	ans=ans1-ans2;
	else
	ans=ans2-ans1;
	cout<<ans<<endl;
    //system("pause");
    return 0;
}

