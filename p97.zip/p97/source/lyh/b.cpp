#include <fstream>
#include <algorithm>
#include <cmath>
#include <queue>
using namespace std;
ifstream cin("b.in");
ofstream cout("b.out");
double p[10][3];//1,2 3,4 5,6
double k[10],b[10];
double l,r,m;
double x,y,kx,bx;
double xj;
double d1,d2;
int ans,i,j;
double dis(double kk,double bb,int n)
{
	double ss=sqrt(kk*kk+1);
	double d=abs(p[n][1]*kk-p[n][2]+bb)/ss;
	return d;
}
int abw(int aa)
{
	double e=k[2]*p[aa][1]+b[2];
	if(e>p[aa][2])
	return 1;
	if(e==p[aa][2])
	return -1;
	
	return 0;
}
int abm(int aa)
{
	double e=k[1]*p[aa][1]+b[1];
	if(e>p[aa][2])
	return 1;
	if(e==p[aa][2])
	return -1;
	
	return 0;
}
int main()
{
    for(i=1;i<=6;i++)
    cin>>p[i][1]>>p[i][2];
    
    k[2]=(p[4][2]-p[3][2])/(p[4][1]-p[3][1]);
    b[2]=p[3][2]-k[1]*p[3][1];
    k[1]=(p[6][2]-p[5][2])/(p[6][1]-p[5][1]);
    b[1]=p[5][2]-k[2]*p[5][1];
    l=p[3][1];
    r=p[4][1];
    k[3]=k[1];
    b[3]=p[1][2]-k[3]*p[1][1];
    
    
    
    while(l<r)
    {
    	m=(l+r)/2;
    	x=m;
    	y=k[1]*x+b[1];
    	kx=(-1)/k[1];
    	bx=y-kx*x;
    	d1=dis(kx,bx,1);
    	d2=dis(kx,bx,2);
    	if(abs(d1-d2)<0.5)
    	break;
    	else if(d1>d2)
    	r=m;
    	else
    	l=m;
	}
	

	x=m;
	xj=m;
	y=k[1]*x+b[1];
	k[4]=(p[1][2]-y)/(p[1][1]-x);
    b[4]=p[1][2]-k[4]*p[1][1];
    
	k[5]=(p[2][2]-y)/(p[2][1]-x);
    b[5]=p[2][2]-k[4]*p[2][1];   
	
	x=(b[2]-b[4])/(k[4]-k[2]);
	y=(b[2]-b[5])/(k[5]-k[2]);
	
	int m1,m2,w1,w2,xx,yy;
	m1=abm(1);
	m2=abm(2);
	w1=abw(1);
	w2=abw(2);
	if(x<=p[6][1] && x>=p[5][1])
	xx=1;
	else
	xx=0;
	
	if(y<=p[6][1] && y>=p[5][1])
	yy=1;
	else
	yy=0;
	
	/*cout<<k[1]<<b[1]<<endl;
	cout<<k[2]<<b[2]<<endl;*/
	//cout<<m1<<m2<<endl;
	
	
	if(p[5][1]==p[6][1] && (p[1][1]-p[5][1])*(p[2][1]-p[5][1])<0)
	ans=1;
	if(m1!=m2)
	ans=1;
	if(m1==m2)
	{
		if(m1==w1)
        if(xx==1 && (xj-x)*(x-p[1][1])>0)
        ans=1;
        
        if(m2==w2)
        if(yy==1 && (xj-x)*(x-p[2][1])>0)
        ans=1;
        //if( &&(xj-y)*(y-p[2][1]))
    }
    if(ans==0)
    cout<<"YES"<<endl;
    else
    cout<<"NO"<<endl;
    //system("pause");
    return 0;
}

