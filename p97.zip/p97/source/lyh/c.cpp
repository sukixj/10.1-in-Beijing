#include <iostream>
#include <algorithm>
#include <cmath>
#include <queue>
using namespace std;
int c[3][3][4];
int h[3][3];
int i,j,k,n;
char shuru[6];
void tiaoshi()
{
	for(i=0;i<3;i++)
	{
	    for(j=0;j<3;j++)
	    {
	        for(k=0;k<4;k++)
	        cout<<c[i][j][k];
	        
	        cout<<h[i][j]<<"  ";
	    }
	    cout<<endl;
	}
}
int main()
{
	for(i=0;i<3;i++)
	{
	    for(j=0;j<3;j++)
	    {
	    	cin>>shuru;
	    	for(k=0;shuru[k]!='\0';k++)
	    	{
	    	if(shuru[k]=='R')
	    	c[i][j][k]=1;
	    	if(shuru[k]=='G')
	    	c[i][j][k]=2;
	    	if(shuru[k]=='B')
	    	c[i][j][k]=3;
	    	if(shuru[k]=='1')
	    	h[i][j]=1;
	        }
		}
	}
	
	
	//tiaoshi();
    //system("pause");
    return 0;
}


/*GGGG0 GGGG0 GGGG0
  OGOO0 GGGG0 OGOO0
  OOOO0 OGGG1 OOOO0 */
