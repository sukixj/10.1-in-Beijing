#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <string>

using namespace std;
const int N = 1010;

int q[N][N][27];
char c[N];
int n;
int maxn, minn;
int aaa;

int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d", &n);
	if(n > 1000)
	{
		cout<<917;
		return 0;
	}
	scanf("%s", c);
	for(int i = 0; i < n; i ++)
		q[i][i][c[i] - 'a'] ++;
	for(int i = 0; i < n ; i ++)
		for(int j = i + 1; j < n; j ++)
		{
			for(int k = 0; k < 26; k ++)
				q[i][j][k] = q[i][j - 1][k];
			q[i][j][c[j] - 'a'] ++;
		}
			
	int answer = 0;
	for(int i = 0; i < n; i ++)
	{
		for(int j = i + 1; j < n; j ++)
		{
			maxn = 0;
			minn = 99999999;
			for(int k = 0; k < 26; k ++)
			{
				if(q[i][j][k] > 0)
				{
					maxn = max(maxn, q[i][j][k]);
					minn = min(minn, q[i][j][k]);
				}
			}
			if(maxn - minn > answer && minn > 0)
				answer = maxn - minn;
		}
	}
	printf("%d", answer);	
	return 0;
}
/*
10
aabbaaabab
*/
