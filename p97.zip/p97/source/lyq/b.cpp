#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <string>

using namespace std;
const int jia = 1e4 + 10;

int p1x, p1y, p2x, p2y;
int j1x, j1y, j2x, j2y;
int w1x, w1y, w2x, w2y;

int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%d%d%d%d%d%d%d%d%d%d%d%d",&p1x,&p1y,&p2x,&p2y,&j1x,&j1y,&j2x,&j2y,&w1x,&w1y,&w2x,&w2y);
	p1x += jia;p1y += jia;p2x += jia;p2y += jia;j1x += jia;j1y += jia;
	j2x += jia;j2y += jia;w1x += jia;w1y += jia;w2x += jia;w2y += jia;
	if(max(w1x, w2x) < min(p1x, p2x))//qiang at zuo
	{
		cout<<"YES";
		return 0;
	}
	if(max(p1x, p2x) < min(w1x, w2x))//peo at zuo
	{
		cout<<"YES";
		return 0;
	}
	if(min(w1y, w2y) > max(p1y, p2y))//qiang at up
	{
		cout<<"YES";
		return 0;
	}
	if(min(p1y, p2y) > max(w1y, w2y))//peo at up
	{
		cout<<"YES";
		return 0;
	}
	if((p1y+p2y+w1y+w2x)%2)
	{
		cout<<"NO";
		return 0;
	}
	cout<<"YES";
	return 0;
}
