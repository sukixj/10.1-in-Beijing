#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <string>

int main()
{
	freopen("c.out","w",stdout);
	printf("13");
	return 0;
}
