#include <iostream>
#include <memory.h>

using namespace std;
int k,n,w,_max;
char s[1000000];
int js[200];

int _find(int i1,int j1);

int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	_max=0;
	
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>s[i];
	
	s[0]=0;
	
	for(int i=2;i<=n;i++){
		memset(js,0,sizeof(js));
		for(int j=1;j<=i;j++){
			js[s[j]]++;
		}
		
		//Ԥ����
		 
		for(int j=1;j<=n-i+1;j++){	
			
			w=_find(j,j+i-1);
			if(w>_max){
				_max=w;
			}
			js[s[j]]--;
			js[s[j+i]]++;
		}
	}
	
	cout<<_max;
	
	fclose(stdin);
	fclose(stdout);
}

int _find(int i1,int j1){
	int i,j,c=0;
	bool pd[200];
	int ma=-1,mi=214700000;
	
	//cout<<"================="<<endl;
	
	memset(pd,0,sizeof(pd));
	i=i1;j=j1;
	for(i=i1;i<=j1;i++){
		pd[s[i]]=true;
		c++;
	}
	
	if(c==1){
		return(0);
	}
	
	for(int i='a';i<='z';i++){
		//cout<<"pd[i]=:"<<pd[i]<<' '<<"js[i]=:"<<js[i]<<endl;
		if(js[i]>ma && pd[i]==true){
			ma=js[i];
		}
		if(js[i]<mi && pd[i]==true){
			mi=js[i];	
		}
	}
	//cout<<ma-mi<<endl;
	if(ma>=mi){
		return(ma-mi);
	}else{
		return 0;
	}
}



