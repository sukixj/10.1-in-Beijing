#include<iostream>
#include<cstdio>
#include<cstring>
#define N 1000005
using namespace std;

int n,head,ans;
int b[N],sum[N],pos[30],tot[30],cnt[N];
char a[N];
bool flag[200];

inline void read(int &num)
{
	char c=getchar();
	for(;!isdigit(c);c=getchar());
	for(;isdigit(c);c=getchar()){num=num*10+c-'0';};
}

int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",a+1);
	for(int i=1;i<=n;++i)
	{
		if(a[i]!=a[i-1])
		{
			++head;
			b[head]=a[i]-'a';
			tot[a[i]-'a']++;
			if(!flag[a[i]])
			{
				pos[a[i]-'a']=i;
				flag[a[i]]=1;
			}
		}
		++sum[head];
	}
	if(head==1)
	{
		printf("0");
		return 0;
	}
	sum[0]=sum[head+1]=0x7fffffff;
	for(int i=0;i<=26;++i)
	{
		if(!pos[i]) continue;
		if(tot[i]==1)
		{
			ans=max(ans,sum[pos[i]]-1);
			continue;
		}
		memset(cnt,0,head);
		for(int j=pos[i];j<=head;++j)
		{
			cnt[j]=cnt[j-1];
			if(b[j]==i) cnt[j]+=sum[j];
			else cnt[j]-=sum[j];
			if(cnt[j]<0) cnt[j]=0;
		}
		for(int j=pos[i];j<=head;++j)
		{
			ans=max(ans,cnt[j]);
		}
	}
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
