#include<cstdio>
#include<iostream>
#include<cmath>
using namespace std;

struct Point
{
	int x,y;
}x,y,xx,yy,a,b,aa,bb;

double determinant(double v1, double v2, double v3, double v4)
{
	return (v1*v3-v2*v4);
}

bool in(Point aa, Point bb, Point cc, Point dd)
{
	double delta = determinant(bb.x-aa.x, cc.x-dd.x, bb.y-aa.y, cc.y-dd.y);
	if(delta<=(1e-6)&&delta>=-(1e-6))
	{
		return false;
	}
	double namenda = determinant(cc.x-aa.x, cc.x-dd.x, cc.y-aa.y, cc.y-dd.y) / delta;
	if ( namenda>1 || namenda<0 )
	{
		return false;
	}
	double miu=determinant(bb.x-aa.x, cc.x-aa.x, bb.y-aa.y, cc.y-aa.y) / delta;
	if ( miu>1 || miu<0 )
	{
		return false;
	}
	return true;
}

int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%d%d",&x.x,&x.y);
	scanf("%d%d",&xx.x,&xx.y);
	scanf("%d%d",&a.x,&a.y);
	scanf("%d%d",&b.x,&b.y);
	scanf("%d%d",&aa.x,&aa.y);
	scanf("%d%d",&bb.x,&bb.y);
	if(in(x,y,aa,bb)) printf("NO");
	else if(in(x,y,a,b)==0) printf("YES");
	else if(in(x,y,a,b)==1&&x.x%2) printf("NO");
	else if(in(x,y,a,b)==1&&!x.x%2) printf("YES");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
