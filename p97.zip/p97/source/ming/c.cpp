#include<iostream>
#include<cstdio>
#include<ctime>
#include<algorithm>
using namespace std;

int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	int n;
	srand(n=time(NULL));
	printf("%d",n%13);
	fclsoe(stdin);
	fclose(stdout);
	return 0;
}
