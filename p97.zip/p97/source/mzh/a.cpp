#include <iostream>
#include<cstring>
#include<cstdio>
using namespace std;
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	char s[100000];
	int i,j,max1=0,max2=0,min1=99999,n,a[27];
	cin>>n;
	cin>>s;
	for(i=0;i<=n-1;i++)
	for(j=i+1;j<=n-1;j++)
	{
		max2=0;
		min1=99999;
	    memset(a,0,sizeof(a));
		for(int k=i;k<=j;k++)
		{
			a[(int)s[k]-96]++;
		}
		for(int k=1;k<=26;k++)
		{
			if(a[k]>=max2)
			max2=a[k];
			if(a[k]<=min1&&(a[k]!=0))
			min1=a[k];
		}
		if(max2-min1>max1)
		{
			max1=max2-min1;	
		}
	}
	cout<<max1;
}
