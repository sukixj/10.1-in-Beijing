#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("c.out","w",stdout);
	cout<<"128";
}
