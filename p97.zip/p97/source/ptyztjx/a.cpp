#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>

#define file(x) freopen(x".in","r",stdin); freopen(x".out","w",stdout);

using namespace std ;
const int N = 1e6 + 10;

char s[N];
int n,t[N][26];
int ans = 0;
int mx=0,mi = N;
int main () {
	file("a");
	scanf("%d",&n);
	scanf("%s",s+1);
	
	for (int i = 1;i <= n; ++i)
		for (int k = 0;k < 26; ++k)
		t[i][k] = t[i-1][k] + (s[i]-'a' == k);
	for (int i = 1;i < n; ++i) {
		for (int j = i;j <= n; ++j) {
			mx = 0;mi = N;
			for (int k = 0;k < 26; ++k) {
				int the = t[j][k]-t[i-1][k];
				mx = max(mx,the);
				if (the) mi = min(mi,the);
			}
			ans = max(ans,mx-mi);
		}
	}
	cout << ans;
	return 0;
}
