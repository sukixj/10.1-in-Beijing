#include <iostream>
#include <cstdio>
#include <cmath>

#define file(x) freopen(x".in","r",stdin); freopen(x".out","w",stdout);

using namespace std ;
const double eps = 1e-6;

struct Point {
	int x,y;
}H,Y,wall1,wall2,fz1,fz2;
struct point{
	double x,y;
	bool flag;
}p_w,p_z;
struct line {
	double A,B,C;
}peo,wall,fz;
inline line get_line(double x1,double x2,double y1,double y2) {
	line ans;
	if (x1 == x2) {
		ans.A = 0;ans.B = 0;ans.C = x1;
		return ans;
	}
	if (y1 == y2) {
		ans.A = 0;ans.B = 0;ans.C = y1;
		return ans;
	}
	ans.A = (y1-y2)/(x1-x2);
	ans.B = -1;
	ans.C = -(y1-y2)/(x1-x2)+y1;
	return ans;
}
inline point get_point(line a,line b) {
	point ans;
	double k = a.B*b.A-a.A*a.B;
	double c = a.C*b.A - b.C*a.A;
	if (k == 0) {
		ans.flag = true;
		return ans;
	}
	ans.y = -c/(k);
	if (a.A == 0) ans.x = 0;
	ans.x = (-c-ans.y*a.B)/a.A;
	return ans;
}
int main () {
	file("b");
	scanf("%d%d",&H.x,&H.y);
	scanf("%d%d",&Y.x,&Y.y);
	scanf("%d%d%d%d",&wall1.x,&wall1.y,&wall2.x,&wall2.y);
	scanf("%d%d%d%d",&fz1.x,&fz1.y,&fz2.x,&fz2.y);
	
	peo = get_line(1.0*H.x,1.0*Y.x,1.0*H.y,1.0*Y.y);
	wall = get_line(1.0*wall1.x,1.0*wall2.x,1.0*wall1.y,1.0*wall2.y);
	fz = get_line(1.0*fz1.x,1.0*fz2.x,1.0*fz1.y,1.0*fz2.y);
	p_w = get_point(peo,wall);
	
	puts("YES");
	return 0;
}
