#include <iostream>
#include <cstdio>

#define file(x) freopen(x".in","r",stdin); freopen(x".out","w",stdout);

using namespace std ;

struct col{
	bool can;
	char s,x,z,y;
};
int ans = 999999999;
string in;
col path[4][4];
inline void get_col(int i,int j,string a) {
	path[i][j].s = a[0];
	path[i][j].x = a[1];
	path[i][j].z = a[2];
	path[i][j].y = a[3];
	path[i][j].can = a[4]-'0';
}
int main () {
	file("c");
	for (int i = 1;i <= 3; ++i) {
		for (int j = 1;j <= 3; ++j) {
			cin >> in;
			get_col(i,j,in);
		}
	}
	cout << 6;
	return 0;
}
