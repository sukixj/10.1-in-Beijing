#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;
char str[1000002];
int sum[30],sum_[30];
int mmax = 0,mmin = 2000000000;
int getmax(int a[1000002]){
	int ans = 0;
	for (int i = 1 ; i <= 26;++ i){
		if (a[i] != 0) ans = max(ans,a[i]);
	}
	return ans;
}
int getmin(int a[1000002]){
	int ans = 2000000000;
	for (int i = 1 ; i <= 26;++ i){
		if (a[i] != 0) ans = min(ans,a[i]);
	}
	return ans;
}
int main (){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	int numi,numj,ans = 0;
	cin >> str;
	for ( int i = 0 ; i <= strlen(str) - 1; ++ i){
		numi =  (int)str[i] - 96 ;
		sum[numi] += 1;
		for (int z = 1; z <= 26;++ z)
			sum_[z] = sum[z];
		for (int j = 0;j <= i ; ++ j){
			numj =  (int)str[j] - 96 ;
			mmax = getmax(sum);
			mmin = getmin(sum);
			
			ans = max (ans,mmax - mmin);
			sum_[numj] -= 1;
		}
	}
	cout << ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
