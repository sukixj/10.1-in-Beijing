#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;
struct line{
	double k,b;
	double dyyl,dyyr;
}wal,r1,r2,fa,jin,r3,r22;
struct dot{
	double x,y;
}dian,r_jin,wal_r1,wal_r22,wal_r3,jin_r1;

line makeline(double bx,double by,double ex,double ey){
	line ans;
	ans.dyyl =  min(bx,ex);
	ans.dyyr =  max(bx,ex);
	ans.k = (by - ey)/(bx - ex);
	if (!(bx - ex)) ans.k = 1.79000e+308;
	ans.b = by - ans.k * bx;
	return ans;
}
dot jiao(line l1,line l2){
	dot ans;
	//y = kx + b
	//k1x + b1 = k2x + b2
	//x = (b2 - b1)/(k1-k2)
	ans.x = (l2.b - l1.b)/(l1.k - l2.k);
	if (!(l1.k - l2.k)) ans.x = 1.79000e+308;
//	cout << l2.b - l1.b<<endl;
	ans.y = l1.k * ans.x + l1.b;
	return ans;
}
bool indyy(double x,double dyyl,double dyyr){
	return (x>= dyyl && x <= dyyr);
}
int main (){
//	freopen("b.in","r",stdin);
//	freopen("b.out","w",stdout);
	double hx,hy,yx,yy,wbx,wby,wex,wey,jbx,jby,jex,jey,kk,hhx,hhy;
//	scanf("%lf%lf",&hx,&hy);
//	scanf("%lf%lf",&yx,&yy);
//	scanf("%lf%lflf%lf",&wbx,&wby,&wex,&wey);
//	scanf("%lf%lflf%lf",&jbx,&jby,&jex,&jey);
	cin >> hx >> hy >> yx >>yy>>wbx>>wby>>wex>>wey>>jbx>>jby>>jex>>jey;
	
	wal = makeline(wbx,wby,wex,wey);
	jin = makeline(jbx,jby,jex,jey);
	r1 = makeline(hx,hy,yx,yy);
	
	kk = -1/jin.k;
	fa = (line){kk,hy - kk*hx,-10002,10002};
	dian = jiao(jin,fa);
	hhx = dian.x + (dian.x - hx);
	hhy = dian.y + (dian.y - hy);
	r2 = makeline(hhx,hhy,yx,yy);
	
	r_jin = jiao(r2,jin);
	r22 = makeline(yx,yy,r_jin.x,r_jin.y);
	r3 = makeline(hx,hy,r_jin.x,r_jin.y);
	
	wal_r1 = jiao(wal,r1);
//	cout << wal_r1.x <<" "<< wal_r1.y<<endl;
	wal_r22 = jiao(wal,r22);
	wal_r3 = jiao(wal,r3);
	jin_r1 = jiao(jin,r1);
	
	
	bool a = (indyy(dian.x,jin.dyyl,jin.dyyr)&& indyy(dian.x,r2.dyyl,r2.dyyr)
	&& !(indyy(wal_r22.x,wal.dyyl,wal.dyyr)&&indyy(wal_r22.x,r22.dyyl,r22.dyyr))	
	&& !(indyy(wal_r3.x,wal.dyyl,wal.dyyr)&&indyy(wal_r3.x,r3.dyyl,r3.dyyr))
	);
	bool b = !(indyy(wal_r1.x,wal.dyyl,wal.dyyr)&& indyy(wal_r1.x,r1.dyyl,r1.dyyr))
	&& !(indyy(jin_r1.x,jin.dyyl,jin.dyyr)&& indyy(jin_r1.x,r1.dyyl,r1.dyyr));
	
	cout << wal.dyyl <<" "<< wal.dyyr <<" "<< wal_r1.x<<endl;
	cout << indyy(wal_r1.x,wal.dyyl,wal.dyyr)<< " "<<indyy(wal_r1.x,r1.dyyl,r1.dyyr)<<endl;
	if(a || b) cout << "YES";
	else cout << "NO";
	
//	fclose(stdin);
//	fclose(stdout);
	return 0;
}
//b = y - kx
