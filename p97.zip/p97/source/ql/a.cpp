#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
int n,maxx,minn,ans,sum[1020][26];
char s[1020];
int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);scanf("%s",s+1);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=26;j++)sum[i][j]=sum[i-1][j];
		int z=s[i]-'a'+1;
		sum[i][z]=sum[i-1][z]+1;
	}
	for(int i=1;i<=n;i++){
		for(int j=i;j<=n;j++){
			if(i==j){
				ans=max(ans,0);
				continue;
			}
			maxx=-1;minn=100000;
			for(int k=1;k<=26;k++){
				int z=sum[j][k]-sum[i-1][k];
				if(z)minn=min(minn,z);
				maxx=max(maxx,z);
			}
			ans=max(ans,maxx-minn);
		}
	}
	printf("%d\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
