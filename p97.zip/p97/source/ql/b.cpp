#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
struct ZB{
	int x,y;
}Hja,Yjq;
struct ZA{
	int x,y,xx,yy;
}mior,qa;
int main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%d%d",&Hja.x,&Hja.y);
	scanf("%d%d",&Yjq.x,&Yjq.y);
	scanf("%d%d%d%d",&qa.x,&qa.y,&qa.xx,&qa.yy);
	scanf("%d%d%d%d",&mior.x,&mior.y,&mior.xx,&mior.yy);
	cout<<"YES\n";
	fclose(stdin);fclose(stdout);
	return 0;
}
