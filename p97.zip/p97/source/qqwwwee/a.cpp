//#include <iostream>
#include <fstream>
using namespace std;

ifstream cin("a.in");
ofstream cout("a.out");

const int STR_LEN = 1000006;
const int CHAR_NUM = 26;

int str_len;
char str_in[STR_LEN];
int cnt, ans, mcnt;
bool exist_a, exist_b;
bool exist_char[128];

int main() {
	cin >> str_len;
	cin >> str_in;
	ans = 0;
	for (int i = 0; i < str_len; i++) {
		exist_char[(int)str_in[i]] = true;
	}
	for (char id_a = 'a'; id_a <= 'z' ; id_a++) {
		if (!exist_char[(int)id_a]) {
			continue;
		}
		for (char id_b = 'a'; id_b <= 'z' ; id_b++) {
			if (!exist_char[(int)id_b]) {
				continue;
			}
			if (id_a == id_b) {
				continue;
			}
			mcnt = 0;
			cnt = 0;
			exist_b = false;
			for (int i = 0; i < str_len; i++) {
				if (str_in[i] == id_a) {
					cnt++;
				} else if (str_in[i] == id_b) {
					exist_b = true;
					cnt--;
					if (cnt < 0) {
						cnt = 0;
						exist_b = false;
					}
				}
				if (exist_b && (cnt > mcnt)) {
					mcnt = cnt;
					//cout << i << 'p' << cnt << id_a << id_b << exist_b << '\n';
				}
				//cout << i << ' ' << cnt << id_a << id_b << exist_b << '\n';
			}
			if (cnt > mcnt) {
				mcnt = cnt - 1;
			}
			if  (mcnt > ans) {
				ans = mcnt;
			}
		}
	}
	cout << ans << endl;
	return 0;
}
