#include <fstream>
#include <algorithm>
#include <cstdlib>
#include <time.h>
//#include <cstdint>
using namespace std;

ifstream cin("b.in");
ofstream cout("b.out");

/*struct Point {
	int x;
	int y;
	Point (int x, int y): x(x), y(y) {}
	Point operator + (Point t) {
		return Point(x + t.x, y + t.y);
	}
	Point operator - (Point t) {
		return Point(x - t.x, y - t.y);
	}
	void operator += (Point t) {
		x += t.x;
		y += t.y;
	}
	void operator -= (Point t) {
		x -= t.x;
		y -= t.y;
	}
	double dis() {
		return sqrt(x*x + y*y);
	}
};*/

int main() {
	//cout << Point(3,4).dis() << endl;
	if (time(NULL) % 2) {
		cout << "YES" << endl;
	} else {
		cout << "NO" << endl;
	}
	return 0;
}
