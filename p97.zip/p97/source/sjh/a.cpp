#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int maxn=100001;
const int inf=1073741824;

char b[maxn],change[26];

int sum[maxn];
int n,ans=0;

struct maxii{
    int sumi;
    char c;
};

maxii maxi,mini;

void dfs(maxii maxni,maxii minni,int lens,int headd,int taill)
{
    if(taill-headd+1<maxni.sumi)
    {
        ans=max(ans,maxni.sumi-minni.sumi);
        return ;
    }
    if(b[headd]==minni.c)
    {
        minni.sumi--;
        dfs(maxni,minni,headd-1,taill);
    }
    if(b[headd]==maxni.c)
    {
        maxni.sumi--;
        dfs(maxni,minni,headd-1,taill);
    }
    if(b[taill]==minni.c)
    {
        minni.sumi--;
        dfs(maxni,minni,headd,taill-1);
    }
    if(b[taill]==maxni.c)
    {
        maxni.sumi--;
        dfs(maxni,minni,headd,taill-1);
    }
    if(b[headd]!=maxni.c && b[headd]!=minni.c)
    {
        int i=headd;
        sum[b[i]-'a']--;
        if(sum[i]>maxi.sumi)
        {
            maxi.sumi=sum[i];
            maxi.c=change[i];
        }
        if(sum[i]!=0  && sum[i]<mini.sumi)
        {
            mini.sumi=sum[i];
            mini.c=change[i];
        }
        dfs(maxni,minni,headd-1,taill);
    }
    if(b[taill]!=maxni.c && b[taill]!=minni.c)
    {
        int i=taill;
        sum[b[i]-'a']--;
        if(sum[i]>maxi.sumi)
        {
            maxi.sumi=sum[i];
            maxi.c=change[i];
        }
        if(sum[i]!=0  && sum[i]<mini.sumi)
        {
            mini.sumi=sum[i];
            mini.c=change[i];
        }
        dfs(maxni,minni,headd,taill-1);
    }
    return ;
}

    
int main()
{
    int i,j,k,ans=0;
    //freopen("a.in","r",stdin);
    //freopen("a.out","w",stdout);
    scanf("%d",&n);
    tail=n-1;
    cin>>b;
    for(i=0;i<n;i++)
    {
        sum[b[i]-'a']++;
        change='a'+i;
    }
    
    for(i=0;i<n;i++)
    {
        if(sum[i]>maxi.sumi)
        {
            maxi.sumi=sum[i];
            maxi.c=change[i];
        }
        if(sum[i]!=0  && sum[i]<mini.sumi)
        {
            mini.sumi=sum[i];
            mini.c=change[i];
        }
    }
    dfs(maxi,mini,0,n-1);
    
    cout<<ans;
    system("pause");
    return 0;
}
