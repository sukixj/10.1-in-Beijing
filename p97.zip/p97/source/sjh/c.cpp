#include<bits/stdc++.h>
using namespace std;
int main()
{
	int i,j,k;
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	cout<<"Sorry I can't do that";
	return 0;
}
