#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#define N 30
using namespace std;
char ch[1100000];
int n,s[1100000][N],ans,minn,maxn;
using namespace std;
int read()
{
	int x=0,f=1; char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9') x=x*10+ch-'0',ch=getchar();
	return x*f;
}
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	n=read();
	cin>>ch;
	for(int i=0;i<n;i++) 
	 for(int j=1;j<=26;j++)
	 {
	 	 if(ch[i]-'a'+1==j) s[i+1][j]=s[i][j]+1;
	  	else s[i+1][j]=s[i][j];
	} 
	
	for(int l=1;l<n;l++)
	 for(int i=1;i<=n;i++)
	 {
	 	maxn=0,minn=0x7fffffff;
	 	if(i+l>n) break;
	 	for(int j=1;j<=26;j++)
	 	{
	 		maxn=max(maxn,s[i+l][j]-s[i-1][j]);
	 		if(minn>s[i+l][j]-s[i][j]&&(s[i+l][j]-s[i-1][j])!=0) 
	 		 minn=s[i+l][j]-s[i-1][j];
		} 
		ans=max(ans,maxn-minn);
	 }
	printf("%d",ans);
}
