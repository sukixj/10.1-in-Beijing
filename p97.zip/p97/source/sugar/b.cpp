#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
int x1,x2,y1,y2;
int wx1,wx2,wy1,wy2,mx1,mx2,my1,my2;
int read()
{
	int x=0,f=1; char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9') x=x*10+ch-'0',ch=getchar();
	return x*f;
}
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	x1=read(),y1=read();
	y1=read(),y2=read();
	wx1=read(),wy1=read(),wx2=read(),wy2=read();
	mx1=read(),my1=read(),mx2=read(),my2=read();
	printf("YES");
	return 0;
}
