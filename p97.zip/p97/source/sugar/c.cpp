#include<ctime>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
using namespace std;
int ans=0x3f3f3f3f,num,x,y,col[3][3][5];
int fx[5]= {1,-1,0,0},fy[5]= {0,0,-1,1};
bool judge()
{
	return true;
}
int main() 
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	srand(time(0));
	for(int i=1; i<=3; ++i) 
	{
		char str[6];
		for(int j=1; j<=3; ++j) 
		{
			scanf("%s",str);
			num+=str[4]-'0';
			if(str[4]-'0'==1) x=i,y=j;
			for(int k=0; k<5; ++k) 
			{
				if(str[k]=='R') col[i][j][1]=1;
				else if(str[k]=='G') col[i][j][2]=2;
				else if(str[k]=='B') col[i][j][3]=3;
				else if(str[k]=='O') col[i][j][4]=4;
			}
		}
	}
	printf("%d",rand()%20010623);
	return 0;
	fclose(stdin);
	fclose(stdout);
}
