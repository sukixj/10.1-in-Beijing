#include <iostream>
#include <cstdio>
using namespace std;
int n, maxn, minn, ans;
char x[100005];
int a[100005][30]={0};
int main(){
	freopen("a.in", "r", stdin);
	freopen("a.out", "w", stdout);
	cin>>n;
	scanf("%s", x+1);
	for(int i=1; i<=n; i++){
		for(int j=0; j<26; j++)
			a[i][j] = a[i-1][j];
		a[i][x[i]-'a']++; 
	}
	for(int i=1; i<=n; i++)
		for(int j=i; j<=n; j++){
			maxn = 0;
			minn = 0x3f3f3f3f;
			for(int k=0; k<26; k++){
				maxn = max(maxn, a[j][k]-a[i-1][k]);
				minn = min(minn, (a[j][k]-a[i-1][k])?(a[j][k]-a[i-1][k]):0x3f3f3f3f);
			}
			ans = max(ans, maxn-minn);
		}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
