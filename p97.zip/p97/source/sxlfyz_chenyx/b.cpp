#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;
struct Lines{
	double x1, y1, x2, y2, k, b;
}sig, wal, mir;
double eps=1e-6;
bool hasn(Lines x, Lines y){
	double xx, yy;
	if(abs(y.k-x.k)<eps)	return false;
	xx = (y.b-x.b)/(x.k-y.k);
	yy = x.k*xx+x.b;
	if(xx>min(x.x1, x.x2) && xx<max(x.x1, x.x2))	return true;
	return false;
}
void cal(Lines &x){
	if(abs(x.x1-x.x2)<eps)	x.k = 99999999.0;
	else			x.k = (double)(x.y2-x.y1)/(x.x2-x.x1);
	x.b = x.y1-x.k*x.x1;
}
void cc(){
	double xx, yy;
	Lines kk;
	kk.k = -1.0/mir.k;
	kk.b = sig.y2-kk.k*sig.x2;
	kk.x1 = sig.x2;
	kk.y1 = sig.y2;
	xx = (mir.b-kk.b)/(kk.k-mir.k);
	yy = kk.k*xx+kk.b;
	if(mir.k>99999990.0){
		kk.y2 = kk.y1;
		kk.x2 = 2*mir.x1-kk.x1;
	}
	else {
		kk.y2 = 2*yy-kk.y1;
		kk.x2 = 2*xx-kk.x1;
	}
	sig.x2 = kk.x2;
	sig.y2 = kk.y2;
	cal(sig);
}
int main(){
	freopen("b.in", "r", stdin);
	freopen("b.out", "w", stdout);
	cin>>sig.x1>>sig.y1>>sig.x2>>sig.y2;
	cin>>wal.x1>>wal.y1>>wal.x2>>wal.y2;
	cin>>mir.x1>>mir.y1>>mir.x2>>mir.y2;
	cal(sig);
	cal(wal);
	cal(mir);
	if(!hasn(sig, wal) && !hasn(sig, mir))	printf("YES");
	else if(hasn(sig, wal)){
		cc();
		if(hasn(sig, mir))	printf("YES");
		else				printf("NO");
	}
	else printf("NO");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
