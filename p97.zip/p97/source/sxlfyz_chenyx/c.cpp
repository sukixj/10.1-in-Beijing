#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <queue>
using namespace std;
struct Node{
	int clr[5];//udlr
};//rgbo=1234
struct NNN{
	Node a[5][5];
	int ste;
}h;
bool havr[5], havc[5], kkk[5];
queue<NNN> d;
char x[10];
int bel[5][5][5], maxxx;
void ranse(NNN h, int x, int y, int c, int s){
	bel[x][y][c] = s;
	if(c==1){
		if(!bel[x][y][3] && h.a[x][y].clr[c]==h.a[x][y].clr[3])
			ranse(h, x, y, 3, s);
		if(!bel[x][y][4] && h.a[x][y].clr[c]==h.a[x][y].clr[4])
			ranse(h, x, y, 4, s);
		if(x>1 && !bel[x-1][y][2] && h.a[x][y].clr[c]==h.a[x-1][y].clr[2])
			ranse(h, x-1, y, 2, s);
	}
	if(c==2){
		if(!bel[x][y][3] && h.a[x][y].clr[c]==h.a[x][y].clr[3])
			ranse(h, x, y, 3, s);
		if(!bel[x][y][4] && h.a[x][y].clr[c]==h.a[x][y].clr[4])
			ranse(h, x, y, 4, s);
		if(x<3 && !bel[x+1][y][1] && h.a[x][y].clr[c]==h.a[x+1][y].clr[1])
			ranse(h, x+1, y, 1, s);
	}
	if(c==3){
		if(!bel[x][y][1] && h.a[x][y].clr[c]==h.a[x][y].clr[1])
			ranse(h, x, y, 1, s);
		if(!bel[x][y][3] && h.a[x][y].clr[c]==h.a[x][y].clr[3])
			ranse(h, x, y, 3, s);
		if(y>1 && !bel[x][y-1][4] && h.a[x][y].clr[c]==h.a[x][y-1].clr[4])
			ranse(h, x, y-1, 4, s);
	}
	if(c==4){
		if(!bel[x][y][1] && h.a[x][y].clr[c]==h.a[x][y].clr[1])
			ranse(h, x, y, 1, s);
		if(!bel[x][y][3] && h.a[x][y].clr[c]==h.a[x][y].clr[3])
			ranse(h, x, y, 3, s);
		if(y<3 && !bel[x][y+1][3] && h.a[x][y].clr[c]==h.a[x][y+1].clr[3])
			ranse(h, x, y+1, 3, s);
	}
}
bool check(NNN h){
	int ind=0;
	memset(bel, 0, sizeof(bel));
	for(int i=1; i<=3; i++)
		for(int j=1; j<=3; j++)
			for(int k=1; k<=4; k++){
				if(!bel[i][j][k]){
					ind++;
					ranse(h, i, j, k, ind);
				}
			}
	if(ind>maxxx)	return false;
	return true;
}
void movr(NNN &j, int r, int p){
	if(p){
		for(int i=0; i<3; i++)
			j.a[r][i] = j.a[r][i+1];
		j.a[r][3] = j.a[r][0];
	}
	else{
		for(int i=4; i>=2; i--)
			j.a[r][i] = j.a[r][i-1];
		j.a[r][1] = j.a[r][4];
	}
}
void movc(NNN &j, int c, int p){
	if(p){
		for(int i=0; i<3; i++)
			j.a[i][c] = j.a[i+1][c];
		j.a[3][c] = j.a[0][c];
	}
	else{
		for(int i=4; i>=2; i--)
			j.a[i][c] = j.a[i-1][c];
		j.a[1][c] = j.a[4][c];
	}
}
void bfs(){
	while(!d.empty()){
		NNN k=d.front();
		d.pop();
		/*printf("---------\n%d:\n", k.ste);
		for(int i=1; i<=3; i++){
			for(int j=1; j<=3; j++){
				for(int jjj=1; jjj<=4; jjj++)
					printf("%d", k.a[i][j].clr[jjj]);
				printf(" ");
			}
			printf("\n");
		}
			*/	
		k.ste++;
		NNN j=k;
		for(int i=1; i<=3; i++){
			if(!havr[i]){
				j = k;
				movr(j, i, 0);
				if(check(j)){
					cout<<j.ste;
					exit(0);
				}
				d.push(j);
				j = k;
				movr(j, i, 1);
				if(check(j)){
					cout<<j.ste;
					exit(0);
				}
				d.push(j);
			}
			if(!havc[i]){
				j = k;
				movc(j, i, 0);
				if(check(j)){
					cout<<j.ste;
					exit(0);
				}
				d.push(j);
				j = k;
				movc(j, i, 1);
				if(check(j)){
					cout<<j.ste;
					exit(0);
				}
				d.push(j);
			}
		}
	}
}
int main(){
	freopen("c.in", "r", stdin);
	freopen("c.out", "w", stdout);
	/*for(int i=1; i<=3; i++)
		for(int j=1; j<=3; j++){
			scanf("%s", x+1);
			for(int k=1; k<=4; k++){
				if(x[k]=='R')	h.a[i][j].clr[k] = 1;
				if(x[k]=='G')	h.a[i][j].clr[k] = 2;
				if(x[k]=='B')	h.a[i][j].clr[k] = 3;
				if(x[k]=='O')	h.a[i][j].clr[k] = 4;
				kkk[h.a[i][j].clr[k]] = true;
			}
			if(x[5]=='1')	havr[i] = havc[j] = true;
			
		}
	for(int i=1; i<=4; i++)
		maxxx += kkk[i];
	if(check(h)){
		cout<<"0";
		return 0;
	}
	h.ste = 0;
	d.push(h);
	bfs();*/
	printf("4");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
