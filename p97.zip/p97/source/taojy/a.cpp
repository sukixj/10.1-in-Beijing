#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<cmath>

using namespace std;

int n,maxn,minn=1010101,tmp,q;
int cnt[1010][30];
char ch[1010];

int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",&ch);
	cnt[0][ch[0]-'a']=1;tmp=1;
	for(int i=1;i<n;i++)
	{
		minn=1010101;maxn=0;
		for(int j=0;j<26;j++)cnt[i][j]=cnt[i-1][j];
	    cnt[i][ch[i]-'a']++;
	    for(int j=0;j<26;j++)
		{
		    if(cnt[i][j]<minn && cnt[i][j]>0)minn=cnt[i][j];
		    if(cnt[i][j]>maxn)maxn=cnt[i][j];
		}
		if(maxn-minn>tmp)tmp=maxn-minn;
    }   
    for(int q=1;q<n;q++)
    {
        for(int i=0;i<q;i++)
        {
        	maxn=0;minn=1010101;
        	for(int j=0;j<26;j++)
        	{
    	    	if(cnt[q][j]-cnt[i][j]>maxn)maxn=cnt[q][j]-cnt[i][j];
    	    	if(cnt[q][j]-cnt[i][j]<minn && cnt[q][j]-cnt[i][j]>0)minn=cnt[q][j]-cnt[i][j];
    	    	if(maxn-minn>tmp)tmp=maxn-minn;
    	    }
        }
    }
    printf("%d",tmp);
	return 0;
}
