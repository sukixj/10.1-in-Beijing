#include<bits/stdc++.h>
inline const void read(int &a)
{
	a=0;
	char c=getchar();
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'&&c<='9')
	{
		a=(a<<1)+(a<<3)+c-'0';
		c=getchar();
	}
}
inline const void write(int a)
{
	if(a>=10)write(a/10);
	putchar(a%10+'0');
}
std::map<char,int> appear;
int big=0,small=INT_MAX;
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	int n;
	read(n);
	for(int i=1;i<=n;i++)
	{
		char c=getchar();
		while(c<'a'||c>'z')c=getchar();
		appear[c]++;
		big=std::max(appear[c],big);
	}
	for(int i=0;i<='z'-'a';i++)if(appear['a'+i]>=1)small=std::min(appear['a'+i],small);
	write(big-small);
	return 0;
}
