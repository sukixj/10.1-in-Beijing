#include<bits/stdc++.h>
inline const void read(double &a)
{
	a=0;double b=1;
	char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')b=-1;c=getchar();}
	while(c>='0'&&c<='9')
	{
		a=a*10+c-'0';
		c=getchar();
	}
	a*=b;
}
double xs,ys,xe,ye,xw1,yw1,xw2,yw2,xm1,ym1,xm2,ym2;
class line
{
	public:
		double xstart,xend,ystart,yend,x,y;
		void init(double a,double b,double c,double d)
		{xstart=a;ystart=b;xend=c;yend=d;x=xend-xstart;y=yend-ystart;}
		inline const double operator*(const line&b){return b.x*y-x*b.y;}
		inline const bool common(const line&b)
		{
			line c,d,e,f;
			c.init(xstart,ystart,b.xstart,b.ystart);d.init(xstart,ystart,b.xend,b.yend);
			e.init(xend,yend,b.xstart,b.ystart);f.init(xend,yend,b.xend,b.yend);
			if((c*d)*(e*f)>=0)return false;
			else return true;
		}
}sight,wall,mirror,conf;
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	read(xs);read(ys);read(xe);read(ye);sight.init(xs,ys,xe,ye);
	read(xw1);read(yw1);read(xw2);read(yw2);wall.init(xw1,yw1,xw2,yw2);
	read(xm1);read(ym1);read(xm2);read(ym2);mirror.init(xm1,ym1,xm2,ym2);
	if(!sight.common(mirror)&&!sight.common(wall)){std::cout<<"YES";exit(0);}
	if(!sight.common(wall)&&sight.common(mirror)){std::cout<<"NO";exit(0);}
	else
	{
		double xconf,yconf,a,b=-1,c;
		a=(ym2-ym1)/(xm2-xm1);c=ym1-a*xm1;
		double t=-(a*xe+b*ye+2*c);
		xconf=(t-b/a*xe-b*ye)/(a-b/a);yconf=(xe-xconf)/a+ye;
		conf.init(xs,ys,xconf,yconf);
		if(!conf.common(mirror)){std::cout<<"NO";exit(0);}
		double aa,bb=-1,cc;
		aa=(yconf-ys)/(xconf-xs);cc=yconf-aa*xconf;
		double xj=(cc-c)/(a-aa),yj=a*xj+c;
		conf.init(xj,yj,xs,ys);
		if(conf.common(wall)){std::cout<<"NO";exit(0);}
		conf.init(xj,yj,xe,ye);
		if(conf.common(wall)){std::cout<<"NO",exit(0);}
		std::cout<<"YES";
	}
	return 0;
}
