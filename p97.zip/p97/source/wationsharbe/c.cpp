#include<bits/stdc++.h>
int main()
{
	freopen("c.out","w",stdout);
	std::cout<<1;
	return 0;
}
