#include<iostream>
#include<fstream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>

using namespace std;

int N;
char c[100010];
int ans[26], max_ans;
int mx, mn;

int main(){
	ifstream fin("a.in");
	ofstream fout("a.out");
	
	fin >> N;
	for(int i = 1;i <= N;i++){
		fin >> c[i];
	}
	
	for(int i = 1;i <= N;i++){
		memset(ans, 0, 26);
		for(int j = i;j <= N;j++){
			mx = 0;
			mn = j - i + 1;
			
			ans[int(c[j]) - 97]++;
			for(int k = 0;k < 26;k++){
				mx = max(mx, ans[k]);
				if(ans[k] != 0){
					mn = min(mn, ans[k]);
				}
			}
			
			max_ans = max(max_ans, mx - mn);
		}
	}
	/*for(int i = 1;i < N;i++){
		for(int j = i + 1;j <= N;j++){
			memset(ans, 0, 26);
			mx = 0;
			mn = N;
			
			for(int k = i;k <= j;k++){
				ans[int(c[k] - 97)]++;
			}
			
			for(int o = 0;o < 26;o++){
				mx = max(mx, ans[o]);
				if(ans[o] != 0){
					mn = min(mn, ans[o]);
				//	cout << o << "!" << ans[o] << endl;
				}
			}
			
			max_ans = max(max_ans, mx - mn);
			
			for(int o = 0;o < 26;o++){
			//	cout << ans[o] << endl;
			}
			//  cout << i << " " << j << endl << mx << " " << mn << endl << endl;
		}
	}*/
	
	fout << max_ans << endl;
	return 0;
}
