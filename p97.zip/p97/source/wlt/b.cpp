#include<iostream>
#include<fstream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>

using namespace std;

int Xv, Yv, Xp, Yp;
int Xpm, Ypm;
int Xw1, Yw1, Xw2, Yw2;
int Xm1, Ym1, Xm2, Ym2;
int Xw1m, Yw1m, Xw2m, Yw2m;

double reflect_X(int X10, int Y10, int X11, int Y11, int X, int Y){
	if(X10 != X11 && Y10 != Y11){
		double K1 = double(Y10 - Y11) / double(X10 - X11);
		double B1 = Y10 - K1 * X10;
		
		return ((1 / K1 - K1) * X + 2 * Y - 2 * B1) / (1 / K1 + K1);
	}
	else if(X10 == X11){
		return (2 * X10 - X);
	}
	else{
		return X;
	}
}

double reflect_Y(int X10, int Y10, int X11, int Y11, int X, int Y){
	if(X10 != X11 && Y10 != Y11){
		double K1 = double(Y10 - Y11) / double(X10 - X11);
		double B1 = Y10 - K1 * X10;
		
		double Xm = ((1 / K1 - K1) * X + 2 * Y - 2 * B1) / (1 / K1 + K1);
		//cout << "!" << X << " " << Xm;
		return (X - Xm) / K1 + Y;
	}
	else if(Y10 == Y11){
		return (2 * Y10 - Y);
	}
	else{
		return Y;
	}
}

bool judge(int X10, int Y10, int X11, int Y11, int X20, int Y20, int X21, int Y21){
	if(X10 != X11 && X20 != X21){
		double K1 = double(Y10 - Y11) / double(X10 - X11);
		double K2 = double(Y20 - Y21) / double(X20 - X21);
		double B1 = Y10 - K1 * X10;
		double B2 = Y20 - K2 * X20;
		
		if(fabs(K1 - K2) <= 0.000001){
			return false;
		}
	
		double X = double(B2 - B1) / double(K1 - K2);
	
		if(X <= max(X10, X11) + 0.000001 && X >= min(X10, X11) - 0.000001 && X <= max(X20, X21) +0.000001 && X >= min(X20, X21) - 0.000001){
			return true;
		}
		else{
			return false;
		}
	}
	else if(X10 == X11){
		if(X20 == X21 && X20 == X10){
			return false;
		}
		
		if(X10 > max(X20, X21) || X10 < min(X20, X21)){
			return false;
		}
		
		double K2 = double(Y20 - Y21) / double(X20 - X21);
		double B2 = Y20 - K2 * X20;

		double Y = K2 * X10 + B2;
	
		if(Y <= max(Y10, Y11) + 0.000001 && Y >= min(Y10, Y11) - 0.000001 && Y <= max(Y20, Y21) + 0.000001 && Y >= min(Y20, Y21) - 0.000001){
			return true;
		}
		else{
			return false;
		}
	}
	else if(X20 == X21){
		if(X20 == X21 && X20 == X10){
			return false;
		}
		
		if(X20 > max(X10, X11) || X20 < min(X10, X11)){
			return false;
		}
		
		double K1 = double(Y10 - Y11) / double(X10 - X11);
		double B1 = Y10 - K1 * X10;

		double Y = K1 * X20 + B1;

		if(Y <= max(Y10, Y11) + 0.000001 && Y >= min(Y10, Y11) - 0.000001 && Y <= max(Y20, Y21) + 0.000001 && Y >= min(Y20, Y21) - 0.000001){
			return true;
		}
		else{
			return false;
		}
	}
}

int main(){
	ifstream fin("b.in");
	ofstream fout("b.out");
	
	fin >> Xv >> Yv >> Xp >> Yp;
	fin >> Xw1 >> Yw1 >> Xw2 >> Yw2;
	fin >> Xm1 >> Ym1 >> Xm2 >> Ym2;

	Xpm = reflect_X(Xm1, Ym1, Xm2, Ym2, Xp, Yp);
	Ypm = reflect_Y(Xm1, Ym1, Xm2, Ym2, Xp, Yp);
	
	Xw1m = reflect_X(Xm1, Ym1, Xm2, Ym2, Xw1, Yw1);
	Yw1m = reflect_Y(Xm1, Ym1, Xm2, Ym2, Xw1, Yw1);
	Xw2m = reflect_X(Xm1, Ym1, Xm2, Ym2, Xw2, Yw2);
	Yw2m = reflect_Y(Xm1, Ym1, Xm2, Ym2, Xw2, Yw2);
	
	if((!judge(Xv, Yv, Xp, Yp, Xw1, Yw1, Xw2, Yw2) && !judge(Xv, Yv, Xp, Yp, Xm1, Ym1, Xm2, Ym2)) || (!judge(Xv, Yv, Xpm, Ypm, Xw1, Yw1, Xw2, Yw2) && !judge(Xv, Yv, Xpm, Ypm, Xw1m, Yw1m, Xw2m, Yw2m) && judge(Xv, Yv, Xpm, Ypm, Xm1, Ym1, Xm2, Ym2))){
		fout << "YES" << endl;
	}
	else{
		fout << "NO" << endl;
	}
	return 0;
}
