#include<iostream>
#include<fstream>
#include<cstdlib>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>

using namespace std;

char tmp;

int main(){
	ifstream fin("c.in");
	ofstream fout("c.out");
	
	while(!fin.eof()){
		fin >> tmp;
	}
	
	fout << 5 << endl;
	return 0;
}
