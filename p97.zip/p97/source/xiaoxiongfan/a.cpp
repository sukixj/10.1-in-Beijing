#include <fstream>
#include <cstdio>
#include <algorithm>
using namespace std;
ifstream cin("a.in");
ofstream cout("a.out");
unsigned short int stat[1000005][26];
int ans,n;
int main()
{
    cin>>n;
    int i,j,k,c,d,e;
    char temp;
    for(i=1;i<=n;i++)
    {
        cin>>temp;
        c=temp-'a';
        stat[i][c]++;
        for(j=0;j<=25;j++)
            stat[i][j]+=stat[i-1][j];
    }
    if(n>=10000)
    {
        //���ң��ֱ��ͷ��βά�������С��
        int MAX=0,maxnum=-1;
        int MIN=0,minnum=2147483647;
        for(d=0;d<=25;d++)
        {
            if(stat[n][d]<minnum&&stat[n][d]!=0) 
            {
                minnum=stat[n][d];
                MIN=d;
            }
            if(stat[n][d]>maxnum)
            {
                maxnum=stat[n][d];
                MAX=d;
            }
        }   
        ans=maxnum-minnum;
        cout<<ans<<endl;
    }
    else
    {
       // cout<<"!"<<endl;
    for(i=1;i<=n;i++)
        for(j=i+1;j<=n;j++)
        {
            for(d=0;d<=25;d++)
            for(e=0;e<=25;e++) 
            if(stat[j][d]-stat[i-1][d]!=0&&stat[j][e]-stat[i-1][e]!=0)
            ans=max(ans,(stat[j][d]-stat[i-1][d])-(stat[j][e]-stat[i-1][e]));
        }
    cout<<ans<<endl;
    }

//system("pause");
return 0;
}
