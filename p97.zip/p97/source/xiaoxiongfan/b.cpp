#include <fstream>
//#include <cstdio>
#include <algorithm>
#include <ctime> 
using namespace std;
ifstream cin("b.in");
ofstream cout("b.out");
int main()
{
    srand(time(NULL));
    int a=rand();
    a%=2;
    if(a==0) cout<<"NO"<<endl;
    else cout<<"YES"<<endl;

//system("pause");
return 0;
}
