#include <iostream>
#include <cstdio>
#include <algorithm>
#include <ctime>
using namespace std;
int main()
{
    srand(time(NULL));
    int a=rand();
    a%=64;
    cout<<a<<endl;

system("pause");
return 0;
}
