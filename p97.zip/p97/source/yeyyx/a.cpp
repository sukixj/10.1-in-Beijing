#include<iostream>
#include<cstdio>

using namespace std;
int maxn,nu,a[1000005],n[1000005];
int fmax(){
	int maxx=0;
	for(int i=1;i<=26;i++){
		if(maxx<n[i])maxx=n[i];
	}
	return maxx;
}
int fmin(){
	int minx=10000000;
	for(int i=1;i<=26;i++){
		if(minx>n[i]&&n[i])minx=n[i];
	}
	return minx;
}

int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&nu);
	for(int i=1;i<=nu;i++){
		char t;
		scanf("%c",&t);
		if(t>='a'&&t<='z')
			a[i]=(int)t-'a'+1;
		else i--;
	}
	//for(int i=1;i<=26;i++)cout<<a[i]<<" ";
	//cout<<endl;
	int maxn=0;
	for(int k=nu;k>1;k--){
		for(int i=1;i<=26;i++)n[i]=0;
		for(int i=1;i<=k;i++){
			++n[a[i]];
		}
		
		for(int l=1;l<=nu-k+1;l++){
			int nmax=fmax();
			int nmin=fmin();
			if(maxn<nmax-nmin) maxn=nmax-nmin;
			n[a[l]]--;
			n[a[l+k]]++;
			//cout<<nmax<<" "<<nmin<<" "<<k<<endl;
		}
	}
	printf("%d\n",maxn);
	return 0;
}
