#include<iostream>
#include<cstdio>

using namespace std;
double gety(double x,double zx1,double zy1,double zx2,double zy2){
	return x*(zy1-zy2)+zx1*zy2-zy1*zx2;
}
int judge(double a,double b,double p,double q,double zx1,double zy1,double zx2,double zy2){
	double yt1=gety(a,zx1,zy1,zx2,zy2);
	double yt2=gety(p,zx1,zy1,zx2,zy2);
	if((yt1-b*(zx1-zx2))*(yt2-q*(zx1-zx2))>=0) return 1;
	return 0;
}
bool judge2(double a,double b,double p,double q,double zx1,double zy1,double zx2,double zy2){
	if(!judge(a,b,p,q,zx1,zy1,zx2,zy2)&&!judge(zx1,zy1,zx2,zy2,a,b,p,q))
		return 1;
	return 0;
}//�����߶��Ƿ��н��� 
double x1,x2,y1,y2,xm1,xm2,xw1,xw2,ym1,ym2,yw1,yw2;
int main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	
	scanf("%lf%lf %lf%lf",&x1,&y1,&x2,&y2);
	if(x1<x2){
		double t=x1;x1=x2;x2=t;
			t=y1;y1=y2;y2=t;
	}
	scanf("%lf%lf%lf%lf",&xw1,&yw1,&xw2,&yw2);
	scanf("%lf%lf%lf%lf",&xm1,&ym1,&xm2,&ym2); 
	
	if(!judge(x1,y1,x2,y2,xm1,ym1,xm2,ym2)){//���ھ���ͬ�� 
		if(judge2(xm1,ym1,xm2,ym2,x1,y1,x2,y2)){
			printf("NO\n");
		}
		else{
			if(judge2(x1,y1,x2,y2,xw1,yw1,xw2,yw2)){
				printf("NO\n");
			}
			else if((y1-y2)*(xw1-xw2)==(yw1-yw2)*(x1-x2)&&(y1-yw2)*(xw1-x2)==(x1-xw2)*(yw1-y2))
				printf("NO\n");
			else printf("YES\n");
		}
	}
	else{//�ھ���ͬ�� 
		double x1t= x1-2*(ym1-ym2)*(x1*(ym1-ym2)-y1*(xm1-xm2)+xm1*ym2-ym1*xm2)/((ym1-ym2)*(ym1-ym2)+(xm1-xm2)*(xm1-xm2));
		double x2t= x2-2*(ym1-ym2)*(x2*(ym1-ym2)-y2*(xm1-xm2)+xm1*ym2-ym1*xm2)/((ym1-ym2)*(ym1-ym2)+(xm1-xm2)*(xm1-xm2));
		double y1t= y1-2*(xm2-xm1)*(x1*(ym1-ym2)-y1*(xm1-xm2)+xm1*ym2-ym1*xm2)/((ym1-ym2)*(ym1-ym2)+(xm1-xm2)*(xm1-xm2));
		double y2t= y2-2*(xm2-xm1)*(x2*(ym1-ym2)-y2*(xm1-xm2)+xm1*ym2-ym1*xm2)/((ym1-ym2)*(ym1-ym2)+(xm1-xm2)*(xm1-xm2));
		if(judge2(x1,y1,x2t,y2t,xw1,yw1,xw2,yw2)||judge2(x1t,y1t,x2,y2,xw1,yw1,xw2,yw2))
			printf("NO\n");
		else printf("YES\n");
	} 
	
	return 0;
}
