#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#include<map>
using namespace std;


struct hanshu
{
	double x;
	double y;
	double k;
	double b;
}a[15];

template<class T>void read(T &x)
{
	int f = 0;
	x = 0;
	char ch = getchar();
	while(ch < '0' || ch >'9')
	  {
	  	f |= (ch == '-');
	  	ch = getchar();
	  }
	while(ch >= '0' && ch <='9')
	  {
	  	x = (x << 1) + (x << 3) + (ch ^ 48);
	  	ch = getchar();
	  }
	x = f? -x : x;
}
void write(int x)
{
	if(x < 0)
	  {
	  	putchar('-');
	  	x = -x;
	  }
	if(x > 9)
	  {
	  	write(x / 10);
	  }
	putchar(x % 10 + '0');
}
void work1(int i, int j)
{
	if(a[j].x - a[i].x == 0)
	  {
	  	a[i].k = 999;
	  	return;
	  }
	a[i].k = (a[j].y - a[i].y) / (a[j].x - a[i].x);
	a[i].b = a[i].y - (a[i].k * a[i].x);
}
void work2()
{
	if(a[6].k == 999)
	  {
	  	a[7].k = 0;
	  	a[7].b = a[1].y;
	  	return;
	  }
	a[7].k = -a[6].k;
	a[7].b = a[1].y - (a[7].k * a[1].x);
}
void work3(int i, int j, int k)
{
	int jjj, iii;
	if((a[i].k == 999 || a[j].k == 999) && a[i].k != a[j].k)
	  {
	  	if(a[i].k == 999)
	  	  {
	  	  	  jjj = i;
	  	  	  iii = j;
		  }
		if(a[j].k == 999)
		  {
		  	jjj = j;
		  	iii = i;
		  }
		a[k].x = a[jjj].x;
		a[k].y = a[iii].k * a[k].x;
		return;
	  }
	a[k].x = (a[j].b - a[i].b) / (a[i].k - a[j].k);
	a[k].y = (a[i].k * a[k].x) + a[i].b;
}
void work4()
{
	a[8].x = (2 * a[7].x) - a[1].x;
	a[8].y = (2 * a[7].y) - a[1].y;
}
int ans()
{
	int xma = max(a[3].x, a[4].x);
	int xmi = min(a[3].x, a[4].x);
	int yma = max(a[3].y, a[4].y);
	int ymi = min(a[3].y, a[4].y);
	if(a[9].x >= xmi && a[9].x <= xma && a[9].y >= ymi && a[9].y <= yma)
	  {
	  	return 0;
	  }
	else
	  if(a[10].x >= xmi && a[10].x <= xma && a[10].y >= ymi && a[10].y <= yma)
	    {
	    	return 0;
		}
	  else return 1;
}
void shuchu(int i)
{
	printf("%lf\n", a[6].x);
	printf("%lf\n", a[6].y);
	printf("%lf\n", a[6].k);
	printf("%lf\n", a[6].b);
}
int main()
{
	freopen("b.in","r",stdin);
//	freopen("b.out","w",stdout);
	for(int i = 1; i <= 6; i++)
	  {
	  	scanf("%lf", &a[i].x);
	  	scanf("%lf", &a[i].y);
	  }
	work1(6, 5);
//	shuchu(6);
	work2();
	work3(6, 7, 7);
	work4();
	work1(1, 2);
	work1(8, 2);
	work1(3, 4);
	work3(1, 3, 9);
	work3(8, 3, 10);
	if(ans == 0) cout << "NO";
	else cout << "YES";
//	printf("%lf\n", a[6].k);
//	printf("%lf\n", a[6].b);
//	printf("%lf\n", a[7].k);
//	for(int i = 1; i <= 6; i++)
//	  {
//	  	printf("%.0lf\n", a[i].x);
//	  	printf("%.0lf\n", a[i].y);
//	  }
	fclose(stdin);fclose(stdout);
	return 0;
}
