#include<iostream>
#include<cstdio>
using namespace std;
char str[1001000];
int q[1001000];
int n,ans=0,ma=0,mi=1,k;
int main()
{
	freopen("a.in.txt","r",stdin);
	freopen("a.out.txt","w",stdout);
	cin>>n>>str;
	q[ma]=0; 
	q[mi]=0x7f;
	for(int i=0;i<n;i++)
	{
		k=str[i]-48;
		q[k]++;
		if(q[k]>q[ma]) ma=k;
		if(q[k]<q[mi]) mi=k;
		if(q[ma]-q[mi]>ans) ans=q[ma]-q[mi];
	}
	cout<<ans;
}
