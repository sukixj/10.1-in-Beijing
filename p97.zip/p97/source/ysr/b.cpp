#include<iostream>
#include<cstdio>
using namespace std;
struct xd {int x1,x2,y1,y2;};
xd j,q;
int xa,ya,xb,yb;
int main()
{
	freopen("b.in.txt","r",stdin);
	freopen("b.out.txt","w",stdout);
	cin>>xa>>ya>>xb>>yb;
	cin>>q.x1>>q.y1>>q.x2>>q.y2;
	cin>>j.x1>>j.y1>>j.x2>>j.y2;
	if(xa==xb)
	{
		if(q.x1==q.x2&&j.x1==j.x2)
		{
			cout<<"YES";
			return 0;
		}
		if(q.y1>ya&&q.y1>yb&&q.y2>ya&&q.y2>yb&&j.y1>ya&&j.y1>yb&&j.y2>ya&&j.y2>yb)
		{
			cout<<"YES";
			return 0;
		}
		if(q.y1<ya&&q.y1<yb&&q.y2<ya&&q.y2<yb&&j.y1<ya&&j.y1<yb&&j.y2<ya&&j.y2<yb)
		{
			cout<<"YES";
			return 0;
		}
	}
	if(ya==yb)
	{
		if(q.y1==q.y2&&j.y1==j.y2)
		{
			cout<<"YES";
			return 0;
		}
		if(q.x1>xa&&q.x1>xb&&q.x2>xa&&q.x2>xb&&j.x1>xa&&j.x1>xb&&j.x2>xa&&j.x2>xb)
		{
			cout<<"YES";
			return 0;
		}
		if(q.x1<xa&&q.x1<xb&&q.x2<xa&&q.x2<xb&&j.x1<xa&&j.x1<xb&&j.x2<xa&&j.x2<xb)
		{
			cout<<"YES";
			return 0;
		}
	}
	    if(q.y1>ya&&q.y1>yb&&q.y2>ya&&q.y2>yb&&j.y1>ya&&j.y1>yb&&j.y2>ya&&j.y2>yb)
		{
			cout<<"YES";
			return 0;
		}
		if(q.y1<ya&&q.y1<yb&&q.y2<ya&&q.y2<yb&&j.y1<ya&&j.y1<yb&&j.y2<ya&&j.y2<yb)
		{
			cout<<"YES";
			return 0;
		}
		if(q.x1>xa&&q.x1>xb&&q.x2>xa&&q.x2>xb&&j.x1>xa&&j.x1>xb&&j.x2>xa&&j.x2>xb)
		{
			cout<<"YES";
			return 0;
		}
		if(q.x1<xa&&q.x1<xb&&q.x2<xa&&q.x2<xb&&j.x1<xa&&j.x1<xb&&j.x2<xa&&j.x2<xb)
		{
			cout<<"YES";
			return 0;
		}
	cout<<"NO";
	return 0;
}
