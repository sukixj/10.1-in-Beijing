#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<queue>
using namespace std;
#define N 1000005

int n;
int ans;
char s[N];
int tot[150]; // 128 �ַ� 

struct node {int x;};
bool operator < (const node &a,const node &b) {return tot[a.x]>tot[b.x];} // da
priority_queue<node>qx; // xiao
struct data {int x;};
bool operator < (const data &a,const data &b) {return tot[a.x]<tot[b.x];} // wls wly
priority_queue<data>qd; // da 

int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",s+1);
	for(int i=1;i<=n;++i) {
		memset(tot,0,sizeof(tot));
		while(!qx.empty()) qx.pop();
		while(!qd.empty()) qd.pop();	
		if(!tot[s[i]]) qx.push((node){s[i]}),qd.push((data){s[i]});
		tot[s[i]]++;
		for(int j=i+1;j<=n;++j) {
			if(!tot[s[j]]) qx.push((node){s[j]}),qd.push((data){s[j]});
			tot[s[j]]++;
			if(qx.top().x!=qd.top().x) ans=max(ans,tot[qd.top().x]-tot[qx.top().x]); 
		}
	}
	printf("%d\n",ans);
	return 0;
}
/*
10
aabbaaabab
*/
