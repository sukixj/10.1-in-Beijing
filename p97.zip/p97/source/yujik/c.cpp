#include<iostream>
#include<cstdio>
using namespace std;
#define N 5

char s[N][N];

int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	for(int i=1;i<=3;++i) {
		for(int j=1;j<=3;++j) {
			scanf("%s",s[i][j]);
		}
	}
	cout<<"5"<<endl;
	return 0;
}
