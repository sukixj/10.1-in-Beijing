#include<iostream>
#include<cstring>
#include<fstream>

using namespace std;

int n;
char ch[1000005];

int main()
{
	int word0[150],word[150],ans,tmp,ma=0,mi=1000005;
	
	ifstream fin("a.in");
	ofstream fout("a.out");
	
	fin>>n;
	for(int i=97;i<=122;i++)	word0[i]=0;
	for(int i=1;i<=n;i++)	
	{
		fin>>ch[i];
		tmp=ch[i];
		word0[tmp]++;
	}
	
	for(int i=97;i<=122;i++)	word[i]=word0[i];
	
	for(int i=1;i<n;i++)
	{
		for(int g=97;g<=122;g++)	word[g]=word0[g];	
		for(int j=n;j>i;j--)
		{
			ma=0;
			mi=1000005;
			for(int i=97;i<=122;i++)
			{
				if(word[i]==0)	continue;
				ma=max(ma,word[i]);
				mi=min(mi,word[i]);																					
			}
			ans=max(ans,ma-mi);
			tmp=ch[j];
			word[tmp]--;
		}
		tmp=ch[i];
		word0[tmp]--;
	}
	
	fout<<ans;
	
	return 0;
}

