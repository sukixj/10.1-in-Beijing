#include<iostream>
#include<fstream>

using namespace std;
double xv,yv,xp,yp,xw1,yw1,xw2,yw2,xm1,ym1,xm2,ym2,k1,b1,k2,b2,kw,bw,km,bm,xp2,yp2;
bool flagp,flagp2,flagw,flagm,flag;

void judgem2()
{
	double x,y;
	x=(bm-b2)/(k2-km);
	if(xm1<=xm2)
	{
		if(x>=xm1&&x<=xm2)
			fout<<"YES";									
		else
			fout<<"NO";								
	}
	else
	{
		if(x>=xm2&&x<=xm1)
			fout<<"YES";
								
		else
			fout<<"NO";

	}
}

void judgew(int k,int b)
{
	double x,y;
	x=(bw-b)/(k-kw);
	if(xw1<=xw2)
	{
		if(x>=xw1&&x>=xw2)
			fout<<"YES";
		if(x<=xw1&&x<=xw2)
			fout<<"YES";
		else
			fout<<"NO";
	}
}

int main()
{
	
	ifstream fin("b.in");
	ofstream fout("b.out");
	fin>>xv>>yv>>xp>>yp>>xw1>>yw1>>xw2>>yw2>>xm1>>ym1>>xm2>>ym2;
	
	if(xv==xp)	xp=xv+0.01;
	if(xw2==xw1)	xw2=xw1+0.01;
	if(xm1==xm2)	xm2=xm1+0.01;
	k1=(yp-yv)/(xp-xv);
	b1=yp-k1*xp;
	kw=(yw2-yw1)/(xw2-xw1);
	bw=yw1-kw*xw1;
	km=(ym2-ym1)/(xm2-xm1);
	bm=ym1-km*xm1;
	xp2=(2*km*yp-(km*km-1)*xp-2*bm*km)/(km*km+1);
	yp2=(2*km*xp+(km*km-1)*yp+2*bm)/(km*km+1);
	if(xv==xp2)	xp2=xv+0.01;
	k2=(yp2-yv)/(xp2-xv);
	b2=yp2-k1*xp2;

	if(km==k2)
	{
		if(k2==kw)
		{
			fout<<"YES";
			return 0;
		}
		else
		{
			judgew(k2,b2);
			return 0;
		}
	}
	else
	{
		judgem2();
		return 0;
	}
	
	judgew(k1,b1);
	
	return 0;
}
