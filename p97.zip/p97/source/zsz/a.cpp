#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int l;
char s[100005];
int num[27];
void init(){
    cin >> l;
    cin >> s;
}
int work(int i, int j){
    for(int k = i; k <= j; k++){
    	num[s[k] - 'a' + 1]++;
    }
	sort(num + 1, num + 1 + 26);
	int k = 1;
	while(num[k] == 0) k++;
	return (num[26] - num[k]);
}
int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
    init();
    int Max = -1;
    for(int i = 0; i < l; i++){
    	for(int j = i; j < l; j++){
    		if(j - i <= Max)
    			continue;
    		memset(num, 0, sizeof(num));
    		int Ans = work(i, j);
			if(Ans > Max)
    			Max = Ans;
		}
	}
	cout << Max << endl;
    return 0;
}
