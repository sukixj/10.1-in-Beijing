#include<iostream>
#include<cstdio>
using namespace std;
int a,b,c,d,aa,bb,cc,dd,aaa,bbb,ccc,ddd;
int main()
{
  freopen("b.in","r",stdin);
  freopen("b.out","w",stdout);
  scanf("%d%d",&a&b);	
  scanf("%d%d",&c&d);
  scanf("%d%d%d%d",&aa&bb&cc&dd);	
  scanf("%d%d%d%d",%aaa%bbb%ccc%ddd);	
cout<<"NO"<<endl;	
	
	
	
	
	
	
	
	
	return 0;
}
