#include<ctime>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
using namespace std;
int main() {
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	srand(time(0)+20001120);
	int n=rand(),Min=-1;
	for(int i=1;i<=n;i++)
		Min=min(rand(),Min);
	for(int i=1;i;i++) {
		if(Min%rand()==0) {
			printf("%d",i);
			fclose(stdin);
			fclose(stdout);
			return 0;
		}
		if(i>=25) break;
	}
	int ans=(rand()+Min-n)%15+1;
	if(ans<0) ans=-ans;
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
