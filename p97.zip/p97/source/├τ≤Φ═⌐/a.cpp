#include<iostream>
using namespace std;
int n,i,j,num[27],now[27],mx;
char c[1000001];
int getmx(int x[])
{
	int mx=0,mn=1e7;
	for(int i=0;i<26;i++)
	  if(x[i])
	    mx=max(mx,x[i]),mn=min(mn,x[i]);
	return mx-mn;
}
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	cin>>n;c[0]=getchar();
	for(i=1;i<=n;i++)
	  c[i]=getchar();
	for(i=1;i<=n;i++)
	{
		num[c[i]-'a']++;
		for(j=0;j<26;j++)now[j]=num[j];
		for(j=1;j<i;j++)
		  now[c[j]-'a']--,mx=max(mx,getmx(now));
	}
	cout<<mx;
	return 0;
}
