#include<iostream>
using namespace std;
double x1,y1,x2,y2,mx1,my1,mx2,my2,wx1,wy1,wx2,wy2;
double k,b,l,r,x,y;
double wk,wb,wl,wr,wok;
int ok;
void getlin(double x1,double y1,double x2,double y2)
{
	if(x1==x2)
	{
		ok=0;
		return;
	}
	ok=1;
	k=(y2-y1)/(x2-x1);
	b=y1-k*x1;
}
void getlr(double k,double b,double x1,double x2)
{
	double l=x1*k+b,r=x2*k+b;
	if(l>r)
	  swap(l,r);
}
void getpoint(double k1,double b1,double k2,double b2)
{
	x=(b2-b1)/(k1-k2);
	y=k1*x+b1;
}
bool same(double a,double b)
{
	double x=a-b;
	if(x<0)
	  x=-x;
	return x<1e-5;
}
bool correct(double x1,double y1,double x2,double y2)
{
	getlin(x1,y1,x2,y2);
	if(ok)
	{
		if(!wok)
		{
			if(x1>=wx2||x2<=wx1)
			  return 1;
			double x=k*wx1+b;
			double ll=min(wy1,wy2),rr=max(wy1,wy2);
			if(x<ll||x>rr)
			  return 1;
		}
		else
		{
			getpoint(k,b,wk,wb);
			if(x<x1||x>x2||x<wx1||x>wx2)
			  return 1;
		}
	}
	else
	{
		double x=wk*x1+wb,ll=min(y1,y2),rr=max(y1,y2);
		if(x<=ll||x>=rr)
		  return 1;
	}
	return 0;
}
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	cin>>x1>>y1>>x2>>y2>>wx1>>wy1>>wx2>>wy2>>mx1>>my1>>mx2>>my2;
	if(x1>x2)
	  swap(x1,x2),swap(y1,y2);
	if(wx1>wx2)
	  swap(wx1,wx2),swap(wy1,wy2);
	getlin(wx1,wy1,wx2,wy2);
	wk=k;wb=b;wok=ok;
	if(correct(x1,y1,x2,y2))
	  cout<<"YES";
	else
	{
		getlin(mx1,my1,mx2,my2);
		double nk=-k;
		double nb1=y1-nk*x1,nb2=y2-nk*x2;
		getpoint(nk,nb1,k,b);
		double xx=x,yy=y;
		getpoint(nk,nb2,k,b);
		  x=(x+xx)*0.5,y=(y+yy)*0.5;
		double ll=min(mx1,mx2),rr=max(mx1,mx2);
		if(correct(x1,y1,x,y)&&correct(x,y,x2,y2)&&(ll<=x&&x<=rr))
		  cout<<"YES";
		else cout<<"NO";
	}
	return 0;
}
