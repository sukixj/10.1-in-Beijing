#include<iostream>
#include<queue>
#include<set>
#define mov(a,b) for(int i=1;i<=3;i++)for(int j=1;j<=3;j++)for(int k=1;k<=4;k++)a[i][j][k]=b[i][j][k];
using namespace std;
struct node
{
	int num[10];
	bool operator <(const node&a)const
	{
		for(int i=1;i<=9;i++)
		{
			if(num[i]==a.num[i])
			  continue;
			return num[i]<a.num[i];
		}
	}
};
set<node> sethash;
int move_ok,heng[4],shu[4],cl[5][5][5],i,j,k,nt[5][5][5];
int que[100000][5][5][5],tm[100000],top,tail;
queue<int>x,y,w;
char c;
node make_node(int x[5][5][5])
{
	node a;
	for(int i=1;i<=3;i++)
	  for(int j=1;j<=3;j++)
		a.num[i*3-3+j]=x[i][j][1]*64+x[i][j][2]*16+x[i][j][3]*4+x[i][j][4];
	return a;
}
bool check()
{
	int ncl[5][5][5];
	for(int i=1;i<=3;i++)
	  for(int j=1;j<=3;j++)
	    for(int k=1;k<=4;k++)
	      ncl[i][j][k]=nt[i][j][k];
	for(int cc=1;cc<=4;cc++)
	{
		for(int i=1;i<=3;i++)
	      for(int j=1;j<=3;j++)
	        for(int k=1;k<=4;k++)
	          if(ncl[i][j][k]==cc)
	          {
	         	 x.push(i);y.push(j);w.push(k);
	         	 while(!x.empty())
	         	 {
	         	 	int nx=x.front(),ny=y.front(),nw=w.front();x.pop();y.pop();w.pop();
	         	 	ncl[nx][ny][nw]=0;
	         	 	for(i=1;i<=4;i++)
	         	 	  if(ncl[nx][ny][i]==cc)
	         	 	    x.push(nx),y.push(ny),w.push(i);
	         	 	if(nw==1&&ncl[nx-1][ny][2]==cc)
	         	 	  x.push(nx-1),y.push(ny),w.push(2);
	         	 	if(nw==2&&ncl[nx+1][ny][1]==cc)
	         	 	  x.push(nx+1),y.push(ny),w.push(1);
					if(nw==3&&ncl[nx][ny-1][4]==cc)
	         	 	  x.push(nx),y.push(ny-1),w.push(4);
					if(nw==4&&ncl[nx][ny+1][3]==cc)
	         	 	  x.push(nx),y.push(ny+1),w.push(3);  
				 }
	         	 i=10;j=10;k=10;
			  }
		for(int i=1;i<=3;i++)
	     for(int j=1;j<=3;j++)
	       for(int k=1;k<=4;k++)
	         if(ncl[i][j][k]==cc)
	           return 0;
	}
	return 1;
}
void swp(int x[5],int y[5])
{
	for(i=1;i<=4;i++)
	  swap(x[i],y[i]);
}
int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	for(i=1;i<=3;i++)
	  for(j=1;j<=3;j++)
	  {
	  	for(k=1;k<=4;k++)
	  	{
	  		cin>>c;
	  		switch(c)
	  		{
	  			case'R':
	  			  cl[i][j][k]=1;break;
	  			case'G':
	  			  cl[i][j][k]=2;break;
	  			case'B':
	  			  cl[i][j][k]=3;break;
	  			case'O':
	  			  cl[i][j][k]=4;break;
			}
		}
	  	cin>>move_ok;
	  	if(move_ok)
	  	  heng[i]=shu[j]=1;
	  }
	for(i=1;i<=3;i++)
	  heng[i]^=1,shu[i]^=1;
	top++;tail=1;
	mov(que[top],cl);tm[top]=0;
	while(top>=tail)
	{
		mov(nt,que[tail]);int ntm=tm[tail];
		tail++;
		if(check())
		{
			cout<<ntm;
			return 0;
		}
		for(int i=1;i<=3;i++)
		{
			if(heng[i])
			{
				swp(nt[i][1],nt[i][3]);
				swp(nt[i][2],nt[i][3]);
				node nod=make_node(nt);
				if(sethash.find(nod)==sethash.end())
				{
					top++;mov(que[top],nt);tm[top]=ntm+1;
					sethash.insert(nod);
				}
				swp(nt[i][1],nt[i][3]);
				swp(nt[i][2],nt[i][3]);
				nod=make_node(nt);
				if(sethash.find(nod)==sethash.end())
				{
					top++;mov(que[top],nt);tm[top]=ntm+1;
					sethash.insert(nod);
				}
				swp(nt[i][1],nt[i][3]);
				swp(nt[i][2],nt[i][3]);
			}
			if(shu[i])
			{
				swp(nt[1][i],nt[3][i]);
				swp(nt[2][i],nt[3][i]);
				node nod=make_node(nt);
				if(sethash.find(nod)==sethash.end())
				{
					top++;mov(que[top],nt);tm[top]=ntm+1;
					sethash.insert(nod);
				}
				swp(nt[1][i],nt[3][i]);
				swp(nt[2][i],nt[3][i]);
				nod=make_node(nt);
				if(sethash.find(nod)==sethash.end())
				{
					top++;mov(que[top],nt);tm[top]=ntm+1;
					sethash.insert(nod);
				}
				swp(nt[1][i],nt[3][i]);
				swp(nt[2][i],nt[3][i]);
			}
		}
	}
	return 0;
}
