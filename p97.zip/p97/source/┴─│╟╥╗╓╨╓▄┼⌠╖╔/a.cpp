#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
#define Max(i,j) i>j ? i : j
#define Min(i,j) i<j ? i : j
#define LL long long
const LL INF=(LL)1<<60;
LL re,ch; char c;
using namespace std;
string s;
LL n,sum[27][1000010],num[1000010];
LL maxn,minn,ans;
LL read(LL &x)
{
	re=0,ch=1,c=getchar();
	while(c<'0'||c>'9'){if(c=='-')ch=-1;c=getchar();}
	while(c>='0'&&c<='9') re=re*10+c-'0',c=getchar();
	x=re*ch;
}
LL put(LL x)
{
	if(x>9) put(x/10);
	putchar(x%10+48);
}
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	read(n); cin>>s;
	for(int i=1;i<=n;i++) num[i]=s[i-1]-'a'+1;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=26;j++) sum[i][j]=sum[i-1][j];
		sum[i][num[i]]++;
	}
	for(int i=1;i<=n;i++)
	{
		maxn=-INF; minn=INF;
		for(int j=1;j<=26;j++)
		if(sum[i][j]) maxn=Max(maxn,sum[i][j]), minn=Min(minn,sum[i][j]);
		ans=Max(ans,maxn-minn);
	}
	put(ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
