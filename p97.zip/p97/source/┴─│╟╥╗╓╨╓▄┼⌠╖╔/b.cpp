#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
#define Max(i,j) i>j ? i : j
#define Min(i,j) i<j ? i : j
#define LL long long
const LL INF=(LL)1<<60;
LL re,ch; char c;
using namespace std;

LL read(LL &x)
{
	re=0,ch=1,c=getchar();
	while(c<'0'||c>'9'){if(c=='-')ch=-1;c=getchar();}
	while(c>='0'&&c<='9') re=re*10+c-'0',c=getchar();
	x=re*ch;
}

LL put(LL x)
{
	if(x>9) put(x/10);
	putchar(x%10+48);
}

int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	cout<<"YES";
	fclose(stdin);fclose(stdout);
	return 0;
}

