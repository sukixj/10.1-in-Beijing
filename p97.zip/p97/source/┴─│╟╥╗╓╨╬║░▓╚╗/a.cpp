#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define zero 96
using namespace std;

void in(int &x)
{
	int y=1;
	char c=getchar();x=0;
	while(c<'0'||c>'9')
	{
		if(c=='-')
		y=-1;
		c=getchar();
	}
	while(c<='9'&&c>='0')x=x*10+c-'0',c=getchar();
	x*=y;
}

void out(int x)
{
	if(x<0)
	{
		putchar('-');
		x=-x;
	}
	if(x>9)out(x/10);
	putchar(x%10+'0');
}

int n;
char c;
int ans;

struct node
{
	int ch[27];
}a[1000010];

int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
    in(n);
    int i,j,l,r,MAX,MIN;
    
    for(i=1;i<=n;i++)
    {
    	cin>>c;
    	for(j=1;j<=26;j++)
    	a[i].ch[j]=a[i-1].ch[j];
    	a[i].ch[c-zero]=a[i-1].ch[c-zero]+1;
	}
    for(r=1;r<=n;r++)
     {
     	for(l=1;l<r;l++)
        {
        	MAX=0,MIN=1000000;
          	for(i=1;i<=26;i++)
          	{
          		MAX=max(MAX,a[r].ch[i]-a[l-1].ch[i]);
          		if(a[r].ch[i]-a[l-1].ch[i]>0)
          		MIN=min(MIN,a[r].ch[i]-a[l-1].ch[i]);
			}
 			ans=max(MAX-MIN,ans);
			if(MAX-MIN>=r-l-1)
			break;
		}
	 } 
	 out(ans);
	return 0;
}

