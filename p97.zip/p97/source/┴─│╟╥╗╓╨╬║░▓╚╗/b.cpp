#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>

using namespace std;

void in(int &x)
{
	int y=1;
	char c=getchar();x=0;
	while(c<'0'||c>'9')
	{
		if(c=='-')
		y=-1;
		c=getchar();
	}
	while(c<='9'&&c>='0')x=x*10+c-'0',c=getchar();
	x*=y;
}

void out(int x)
{
	if(x<0)
	{
		putchar('-');
		x=-x;
	}
	if(x>9)out(x/10);
	putchar(x%10+'0');
}

struct node
{
	double x,y;
}a[10];

double k[10];
double b[10]; 
double X,Y;



int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
    for(int i=1;i<=6;i++)
    {
    	cin>>a[i].x>>a[i].y;
	}
	k[1]=(double)(a[1].y-a[2].y)/(a[1].x-a[2].x);
	k[2]=(double)(a[3].y-a[4].y)/(a[3].x-a[4].x);
	k[3]=(double)(a[5].y-a[6].y)/(a[5].x-a[6].x);
	b[1]=(double)(a[1].y-k[1]*a[1].x);
	b[2]=(double)(a[3].y-k[2]*a[3].x);
	b[3]=(double)(a[5].y-k[3]*a[5].x);
	
	//��ԳƵ�
	k[4]=-1/k[3];
	b[4]=a[1].y-k[4]*a[1].x;
	double xxx,yyy,xx,yy;
	xx=(b[4]-b[1])/(k[1]-k[4]);
	yy=k[1]*X+b[1];
	xxx=2*xx-a[1].x;
	yyy=2*yy-a[1].y;
	k[5]=(double)(yyy-a[2].y)/(xxx-a[2].x);
	b[5]=(double)(a[2].y-k[5]*a[2].x);
    //H��Y�Ƿ��ھ������ 
    
    X=(b[3]-b[1])/(k[1]-k[3]);
    Y=k[1]*X+b[1];
    if(X>=min(a[1].x,a[2].x)&&X<=max(a[1].x,a[2].x)&&Y>=min(a[1].y,a[2].y)&&X<=max(a[1].y,a[2].y))
    {
    	if(X>=min(a[5].x,a[6].x)&&X<=max(a[5].x,a[6].x)&&Y>=min(a[5].y,a[6].y)&&X<=max(a[5].y,a[6].y))
    {
    	cout<<"NO";
    	return 0;
	}
	}
	//��ǽ��ס
	 X=(b[2]-b[1])/(k[1]-k[2]);
    Y=k[1]*X+b[1];
    if(X>=min(a[1].x,a[2].x)&&X<=max(a[1].x,a[2].x)&&Y>=min(a[1].y,a[2].y)&&X<=max(a[1].y,a[2].y))
    {
    	if(X>=min(a[3].x,a[4].x)&&X<=max(a[3].x,a[4].x)&&Y>=min(a[3].y,a[4].y)&&X<=max(a[3].y,a[4].y))
    {
       //�����ܷ�������
	   X=(b[5]-b[3])/(k[3]-k[5]);
       Y=k[3]*X+b[3];  
       if(X>=min(a[5].x,a[6].x)&&X<=max(a[5].x,a[6].x)&&Y>=min(a[5].y,a[6].y)&&X<=max(a[5].y,a[6].y))
    {
    	if(X>=min(a[2].x,xxx)&&X<=max(a[2].x,xxx)&&Y>=min(a[2].y,yyy)&&X<=max(a[2].y,yyy))
    {
    	 X=(b[5]-b[2])/(k[2]-k[5]);
         Y=k[2]*X+b[2];
          if(X>=min(a[3].x,a[4].x)&&X<=max(a[3].x,a[4].x)&&Y>=min(a[3].y,a[4].y)&&X<=max(a[3].y,a[4].y))
    {
    	if(X>=min(a[2].x,xxx)&&X<=max(a[2].x,xxx)&&Y>=min(a[2].y,yyy)&&X<=max(a[2].y,yyy))
    {
    	cout<<"YES";
    	return 0;
    }
    else
    {
    	cout<<"NO";
    	return 0;
	}
    }
    else
    {
    	cout<<"NO";
    	return 0;
	}
    }
    }
	}
	} 
	cout<<"YES";
	return 0;
}

