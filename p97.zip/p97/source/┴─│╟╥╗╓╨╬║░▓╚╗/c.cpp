#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<ctime>
using namespace std;

void in(int &x)
{
	int y=1;
	char c=getchar();x=0;
	while(c<'0'||c>'9')
	{
		if(c=='-')
		y=-1;
		c=getchar();
	}
	while(c<='9'&&c>='0')x=x*10+c-'0',c=getchar();
	x*=y;
}

void out(int x)
{
	if(x<0)
	{
		putchar('-');
		x=-x;
	}
	if(x>9)out(x/10);
	putchar(x%10+'0');
}


int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
    srand((unsigned)time(NULL));
    int n=rand()%1000+1;
    cout<<n;
	return 0;
}

