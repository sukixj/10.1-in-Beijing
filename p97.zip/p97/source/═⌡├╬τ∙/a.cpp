#include<iostream>
#include<cstdio>
#include<cstring>
#define R register

using namespace std;

int n,a[35],ans;
char s[1000005];

int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d%s",&n,s+1);
	for(int i=1;i<=n;++i){
//		cout<<s[i]-'a'+1<<" ";
		memset(a,0,sizeof(a));
		R int maxx=0;
		for(int j=i;j<=n;++j){
			R int minn=20010923;
			a[s[j]-'a'+1]++;
//			cout<<maxx<<" "<<a[s[i]-'a'+1]<<endl;
			maxx=max(maxx,a[s[j]-'a'+1]);
			for(int k=1;k<=26;++k){
				if(!a[k]) continue;
//				cout<<k<<" ";
				minn=min(a[k],minn);
			}//cout<<endl;
//			cout<<maxx<<" "<<minn<<endl;
			ans=max(ans,maxx-minn);
		}
	}
	printf("%d\n",ans);
	return 0;
}
/*10
aabbaaabab*/
