#include<iostream>
#include<cstdio>

using namespace std;

int x[3],y[3],sx[3],sy[3],tx[3],ty[3];

int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%d%d%d%d",&x[1],&y[1],&x[2],&y[2]);
	scanf("%d%d%d%d",&sx[1],&sy[1],&tx[1],&ty[1]);
	scanf("%d%d%d%d",&sx[2],&sy[2],&tx[2],&ty[2]);
	/*k[1]=(ty[1]-sy[1])*1.0/(tx[1]-sx[1]);
	b[1]=ty[1]-k[1]*tx[1];
	k[2]=(ty[2]-sy[2])*1.0/(tx[2]-sx[2]);
	b[2]=ty[2]-k[2]*tx[2];
	k[3]=(y[1]-y[2])*1.0/(x[1]-x[2]);
	b[3]=y[1]-k*x[1];
	if(k[3]==k[1]){
		if(b[3]==b[1]){
			
		}
	}
	double xx1=(b[1]-b[3])/(k[3]-k[1]);
	double yy1=k[3]*xx1+b[3];
	double xx2=(b[2]-b[3])/(k[3]-k[2]);
	double yy2=k[3]*xx2+b[3];*/
	printf("YES\n");
	return 0;
}
