#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>

using namespace std;

char a[5][5][5];
int f[5][5],ans=5;
bool vis[5][5][5],b[35],vish[5],visl[5];

struct node
{
	int i,j,k;
};

queue <node> q;

void bfs(int i,int j,int k)
{
	q.push((node){i,j,k});
	vis[i][j][k]=1;
	while(!q.empty()){
		node now=q.front();q.pop();
		if(now.k==1||now.k==2){
			if(!vis[now.i][now.j][3]&&a[now.i][now.j][now.k]==a[now.i][now.j][3]){
				q.push((node){now.i,now.j,3});
				vis[now.i][now.j][3]=1;
			}
			if(!vis[now.i][now.j][4]&&a[now.i][now.j][now.k]==a[now.i][now.j][4]){
				q.push((node){now.i,now.j,4});
				vis[now.i][now.j][4]=1;
			}
			int ii=(now.k==1 ? now.i-1:now.i+1),kk=(now.k==1 ? 2:1);
			if(!vis[ii][now.j][kk]&&a[now.i][now.j][now.k]==a[ii][now.j][kk]){
				q.push((node){ii,now.j,kk});
				vis[ii][now.j][kk]=1;
			}
		}
		if(now.k==3||now.k==4){
			if(!vis[now.i][now.j][1]&&a[now.i][now.j][now.k]==a[now.i][now.j][1]){
				q.push((node){now.i,now.j,1});
				vis[now.i][now.j][1]=1;
			}
			if(!vis[now.i][now.j][2]&&a[now.i][now.j][now.k]==a[now.i][now.j][2]){
				q.push((node){now.i,now.j,2});
				vis[now.i][now.j][2]=1;
			}
			int jj=(now.k==3 ? now.j-1:now.j+1),kk=(now.k==3 ? 4:3);
			if(!vis[now.i][jj][kk]&&a[now.i][now.j][now.k]==a[now.i][jj][kk]){
				q.push((node){now.i,jj,kk});
				vis[now.i][jj][kk]=1;
			}
		}
	}
}

bool check()
{
	memset(vis,0,sizeof(vis));
	for(int i=0;i<=4;++i){
		for(int j=1;j<=4;++j){
			vis[0][i][j]=vis[4][i][j]=1;
			vis[i][0][j]=vis[i][4][j]=1;
		}
	}
	b[2]=b[7]=b[15]=b[18]=1;
	for(int i=1;i<=3;++i){
		for(int j=1;j<=3;++j){
			for(int k=1;k<=4;++k){
				if(!vis[i][j][k]){
					if(b[a[i][j][k]-'A']) return 0;
					b[a[i][j][k]-'A']=1;
					bfs(i,j,k);
				} 
			}
		}
	}
	return 1;
}

void wanna(int now)
{
	if(now>=ans) return;
	if(check()){
		ans=min(ans,now);
		return;
	}
	for(int i=1;i<=3;++i){
		if(vish[i]) continue;
		int tmp=f[i][3];
		f[i][3]=f[i][2];f[i][2]=f[i][1];f[i][1]=tmp;
		wanna(now+1);
		tmp=f[i][1];
		f[i][1]=f[i][2];f[i][2]=f[i][3];f[i][3]=tmp;
		tmp=f[i][1];
		f[i][1]=f[i][2];f[i][2]=f[i][3];f[i][3]=tmp;
		wanna(now+1);
		tmp=f[i][3];
		f[i][3]=f[i][2];f[i][2]=f[i][1];f[i][1]=tmp;
	}
	for(int j=1;j<=3;++j){
		if(visl[j]) continue;
		int tmp=f[1][j];
		f[1][j]=f[2][j];f[2][j]=f[3][j];f[3][j]=tmp;
		wanna(now+1);
		tmp=f[3][j];
		f[3][j]=f[2][j];f[2][j]=f[1][j];f[1][j]=tmp;
		tmp=f[3][j];
		f[3][j]=f[2][j];f[2][j]=f[1][j];f[1][j]=tmp;
		wanna(now+1);
		tmp=f[1][j];
		f[1][j]=f[2][j];f[2][j]=f[3][j];f[3][j]=tmp;
	}
	return;
}

int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	bool x;char ch;
	for(int i=1;i<=3;++i){
		for(int j=1;j<=3;++j){
			cin>>a[i][j][1]>>a[i][j][2]>>a[i][j][3]>>a[i][j][4];
			cin>>x;//a[i][j].id=i*3-3+j;
			if(x==1) vish[i]=1,visl[j]=1;
//			a[i][j].idh=i;a[i][j].idl=j;
			f[i][j]=i*3-3+j;
//			getchar();
		}
	}
	/*for(int i=1;i<=3;++i){
		for(int j=1;j<=3;++j){
			cout<<f[i][j]<<" ";
		}cout<<endl;
	}*/
//	wanna(0);
	printf("%d\n",ans);
	return 0;
}
/*GGGG0 GGGG0 GGGG0
OGOO0 GGGG0 OGOO0
OOOO0 OGGG0 OOOO0*/
