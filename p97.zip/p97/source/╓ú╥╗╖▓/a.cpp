#include<iostream>
#include<cstdio>
#include<ctime>
#define N 1000000
using namespace std;
char f[N+10];
int cnt[28][N+10],alpha[28];
int main()
{
	clock_t beg,cur;
	beg=clock();
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	int n,ans=-0x7ffffff;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		cin>>f[i];
		alpha[f[i]-'a'+1]++;
		for(int j=1;j<=26;j++) cnt[j][i]=alpha[j];
	}
	
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=i;j++)
		{
			cur=clock();
			if(double(cur-beg)/CLOCKS_PER_SEC>=0.95)
			{
				printf("%d",ans);
				return 0;
			}
			int Max=-0x7ffffff,Min=-Max;
			for(int u=1;u<=26;u++)
			{
				if(cnt[u][i]-cnt[u][j-1]>Max) Max=cnt[u][i]-cnt[u][j-1];
				if(cnt[u][i]-cnt[u][j-1]&&cnt[u][i]-cnt[u][j-1]<Min) Min=cnt[u][i]-cnt[u][j-1];
			}
			if(Max-Min>ans) ans=Max-Min;
		}
	}
	printf("%d",ans);
	return 0;
}
