#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	puts("YES");
	return 0;
}
