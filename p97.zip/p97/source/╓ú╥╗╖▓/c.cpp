#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	
}
