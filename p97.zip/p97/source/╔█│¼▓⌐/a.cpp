#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#define MAX ((int)1E6+10)
using namespace std;
int n,num[26][MAX],res,now[26];
char s[MAX];
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	for(int i=0;i<n;i++)
		do
		scanf("%c",&s[i]);
		while(s[i]=='\n'||s[i]=='\r'||s[i]==' ');
	for(int i=0;i<n;i++)
	{
		int to=s[i]-'a';
		num[to][i]++;
		if(i) for(int j=0;j<26;j++) num[j][i]+=num[j][i-1];
	}
	for(int i=0;i<n;i++)
		for(int j=0;j<i;j++)
		{
			if(j==-1) for(int k=0;k<26;k++) now[k]=num[k][i];
			else for(int k=0;k<26;k++) now[k]=num[k][i]-num[k][j];
			int max_=0,min_=(int)(1E9)+7;
		    for(int k=0;k<26;k++)
		    {
			    if(now[k]>max_) max_=now[k];
			    if(now[k]&&now[k]<min_) min_=now[k];
		    }
			res=max(res,max_-min_);	
		}
	printf("%d\n",res);
	fclose(stdin);fclose(stdout);
	return 0;	
}
