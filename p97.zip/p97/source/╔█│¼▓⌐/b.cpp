#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
using namespace std;
int xv,xp,xw1,xw2,xm1,xm2;
int yv,yp,yw1,yw2,ym1,ym2;
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%d %d",&xv,&yv);
	scanf("%d %d",&xp,&yp);
	scanf("%d %d %d %d",&xw1,&yw1,&xw2,&yw2);
	scanf("%d %d %d %d",&xm1,&ym1,&xm2,&ym2);
	double a=((double)(yv-yp))/((double)(xv-xp));
	double b=(((double)yv-(double)(a*xv))+((double)yp-(double)(a*xp)))/(double)2;
	double y1=(double)a*xw1+b,y2=(double)a*xw2+b;
	bool flag1=(y1>=yw1&&y2<=yw2)||(y1<=yw1&&y2>=yw2);
	double y3=(double)a*xm1+b,y4=(double)a*xm2+b;
	bool flag2=(y3>=ym1&&y4<=ym2)||(y3<=ym1&&y4>=ym2);
	if(y3==ym1&&y4==ym2) flag2=false;
	if(y3==ym1&&y4==ym2) flag2=false;
	if(flag2) printf("NO\n");
	else if(flag1) printf("YES\n");
	else 
	{
		double A=((double)(ym1-ym2))/((double)(xm1-xm2));
		double B=(((double)ym1-(double)(A*xm1))+((double)ym2-(double)(A*xm2)))/(double)2;
		double dv=(A*xv-yv+B)/sqrt(pow(A,2)+1);
		double dp=(A*xp-yp+B)/sqrt(pow(A,2)+1);
		double lv1=sqrt(pow(xm1-xv,2)+pow(ym1-yv,2));
		double lv2=sqrt(pow(xm2-xv,2)+pow(ym2-yv,2));
		double lp1=sqrt(pow(xm1-xp,2)+pow(ym1-yp,2));
		double lp2=sqrt(pow(xm2-xp,2)+pow(ym2-yp,2));
		double sinv1=dv/lv1,sinv2=dv/lv2,sinp1=dp/lp1,sinp2=dp/lp2;
		if(sinv1-sinp1<=1E-6||sinv2-sinp2<=1E-6||sinv1-sinp1>=-1E-6||sinv2-sinp2>=-1E-6) printf("YES\n");
		else
		{
			bool flag=(sinv1>sinp1&&sinv1<sinp1)||(sinv1<sinp1&&sinv1>sinp1);
			if(flag) printf("YES\n");
			else printf("NO\n");
		}
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
