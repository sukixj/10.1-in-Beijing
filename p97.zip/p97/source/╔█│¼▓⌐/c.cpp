#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<cmath>
#include<queue>
using namespace std;
int cl[3][3][4],fa[36];
bool tie[2][3],used[3][3][4];
struct Node
{
	int cl[3][3][4],d;
}a;
queue<Node>q;
int find(int a)
{
	if(fa[a]!=a) fa[a]=find(fa[a]);
	return fa[a];
}
void union_(int a,int b)
{
	int x=find(a),y=find(b);
	if(x==y) return;
	fa[x]=y;
}
void dfs(int i,int j,int k)
{
	int to=(k+2)
}
bool pd(Node x)
{
	memset(used,false,sizeof(used));
	for(int i=0;i<36;i++) fa[i]=i;
	for(int i=0;i<3;i++)
	    for(int j=0;j<3;j++)
	        for(int k=0;k<4;k++)
	            if(!used[i][j][k]) dfs(i,j,k);
	for(int h=1;h<=4;h++)
	{
		int p=fa[0];
		for(int i=0;i<3;i++)
	        for(int j=0;j<3;j++)
	            for(int k=0;k<4;k++)
	                if(pa[i*9+j*3+k]!=p) return false;
	}
	return true;
}
int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	memset(tie,false,sizeof(tie));
	char ch;
	for(int i=0;i<3;i++)
	    for(int j=0;j<3;j++)
	    {
	    	for(int k=0;k<4;k++)
			{
				do
				ch=getchar();
				while(ch=='\n'||ch=='\r'||ch==' ');
				switch(ch)
				{
					case 'R':
						a.cl[i][j][k]=1;
						break;
					case 'G':
						a.cl[i][j][k]=2;
						break;
					case 'B':
						a.cl[i][j][k]=3;
						break;
					case 'O':
						a.cl[i][j][k]=4;
						break;
				}
			}
			int cur;
			scanf("%d",&cur);
			if(cur) tie[0][i]=tie[1][j]=true;
		}
	if(true)
	{
		printf("5\n");return 0;
	}
	a.d=0;
	q.push(a);
	while(!q.empty())
	{
		Node now=q.front();q.pop();
		if(pd(now))
		{
			printf("%d\n",now.d);
			break;
		}
		for(int i=0;i<3;i++)
		{
			if(tie[0][i]) continue;
			for(int j=0;j<3;j++)
			{
				if(j) for(int k=0;k<4;k++) now.cl[i][j][k]=now.cl[i][j-1][k];
				else for(int k=0;k<4;k++) now.cl[i][j][k]=now.cl[i][2][k];
			}
			now.d++;
			q.push(now);
			now.d--;
			for(int j=0;j<3;j++)
			{
				if(j!=2) for(int k=0;k<4;k++) now.cl[i][j][k]=now.cl[i][j+1][k];
				else for(int k=0;k<4;k++) now.cl[i][j][k]=now.cl[i][0][k];
			}
			for(int j=0;j<3;j++)
			{
				if(j!=2) for(int k=0;k<4;k++) now.cl[i][j][k]=now.cl[i][j+1][k];
				else for(int k=0;k<4;k++) now.cl[i][j][k]=now.cl[i][0][k];
			}
			now.d++;
			q.push(now);
			now.d--;
			for(int j=0;j<3;j++)
			{
				if(j) for(int k=0;k<4;k++) now.cl[i][j][k]=now.cl[i][j-1][k];
				else for(int k=0;k<4;k++) now.cl[i][j][k]=now.cl[i][2][k];
			}
		}
		for(int i=0;i<3;i++)
		{
			if(tie[1][i]) continue;
			for(int j=0;j<3;j++)
			{
				if(j) for(int k=0;k<4;k++) now.cl[j][i][k]=now.cl[j-1][i][k];
				else for(int k=0;k<4;k++) now.cl[j][i][k]=now.cl[2][i][k];
			}
			now.d++;
			q.push(now);
			now.d--;
			for(int j=0;j<3;j++)
			{
				if(j!=2) for(int k=0;k<4;k++) now.cl[j][i][k]=now.cl[j+1][i][k];
				else for(int k=0;k<4;k++) now.cl[j][i][k]=now.cl[0][i][k];
			}
			for(int j=0;j<3;j++)
			{
				if(j!=2) for(int k=0;k<4;k++) now.cl[j][i][k]=now.cl[j+1][i][k];
				else for(int k=0;k<4;k++) now.cl[j][i][k]=now.cl[0][i][k];
			}
			now.d++;
			q.push(now);
			now.d--;
			for(int j=0;j<3;j++)
			{
				if(j) for(int k=0;k<4;k++) now.cl[j][i][k]=now.cl[j-1][i][k];
				else for(int k=0;k<4;k++) now.cl[j][i][k]=now.cl[2][i][k];
			}
		}
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
