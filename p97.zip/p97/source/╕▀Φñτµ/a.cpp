#include <cstdio>
#include <iostream>
using namespace std;
const int INF=100010;
int n,f[INF][30],ans;
int main(int argc,char *argv[])
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d\n",&n);
	for(int i=1;i<=n;++i)
	{
		char c=getchar();
		f[i][c-'a'+1]=1;
	}
	for(int i=2;i<=n;++i)
		for(int j=1;j<=26;++j)
			f[i][j]+=f[i-1][j];
	for(int i=1;i<=n;++i)
		for(int j=i;j<=n;++j)
		{
			int tmp[30],Max=-1,Min=INF;
			for(int k=1;k<=26;++k)
			{
				tmp[k]=f[j][k]-f[i-1][k];
				Max=max(Max,tmp[k]);
				if(!tmp[k])
					tmp[k]=INF;
				Min=min(Min,tmp[k]);
			}
			ans=max(ans,Max-Min);
		}
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
