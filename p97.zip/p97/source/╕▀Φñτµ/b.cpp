#include <cstdio>
#include <cstdlib>
#include <ctime>
struct point
{
	int x,y;
}v,p,w1,w2,m1,m2;
int main(int argc,char *argv[])
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%d%d",&v.x,&v.y);
	scanf("%d%d",&p.x,&p.y);
	scanf("%d%d%d%d",&w1.x,&w1.y,&w2.x,&w2.y);
	scanf("%d%d%d%d",&m1.x,&m1.y,&m2.x,&m2.y);
	srand(unsigned(time(NULL)));
	if(rand()%2)
		printf("YES");
	else
		printf("NO");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
