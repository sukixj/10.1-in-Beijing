#include <bits/stdc++.h>
#define N 1000000
#define inl inline
#define reg register
#define inf 998244353
using namespace std;
int n,c[N|1][26|1],res;
char s[N|1];
int main () {
	freopen ("a.in","r",stdin);
	freopen ("a.out","w",stdout);
	scanf ("%d%s",&n,s+1);
	for (reg int i=1;i<=n;i++) {
		for (reg int j=1;j<=26;j++)
			c[i][j]=c[i-1][j];
		c[i][s[i]-'a'+1]++;
	}
	for (reg int i=1;i<=n;i++)
		for (reg int j=i;j<=n;j++) {
			reg int mn=inf,mx=-inf;
			for (reg int k=1;k<=26;k++)
				if (c[j][k]!=c[i-1][k]) {
					mn=min(mn,c[j][k]-c[i-1][k]);
					mx=max(mx,c[j][k]-c[i-1][k]);
				}
			res=max(res,mx-mn);
		}
	printf ("%d\n",res);
	return 0;
}
