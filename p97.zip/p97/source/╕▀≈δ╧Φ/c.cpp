#include <cstdio>
int main () {
	freopen ("c.in","r",stdin);
	freopen ("c.out","w",stdout);
	printf ("10\n");
	return 0;
}
