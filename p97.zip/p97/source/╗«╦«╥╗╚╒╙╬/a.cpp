#include<cstdio>
#include<string>
#include<iostream>
using namespace std;
int n,i,j,k,mmin,mmax,p,c[100010][255]={0},ans=0;
char x;
int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	cin>>n;
	cin.ignore();
	for(i=1;i<=n;i++){
		x=getchar();
		for(j='a';j<='z';j++)c[i][j]=c[i-1][j];
		c[i][x]++;
	}
	for(i=1;i<=n;i++)
	for(j=n;j>=i;j--){
		mmin=n+1;mmax=0;
		for(k='a';k<='z';k++){
			p=c[j][k]-c[i-1][k];
			if(p>0){
				if(p>mmax)mmax=p;
				if(p<mmin)mmin=p;
			}
		}
		if(mmax-mmin>ans)ans=mmax-mmin;
	}
	cout<<ans;
	return 0;
}
