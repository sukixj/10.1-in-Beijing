#include<iostream>
using namespace std;
int x_v,y_v,x_p,y_p,x_m1,y_m1,x_m2,y_m2,x_w1,y_w1,x_w2,y_w2;
bool f;
bool zhijie(){
	int a=y_v-y_p,b=x_p-x_v,c=(x_v-x_p)*y_v-x_v*(y_v-y_p);
	if((a*x_w1+b*y_w1+c)*(a*x_w2+b*y_w2+c)<=0)return false;
	else return true;
}
bool zheshe(){
	int a=y_m1-y_m2,b=x_m2-x_m1,c=(x_m1-x_m2)*y_m1-x_m1*(y_m1-y_m2);
	int x=x_p-2*a*(a*x_p+b*y_p+c)/(a*a+b*b),y=y_p-2*b*(a*x_p+b*y_p+c)/(a*a+b*b);
	a=y_v-y;b=x-x_v;c=(x_v-x)*y_v-x_v*(y_v-y);
	if((a*x_m1+b*y_m1+c)*(a*x_m2+b*y_m2+c)<=0)return true;
	else return false;
}
int main(){
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	cin>>x_v>>y_v;
	cin>>x_p>>y_p;
	cin>>x_w1>>y_w1>>x_w2>>y_w2;
	cin>>x_m1>>y_m1>>x_m2>>y_m2;
	if(zhijie()==true)f=true;
	else if(zheshe())f=true;
	else f=false;	
	if(f==true)cout<<"YES";
	else cout<<"NO";
	return 0;
}
