#include<iostream>
#include<cstdio>
using namespace std;

double sx,sy,tx,ty;
double q1,q2,q3,q4;
double j1,j2,j3,j4;

int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%lf%lf",&sx,&sy);
	scanf("%lf%lf",&tx,&ty);
	scanf("%lf%lf%lf%lf",&q1,&q2,&q3,&q4);
	scanf("%lf%lf%lf%lf",&j1,&j2,&j3,&j4);
	cout<<"NO"<<endl;
	return 0;
}
