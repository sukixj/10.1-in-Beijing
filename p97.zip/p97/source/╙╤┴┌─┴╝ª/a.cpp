#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int a[1000001],n,c[1000001][26],ans;
string b;
int init()
{
	char c=getchar();
	int jg=0,zf=1;
	while(c<'0'&&c>'9'){if(c=='-')zf*=-1;c=getchar();}
	while(c>='0'&&c<='9'){jg=(jg<<1)+(jg<<3)+c-'0';c=getchar();}
	return zf*jg;	
}
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	cin>>n;
	cin>>b;
	for(int i=0;i<b.size();i++)
	{
		for(int j=0;j<=25;j++)
		c[i+1][j]=c[i][j];
		c[i+1][b[i]-'a']++;
	}
	for(int i=1;i<=n;i++)
	for(int j=i+ans;j<=n;j++)
	{
		int maxn=0,minn=9999999;
		for(int k=0;k<26;k++)
		{
			maxn=max(c[j][k]-c[i-1][k],maxn);
			if(c[j][k]-c[i-1][k])
			minn=min(c[j][k]-c[i-1][k],minn);
		}
		ans=max(ans,maxn-minn);
	}
	cout<<ans<<endl;
	return 0;
}
