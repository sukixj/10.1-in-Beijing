#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int init()
{
	char c=getchar();
	int jg=0,zf=1;
	while(c<'0'&&c>'9'){if(c=='-')zf*=-1;c=getchar();}
	while(c>='0'&&c<='9'){jg=(jg<<1)+(jg<<3)+c-'0';c=getchar();}
	return zf*jg;
}
double hx,hy;
double xv,yv,xp,yp,xw1,yw1,xw2,yw2,xm1,ym1,xm2,ym2;
int jj(double x1,double y1,double x2,double y2,double x3,double y3,double x4,double y4)//0:���ཻ��1����һ�����㡣2�������֣��غ� 
{
	if(x1==x2&&x3==x4)
	{
		if(x1!=x3)
		return 0;
		if(min(y1,y2)>=max(y3,y4)||max(y1,y2)<=min(y3,y4))
		return 0;
		return 2;
	}
	if(x1==x2)
	{
		double dd=(y3-y4)/(x3-x4)*x1+(y4*x3-y3*x4)/(x3-x4);
		hx=x1;
		hy=dd;
		if(dd>=min(y1,y2)&&dd<=max(y1,y2))
		return 1;
		return 0;
	}
	if(x3==x4)
	{
		double dd=(y1-y2)/(x1-x2)*x3+(y2*x1-y2*x2)/(x1-x2);
		hx=x3;
		hy=dd;
		if(dd>=min(y3,y4)&&dd<=max(y3,y4))
		return 1;
		return 0;
	}
	if(((y1-y2)*x3+(y2*x1-y1*x2)==(x1-x2)*y3)&&((y1-y2)*x4+(y2*x1-y1*x2)==(x1-x2)*y4))
	{
		if(min(y1,y2)>=max(y3,y4)||max(y1,y2)<=min(y3,y4))
		return 0;
		return 2;
	}
	double qq=((y3*x4-y4*x3)/(x4-x3)-(y2*x1-y1*x2)/(x1-x2))/((y1-y2)/(x1-x2)-(y4-y3)/(x4-x3));
	hx=qq;
	hy=(y1-y2)/(x1-x2)*hx+(y2*x1-y1*x2)/(x1-x2);
	if(qq>=min(x1,x2)&&qq<=max(x1,x2)&&qq>=min(x3,x4)&&qq<=max(x3,x4))
	return 1;
	else
	return 0;
}

int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	cin>>xv>>yv>>xp>>yp>>xw1>>yw1>>xw2>>yw2>>xm1>>ym1>>xm2>>ym2;
	//////��ֱ�ӿ���
	if((jj(xv,yv,xp,yp,xw1,yw1,xw2,yw2)==0)&&(jj(xv,yv,xp,yp,xm1,ym1,xm2,ym2)!=1))
	{
		cout<<"YES"<<endl;
		return 0;
	}
	if(jj(xv,yv,xp,yp,xm1,ym1,xm2,ym2)!=0)
	{
		cout<<"NO"<<endl;
		return 0;
	}
	double nx0=((xm1-xm2)/(ym1-ym2)*xv+yv-(ym2*xm1-ym1*xm2)/(xm1-xm2))/((ym1-ym2)/(xm1-xm2)+(xm1-xm2)/(ym1-ym2));
	double ny0=(ym1-ym2)/(xm1-xm2)*nx0+(ym2*xm1-ym1*xm2)/(xm1-xm2);
	double ddx=2*nx0-xv,ddy=2*ny0-yv;
	jj(ddx,ddy,xp,yp,xm1,ym1,xm2,ym2);
	double hhx=hx,hhy=hy;
	if(hhx<=max(xm1,xm2)&&hhx>=min(xm1,xm2)&&hhy<=max(ym1,ym2)&&hhy>=min(ym1,ym2))
	1==1;
	else
	{
		cout<<"NO"<<endl;
		return 0;
	}
	if((jj(hhx,hhy,xv,yv,xw1,yw1,xw2,yw2)==0)&&(jj(hhx,hhy,xp,yp,xw1,yw1,xw2,yw2)==0))
	{
		cout<<"YES"<<endl;
		return 0;
	}
	else
	{
		cout<<"NO"<<endl;
		return 0;
	}
	return 0;
}
