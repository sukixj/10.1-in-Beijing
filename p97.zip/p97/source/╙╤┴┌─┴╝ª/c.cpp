#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
int init()
{
	char c=getchar();
	int jg=0,zf=1;
	while(c<'0'&&c>'9'){if(c=='-')zf*=-1;c=getchar();}
	while(c>='0'&&c<='9'){jg=(jg<<1)+(jg<<3)+c-'0';c=getchar();}
	return zf*jg;
}
int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	cout<<5<<endl;
	return 0;
}

