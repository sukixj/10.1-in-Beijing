#include<iostream>
using namespace std;
int x[1000005],n,ans=0,here;
char a[1000005];
int quan(int l,int r)
{
    int big=0,small=1050000,now=0;
    for(int i=l;i<=r;i++)x[i]=0;
    for(int i=l;i<=r;i++)
    {
            if(x[i]==0)
            {
                for(int j=i;j<=r;j++)
            {
                    if(a[j]==a[i]&&x[j]==0)
                    {
                            now++;
                            x[j]=1;
                    }      
            }
            if(now>big)big=now;
            if(now<small)small=now;
            now=0;       
            }
            
    }
    return big-small;
}
int main()
{
    freopen("a.in","r",stdin);
    freopen("a.out","w",stdout);
    cin>>n>>a;
    for(int i=0;i<=n-1;i++)
    {
            for(int j=i;j<=n-1;j++)
            {
                    here=quan(i,j);
                    if(here>ans)ans=here;
            }
    }
    cout<<ans;
    return 0;
}
