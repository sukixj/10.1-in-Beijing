#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<vector>
#include<queue>
#include<stack>
#include<string>
#include<cstdlib>
#include<ctime>
#include<iostream>
using namespace std;
int f[1020][1020][30];
char str[1020];
inline int ri()
{
	register int x=0;
	bool f=0;
	register char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')	f=1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	if(f)	return -x;
	else	return x;
}
void wi(int x)
{
	if(x<0)	putchar('-'),x=-x;
	if(x>9)	wi(x/10);
	putchar(x%10+'0');
}
inline int mmax(int x,int y)
{
	if(x>y)	return x;
	else	return y;
}
inline int mmin(int x,int y)
{
	if(x<y)	return x;
	else	return y;
}
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	register int len=ri(),i,j,l,k,nmin,nmax,ans=0;
	gets(str+1);
	for(i=1;i<=len;i++)
	{
		f[i][i][str[i]-'a']=1;
	}
	for(l=2;l<=len;l++)
	{
		for(i=1;i+l-1<=len;i++)
		{
			j=i+l-1;
			memcpy(f[i][j],f[i][j-1],sizeof(f[i][j]));
			f[i][j][str[j]-'a']++;
			nmin=1e9;
			nmax=0;
			for(k=0;k<26;k++)
			{
				if(f[i][j][k])
				{
					nmax=mmax(nmax,f[i][j][k]);
					nmin=mmin(nmin,f[i][j][k]);
				}
			}
			ans=mmax(ans,nmax-nmin);
		}
	}
	wi(ans);
	return 0;
}
/*
10
babbacadae











*/
