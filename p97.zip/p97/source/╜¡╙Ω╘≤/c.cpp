#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<vector>
#include<queue>
#include<stack>
#include<string>
#include<cstdlib>
#include<ctime>
#include<iostream>
using namespace std;
const long double eps=1e-12;
inline int ri()
{
	register int x=0;
	bool f=0;
	register char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')	f=1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	if(f)	return -x;
	else	return x;
}
void wi(int x)
{
	if(x<0)	putchar('-'),x=-x;
	if(x>9)	wi(x/10);
	putchar(x%10+'0');
}
struct line
{
	bool kcunzai;
	long double x1,x2,y1,y2,k,b;
}w,m,tl,longm;
struct point
{
	long double x,y;
	bool cunzai;
}u,v,tp;
line la,lb,lc;
bool feql(long double a,long double b)
{
	if(a-b<=eps||b-a<=eps)	return 1;
	else	return 0;
}
void lineinit(line a)
{
	if(feql(a.x1,a.x2))
	{
		a.kcunzai=0;
	}
	else
	{
		a.kcunzai=1;
		a.k=(a.y1-a.y2)/(a.x1-a.x2);
		a.b=a.y1-a.k*a.x1;
	}
}
point qiujiaodian(line a,line b)
{
	point ret;
	if(a.kcunzai==0)
	{
		ret.x=a.x1;
		ret.y=b.k*a.x1+b.b;
		if((ret.y>=a.y1&&ret.y<=a.y2||ret.y>=a.y2&&ret.y<=a.y1)&&(ret.x>=b.x1&&ret.x<=b.x2||ret.x>=b.x2&&ret.x<=b.x1))	ret.cunzai=1;
		else	ret.cunzai=0;
	}
	else	if(b.kcunzai==0)
	{
		ret.x=b.x1;
		ret.y=a.k*b.x1+a.b;
		if((ret.x>=a.x1&&ret.x<=a.x2||ret.x>=a.x2&&ret.x<=a.x1)&&(ret.y>=b.y1&&ret.y<=b.y2||ret.y>=b.y2&&ret.y<=b.y1))	ret.cunzai=1;
		else	ret.cunzai=0;
	}
	else
	{
		ret.x=(b.b-a.b)/(a.k-b.k);
		ret.y=(a.k*b.b-b.k*a.b)/(a.k-b.k);
		if((ret.x>=a.x1&&ret.x<=a.x2||ret.x>=a.x2&&ret.x<=a.x1)&&(ret.x>=b.x1&&ret.x<=b.x2||ret.x>=b.x2&&ret.x<=b.x1))	ret.cunzai=1;
		else	ret.cunzai=0;
	}	
	return ret;
}
point qiuduichendian(line a,point c)
{
	point ret;
	ret.cunzai=1;
	if(a.kcunzai==0)
	{
		ret.y=c.y;
		ret.x=2*a.x1-c.x;
		return ret;
	}
	ret.y=((a.k*a.k-1)*c.y+2*a.k*c.x+2*a.b)/(a.k*a.k+1);
	ret.x=a.k*c.y-a.k*ret.y+c.x;
	return ret;
}
bool pingxing(line a,line b)
{
	if(a.kcunzai==0&&b.kcunzai==0)	return 1;
	if(a.kcunzai==1&&b.kcunzai==1&&feql(a.k,b.k))	return 1;
	return 0;
}
void gg(int x)
{
	if(x==1)
	{
		printf("YES");
	}
	else
	{
		printf("NO");
	}
	exit(0);
}
int main()
{
	//read
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	cout<<5;
	return 0;
}
/*
0 0
1 1
0 1 1 0
-1 1 1 3







*/
