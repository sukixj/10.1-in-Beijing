#include<iostream>  
#include<cstdio>  
#include<cstring>  
#include<algorithm>  
using namespace std;  
char s[1000001];  
int a[1000001];  
int rr[27][27],ll[27][27],C[27][27],sec[27][27],tot[27];  
int main()  
{  
    freopen("a.in","r",stdin);
    freopen("a.out","w",stdout);
	int n,ans=0;  
    scanf("%d%s",&n,s+1);   
    memset(sec,0x3f,sizeof(sec));  
    for(int i=1;i<=n;i++)  
    {  
        a[i]=s[i]-96;  
        tot[a[i]]++;  
        for(int j=1;j<=26;j++)  
        if(a[i]!=j)  
        {  
            rr[a[i]][j]++;  
            int x=a[i],y=j;
            if(C[x][y]!=tot[y]) ans=max(ans,rr[x][y]-ll[x][y]);  
    		else ans=max(ans,rr[x][y]-sec[x][y]);  
    		if(rr[x][y]<ll[x][y])  
    		{  
        		if(C[x][y]==tot[y]) ll[x][y]=rr[x][y];  
        		else  
        		{  
            		sec[x][y]=ll[x][y];  
            		ll[x][y]=rr[x][y];  
            		C[x][y]=tot[y];  
        		}  
    		}  
    		else if(rr[x][y]<sec[x][y])  
    		{
    		    if(tot[y]!=C[x][y]) sec[x][y]=ll[x][y]; 
			}
            rr[j][a[i]]--;  
            x=j,y=a[i];
            if(C[x][y]!=tot[y]) ans=max(ans,rr[x][y]-ll[x][y]);  
    		else ans=max(ans,rr[x][y]-sec[x][y]);  
    		if(rr[x][y]<ll[x][y])  
    		{  
        		if(C[x][y]==tot[y]) ll[x][y]=rr[x][y];  
        		else  
        		{  
            		sec[x][y]=ll[x][y];  
            		ll[x][y]=rr[x][y];  
            		C[x][y]=tot[y];  
        		}  
    		}  
    		else if(rr[x][y]<sec[x][y])  
    		{
    		    if(tot[y]!=C[x][y]) sec[x][y]=ll[x][y];
			}
        }  
    }  
    printf("%d",ans);
    return 0;
}  
