#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int dx[]={1,0,-1,0};
int dy[]={0,1,0,-1};
struct node
{ 
    int mp[5];
}re[3][3];
int movx[4],movy[4];
int col(char c)
{
    if(c=='R') return 0;
    if(c=='G') return 1;
    if(c=='B') return 2;
    if(c=='O') return 3;
    return -1;
}
int fac[]={1,1,2,6,24,120,720,5040,40320,362880,3628800};
int cantor(int *s,int n)
{
    int i,j,num=0,tmp;
    for(i=0;i<n;i++)
    {
        tmp=0;
        for(j=i+1;j<n;j++)
            if(s[j]<s[i]) tmp++;
        num+=fac[n-1-i]*tmp;
    }
	return num;
}
node que[370000][3][3];
int can[10];
void mcan(node t[3][3])
{
    for(int i=0;i<3;i++)
    for(int j=0;j<3;j++)
    can[i*3+j] = t[i][j].mp[4];
}
int dis[370000];
const int INF=0x3f3f3f3f;
bool v[4][4][4];
int color[5];
bool tj(int x,int y)
{
    if(x<0||x>=3) return false;
    if(y<0||y>=3) return false;
    return true;
}
void dfs(node t[3][3],int x,int y,int z,int c)
{
    if(v[x][y][z]) return;
    v[x][y][z]=1;
    if(t[x][y].mp[(z+1)%4]==c) dfs(t,x,y,(z+1)%4,c);
    if(t[x][y].mp[(z+3)%4]==c) dfs(t,x,y,(z+3)%4,c);
    int tx=x+dx[z],ty=y+dy[z];
    if(!tj(tx,ty)) return;
    if(t[tx][ty].mp[(z+2)%4]==c) dfs(t,tx,ty,(z+2)%4,c);
}
bool ok(node t[3][3])
{
    memset(v,0,sizeof(v));
    memset(color,0,sizeof(color));
    for(int i=0;i<3;i++)
    for(int j=0;j<3;j++)
    for(int k=0;k<4;k++)
    {
        if(!v[i][j][k])
        {
            if(color[t[i][j].mp[k]]) return false;
            color[t[i][j].mp[k]]=1;
            dfs(t,i,j,k,t[i][j].mp[k]);
        }
    }
	return true;
}
void solve()
{
    memset(dis,INF,sizeof(dis));
    int rear=0,front=0;
    memcpy(que[rear++],re,sizeof(re));
    dis[0]=0;
    node e[3][3],t[3][3];
    while(rear>front)
    {
        memcpy(e,que[front++],sizeof(e));
        mcan(e);
        int ee=cantor(can,9);
        int dd=dis[ee];
        if(ok(e))
        {
            printf("%d",dis[ee]);
            break;
        }
        node tmp;
        for(int i=0;i<3;i++)
        {
        	if(movx[i]==0)
        	{
            	memcpy(t,e,sizeof(e));
            	tmp=t[i][0];
            	t[i][0]=t[i][1];
				t[i][1]=t[i][2];
				t[i][2]=tmp;
            	mcan(t);
            	int tc=cantor(can,9);
            	if(dis[tc]>dd+1)
            	{
                	dis[tc]=dd+1;
                	memcpy(que[rear++],t,sizeof(t));
            	}
            	memcpy(t,e,sizeof(e));
            	tmp=t[i][2];
            	t[i][2]=t[i][1];
				t[i][1]=t[i][0];
				t[i][0]=tmp;
            	mcan(t);
            	tc=cantor(can,9);
            	if(dis[tc]>dd+1)
            	{
                	dis[tc]=dd+1;
                	memcpy(que[rear++],t,sizeof(t));
           	 	}
           	}
        }
        for(int i=0;i<3;i++)
        {
        	if(movy[i]==0)
        	{
            	memcpy(t,e,sizeof(e));
            	tmp=t[0][i];
            	t[0][i]=t[1][i];
				t[1][i]=t[2][i];
				t[2][i]=tmp;
            	mcan(t);
            	int tc=cantor(can,9);
            	if(dis[tc]>dd+1)
            	{
                	dis[tc]=dd+1;
                	memcpy(que[rear++],t,sizeof(t));
            	}
            	memcpy(t,e,sizeof(e));
            	tmp=t[2][i];
            	t[2][i]=t[1][i];
				t[1][i]=t[0][i];
				t[0][i]=tmp;
            	mcan(t);
            	tc=cantor(can,9);
            	if(dis[tc]>dd+1)
            	{
                	dis[tc]=dd+1;
                	memcpy(que[rear++],t,sizeof(t));
            	}
        	}
    	}
    }
}
int main()
{
    freopen("c.in","r",stdin);
    freopen("c.out","w",stdout);
    char ch[10];
    int cnt=0;
    memset(movx,0,sizeof(movx));
    memset(movy,0,sizeof(movy));
    for(int i=0;i<3;i++)
    {
    	for(int j=0;j<3;j++)
    	{
        	scanf("%s",ch);
        	re[i][j].mp[0]=col(ch[1]);
        	re[i][j].mp[1]=col(ch[3]);
        	re[i][j].mp[2]=col(ch[0]);
        	re[i][j].mp[3]=col(ch[2]);
        	re[i][j].mp[4]=cnt++;
        	int tmp =ch[4]-'0';
        	if(tmp==1)
        	{
            	movx[i]=1;
            	movy[j]=1;
        	}
        }
    }
    solve();
    return 0;
}

