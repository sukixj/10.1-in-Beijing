#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <string>
using namespace std;
int n,ans,c[30],tmp;
int main(){
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	int head=1,tail=1,ba=0,sa=1000010,bd='0',sd='0';
	string str;
	cin>>n;
	cin>>str;
	for(int i=1;i<n;i++){
		c[str[head]-'a']++;
		if(c[str[head]-'a']>ba&&bd!=str[head]-'a'){
			bd=str[head]-'a';
			ba=c[str[head]-'a'];
		}
		if(c[str[head]-'a']<sa&&sd!=str[head]-'a'){
			sd=str[head]-'a';
			sa=c[str[head]-'a'];
		}
		head++;
		tmp=ba-sa;
		if(tmp>ans)
			ans=tmp;
	}
	while(c[str[tail]-'a']==sd&&sa>1){
			tail++;
			ans--;
			sa--;
	}
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
