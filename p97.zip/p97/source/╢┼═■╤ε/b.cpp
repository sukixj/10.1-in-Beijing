#include <iostream>
using namespace std;
int main(){
	freopen("b.out","w",stdout);
	cout<<"NO"<<endl;
	return 0;
}
