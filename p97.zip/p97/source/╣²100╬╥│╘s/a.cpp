#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int N=1000005;
int n,minn,dp[N],maxn,num[30],ans,f;
char s[N];
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",s+1);
	for(int i=2;i<=n;i++) if(s[i]!=s[i-1]) f=1;
	if(f==0)
	{
		printf("0");
		return 0;
	}
	for(int i=1;i<n;i++)
	{
		f=0;
		memset(num,0,sizeof(num));
		for(int j=i;j<=n;j++)
		{
			maxn=0,minn=N;
			if(j>1&&s[j]!=s[j-1]) f=1;
			num[s[j]-'a'+1]++;
			if(!f) minn=0;
			if(f)
			{
				for(int k=1;k<=26;k++)
				{
					if(num[k])
					{
						maxn=max(maxn,num[k]);
						minn=min(minn,num[k]);
					}
				}
				ans=max(ans,maxn-minn);
			}
		}
	}
	printf("%d",ans);
	return 0;
}
