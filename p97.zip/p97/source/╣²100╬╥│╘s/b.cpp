#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
using namespace std;
int x,y,x1,x2,y11,y2,xa,xb,ya,yb;
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	scanf("%d%d%d%d%d%d%d%d%d%d%d%d",&x,&y,&x1,&y11,&x2,&y2,&xa,&ya,&xb,&yb);
	printf("NO\n");
	return 0;
}
