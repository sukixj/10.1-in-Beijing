#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<ctime>
using namespace std;
char s[5];
int n,ans=0x3f3f3f3f;
struct Type{
	bool if_;
	int s,x,z,y;
	
}pos[4][4],pos0[4][4];

int dx[5]={0,1,-1,0,0};
int dy[5]={0,0,0,1,-1};

void work1(int x)
{
	Type p=pos[1][x];
	for(int i=1;i<3;i++)
		pos[i][x]=pos[i+1][x];
	pos[3][x]=p;
}

void work2(int x)
{
	Type p=pos[3][x];
	for(int i=2;i<=3;i++)
		pos[i][x]=pos[i-1][x];
	pos[1][x]=p;
}

void work3(int x)
{
	Type p=pos[x][1];
	for(int i=1;i<3;i++)
		pos[x][i]=pos[x][i+1];
	pos[x][3]=p;
}

void work4(int x)
{
	Type p=pos[x][3];
	for(int i=2;i<=3;i++)
		pos[i][x]=pos[i-1][x];
	pos[1][x]=p;
}

bool judge(int x,int y)
{
	if(pos[x][y].if_!=pos0[x][y].if_) return false;
	if(pos[x][y].s!=pos0[x][y].s) return false;
	if(pos[x][y].x!=pos0[x][y].x) return false;
	if(pos[x][y].z!=pos0[x][y].z) return false;
	if(pos[x][y].y!=pos0[x][y].y) return false;
	return true;
}

void dfs(int num,int x,int y,int now)
{
	if(now>1e3) return ;
	if(num==1) work1(y);
	if(num==2) work2(y);
	if(num==3) work3(x);
	if(num==4) work4(x);
	int f_=0;
	for(int i=1;i<=3;i++)
		for(int j=1;j<=3;j++)
		{
			if(!judge(i,j))
			f_=1;
		}
	if(f_==0) return ;
	int f=0;
	for(int i=1;i<=3;i++)
		for(int j=1;j<=3;j++)
		{
			if(i!=1&&pos[i][j].s!=pos[i-1][j].x) f=1;
			if(j!=1&&pos[i][j].z!=pos[i][j-1].y) f=1;
		}
	if(f==0)
	{
		ans=min(ans,now);
		return ;
	}
	for(int i=1;i<=3;i++)
		for(int j=1;j<=3;j++)
			for(int k=1;k<=4;k++)
				dfs(k,i,j,now+1);
}

int main()
{
	freopen("c.in","r",stdin);
	freopen("c.out","w",stdout);
	srand(time(0));
	for(int i=1;i<=3;i++)
		for(int j=1;j<=3;j++)
		{
			cin>>s;
			pos[i][j].if_=s[4]-'0';
			for(int k=0;k<=3;k++)
			{
				if(k==0)
				{
					if(s[k]=='R')
					pos[i][j].s=1;
					else if(s[k]=='G')
					pos[i][j].s=2;
					else if(s[k]=='B')
					pos[i][j].s=3;
					else if(s[k]=='O')
					pos[i][j].s=4;
				}
				if(k==1)
				{
					if(s[k]=='R')
					pos[i][j].x=1;
					else if(s[k]=='G')
					pos[i][j].x=2;
					else if(s[k]=='B')
					pos[i][j].x=3;
					else if(s[k]=='O')
					pos[i][j].x=4;
				}
				if(k==2)
				{
					if(s[k]=='R')
					pos[i][j].z=1;
					else if(s[k]=='G')
					pos[i][j].z=2;
					else if(s[k]=='B')
					pos[i][j].z=3;
					else if(s[k]=='O')
					pos[i][j].z=4;
				}
				if(k==3)
				{
					if(s[k]=='R')
					pos[i][j].y=1;
					else if(s[k]=='G')
					pos[i][j].y=2;
					else if(s[k]=='B')
					pos[i][j].y=3;
					else if(s[k]=='O')
					pos[i][j].y=4;
				}
			}
			pos0[i][j]=pos[i][j];
		}
//	for(int i=1;i<=4;i++)	dfs(i,1,1,1);
	/*for(int i=1;i<=3;i++)
	{
		for(int j=1;j<=3;j++)
			printf("%d%d%d%d%d ",pos[i][j].s,pos[i][j].x,pos[i][j].z,pos[i][j].y,pos[i][j].if_);
		printf("\n");
	}*/	
	printf("%d",rand()%23*(rand()%3));
	return 0;
}
