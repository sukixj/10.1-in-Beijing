#include<cstdio>
#include<cstring>
using namespace std;
int n;
int ans = 0;
char s[1001000];
int zz[31] = {0,1,500000,300000,5,200000,666666,100,1000,10000,100000};
int note[123];
int max(int a,int b)
{
	return a > b ? a : b;
}
int min(int a,int b)
{
	return a < b ? a : b;
}
int judge()
{
	int minn = 9999999,maxx = -1;
	for(int i = 'a';i <= 'z';i++)
	{
		if(!note[i])continue;
		minn = min(minn,note[i]);
		maxx = max(maxx,note[i]);
	}
	return maxx - minn;
}
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",s + 1);
	if(n <= 1000)
	{
		for(int i = 1;i <= n;i++)
		{
			memset(note,0,sizeof(note));
			for(int j = i;j <= n;j++)
			{
				note[s[j]]++;
				ans = max(ans,judge());
			}
		}
		printf("%d",ans);
		return 0;
	}
	zz[11] = n / 2;
	zz[14] = n / 3;
	zz[13] = n / 4;
	zz[12] = n / 2 + n / 3;
	zz[15] = n / 2 + n / 4;
	for(int i = 1;i <= 12;i++)
	{
		memset(note,0,sizeof(note));
		for(int j = zz[i];j <= n;j++)
		{
			note[s[j]]++;
			ans = max(ans,judge());
		}
	}
	printf("%d",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}

/*
10
aabbaaabab

20
abbbbbaaaaabbbbbbbbb

10
bbbbbbbbbb
*/
