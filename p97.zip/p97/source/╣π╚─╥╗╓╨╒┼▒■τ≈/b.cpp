#include<cstdio>
#include<cmath>
using namespace std;

struct point{
	double x;
	double y;
}H,Y;

struct Edge
{
	point a;
	point b;
}wall_,mirror_;

double max(double a,double b)
{
	return a > b ? a : b;
}

double min(double a,double b)
{
	return a < b ? a : b;
}

bool judge(Edge op)
{
	int ax = max(H.x,Y.x);
	int bx = min(op.a.x,op.b.x);
	if(bx > ax)return false;
	ax = max(op.a.x,op.b.x);
	bx = min(H.x,Y.x);
	if(bx > ax)return false;
	
	int ay = max(H.y,Y.y);
	int by = min(op.a.y,op.b.y);
	if(by > ay)return false;
	ay = max(op.a.y,op.b.y);
	by = min(H.y,Y.y);
	if(by > ay)return false;
	return true;
}

int main()
{
	freopen("b.in","r",stdin);freopen("b.out","w",stdout);
	scanf("%lf%lf",&H.x,&H.y);
	scanf("%lf%lf",&Y.x,&Y.y);
	scanf("%lf%lf%lf%lf",&wall_.a.x,&wall_.a.y,&wall_.b.x,&wall_.b.y);
	scanf("%lf%lf%lf%lf",&mirror_.a.x,&mirror_.a.y,&mirror_.b.x,&mirror_.b.y);
	
	if(!judge(wall_) &&!judge(mirror_))
	{
		printf("YES");
		return 0;
	}
	if(!judge(mirror_))
	{
		printf("NO");
		return 0;
	}
	printf("YES");
	fclose(stdin);fclose(stdout);
	return 0;
}
/*
-1 3
1 3
0 2 2 4
0 0 0 1
NO

0 0
1 1
0 1 1 0
-1 1 1 3
YES

0 0
1 1
0 1 1 0
-100 -100 -101 -101
NO

0 0
10 0
100 100 101 101
1 0 3 0
YES




*/
