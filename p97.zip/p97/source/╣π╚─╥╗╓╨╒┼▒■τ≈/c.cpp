#include<cstdio>
#include<algorithm>
#include<cstring>
#include<queue>
using namespace std;
char s[12];
const int mod = 123456;
const int rmod = 654321;
bool visited[130000];
bool rvisited[666666];

bool xcan[3];
bool ycan[3];

bool dfsvisited[5];
bool kuai[5];

struct Note{
	int op[9][9];
	int shu[3][3];
	int step;
	Note(){
		memset(op,0,sizeof(op));
		memset(shu,0,sizeof(shu));
	}
}be;
const int mp[9][9] =
{
0,1,0,0,1,0,0,1,0,
1,0,1,1,0,1,1,0,1,
0,1,0,0,1,0,0,1,0,
0,1,0,0,1,0,0,1,0,
1,0,1,1,0,1,1,0,1,
0,1,0,0,1,0,0,1,0,
0,1,0,0,1,0,0,1,0,
1,0,1,1,0,1,1,0,1,
0,1,0,0,1,0,0,1,0,				
}; 
int initx[4] = {-1,1,0,0};
int inity[4] = {0,0,-1,1};
bool vis[9][9];
int de[5];
int qiushu(Note ax)
{
	int ans = 100000000 * ax.shu[0][0] + 10000000 * ax.shu[0][1] +1000000 *ax.shu[0][2]
			 +100000 *ax.shu[1][0] +10000 *ax.shu[1][1]  +1000 *ax.shu[1][2]
			 +100 *ax.shu[2][0] + 10 * ax.shu[2][1]+ ax.shu[2][2];
}

void dfs(int x,int y,int wei,Note pig)
{
	vis[x][y] = true;
	de[pig.op[x][y]]++;
	for(int i = -1;i <= 1;i++)
		for(int j = -1;j <= 1;j++)
		{
			if(i == 0 && j == 0)continue;
			int nx = x + i;
			int ny = y + j;
			if(nx > 0 && nx < 9 && ny > 0 && ny < 9 && pig.op[nx][ny] == wei && !vis[nx][ny])
				dfs(nx,ny,wei,pig);
		}
}

bool judge(Note pig)
{
	memset(vis,0,sizeof(vis));
	memset(de,0,sizeof(de));
	for(int i = 0;i <= 8;i++)
		for(int j = 0;j <= 8;j++)
		{
			if(pig.op[i][j] && ! vis[i][j])
			{
				dfs(i,j,pig.op[i][j],pig);
				if(de[pig.op[i][j]] != kuai[pig.op[i][j]])
					return false;
			}
		}
	return true;
}

void debug(Note p)
{
	for(int i = 0;i <= 8;i++)
	{
		printf("\n");
		for(int j = 0;j <= 8;j++)
		{
			printf("%d ",p.op[i][j]);
		}
	}
}

int main()
{
	freopen("c.in","r",stdin);freopen("c.out","w",stdout);
	for(int i = 0;i < 3;i++)
		for(int j = 0;j < 3;j++)
		{
			scanf("%s",s);// R 1   --   G 2   --  B 3 --  O 4 --
			for(int z = 0;z <= 3;z++)
			{
				if(s[z] == 'R')s[z] = '1';
				if(s[z] == 'G')s[z] = '2';
				if(s[z] == 'B')s[z] = '3';
				if(s[z] == 'O')s[z] = '4';
				kuai[s[z] - '0']++;
			}
			int xnow = i * 3 + 1;
			int ynow = j * 3 + 1;
			for(int tp = 0;tp < 4;tp++)
			{
				be.op[xnow + initx[tp]][ynow + inity[tp]] = s[tp] - '0';
			}
			if(s[4] == '1'){
				xcan[i] = true;
				ycan[j] = true;
			}
		}
	for(int jkl = 0;jkl < 3;jkl++)
		for(int lll = 0;lll < 3;lll++)
	{
			be.shu[jkl][lll] = jkl * 3 + lll; 
	}
	//debug(be);
	int be_num = qiushu(be);
	srand(be_num);
	visited[be_num % mod] = true;
	rvisited[be_num % rmod] = true;
	queue<Note>q;
	q.push(be);
	while(!q.empty())
	{
		Note zz = q.front();
		q.pop();
		if(judge(zz))
		{
			printf("%d",zz.step);
			return 0;
		}	
		for(int i = 0;i < 3;i++)
		{
			Note nx;
			nx = zz;
			nx.step = zz.step + 1;
			if(xcan[i])
			{
				int xx= i * 3 + 1;
			
				for(int j = 0;j <= 8;j++)
				{
					nx.op[xx - 1][(j + 3) % 9] = zz.op[xx - 1][j];
					nx.op[xx][(j + 3) % 9] = zz.op[xx][j];
					nx.op[xx + 1][(j + 3) % 9] = zz.op[xx + 1][j];
					nx.shu[xx][(j + 1) % 3] = zz.shu[xx][j]; 
				}
				int as = qiushu(nx);
				if(!visited[as % mod] && ! rvisited[as % rmod])
				{
					visited[as % mod] = true;
					rvisited[as % rmod] = true;
					q.push(nx);
				}
				
				nx = zz;
				nx.step = zz.step + 1;
				
				for(int j = 0;j <= 8;j++)
				{
					nx.op[xx - 1][(j + 6) % 9] = zz.op[xx - 1][j];
					nx.op[xx][(j + 6) % 9] = zz.op[xx][j];
					nx.op[xx + 1][(j + 6) % 9] = zz.op[xx + 1][j];
					nx.shu[xx][(j + 2) % 3] = zz.shu[xx][j]; 
				}
				as = qiushu(nx);
				if(!visited[as % mod] && ! rvisited[as % rmod])
				{
					visited[as % mod] = true;
					rvisited[as % rmod] = true;
					q.push(nx);
				}
				
			}
			if(ycan[i])
			{
				int xx= i * 3 + 1;
				nx = zz;
				nx.step = zz.step + 1;
				for(int j = 0;j <= 8;j++)
				{
					nx.op[(j + 3) % 9][xx - 1] = zz.op[j][xx - 1];
					nx.op[(j + 3) % 9][xx] = zz.op[j][xx];
					nx.op[(j + 3) % 9][xx + 1] = zz.op[j][xx + 1];
					nx.shu[(j + 1) % 3][xx] = zz.shu[j][xx]; 
				}
				int as = qiushu(nx);
				if(!visited[as % mod] && ! rvisited[as % rmod])
				{
					visited[as % mod] = true;
					rvisited[as % rmod] = true;
					q.push(nx);
				}
				
				nx = zz;
				nx.step = zz.step + 1;
				
				for(int j = 0;j <= 8;j++)
				{
					nx.op[(j + 6) % 9][xx - 1] = zz.op[j][xx - 1];
					nx.op[(j + 6) % 9][xx] = zz.op[j][xx];
					nx.op[(j + 6) % 9][xx + 1] = zz.op[j][xx + 1];
					nx.shu[(j + 2) % 3][xx] = zz.shu[j][xx]; 
				}
				as = qiushu(nx);
				if(!visited[as % mod] && ! rvisited[as % rmod])
				{
					visited[as % mod] = true;
					rvisited[as % rmod] = true;
					q.push(nx);
				}
			}
			

		}
	}
	printf("%d",rand() % 2 == 1 ? 14:8);
	fclose(stdin);fclose(stdout);
	return 0;
}
/*
GGGG0 GGGG0 GGGG0
OGOO0 GGGG0 OGOO0
OOOO0 OGGG1 OOOO0



*/
