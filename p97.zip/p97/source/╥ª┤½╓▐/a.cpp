#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
int n,ans,tt,maxl,minn;
char ch,bb;
int a[1000001];
int b[27];
int c[27],d[27];
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	cin>>n;
	bb=getchar();
	for(int i=1;i<=n;i++)
	{
		ch=getchar();
		a[i]=ch-'a'+1;
	}
	for(int i=1;i<=n;i++)
	{
		maxl=-1,minn=1000000;
		if(!b[a[i]]) b[a[i]]=++tt;
		c[b[a[i]]]++;
		for(int j=1;j<=tt;j++)
		maxl=max(maxl,c[j]),minn=min(minn,c[j]),d[j]=c[j];
		ans=max(maxl-minn,ans);
		for(int j=2;j<=i-1;j++)
		{
		maxl=-1,minn=10000000;
		d[b[a[j-1]]]--;
		for(int g=1;g<=tt;g++)
		{
		maxl=max(maxl,d[g]);
		if(d[g]!=0)minn=min(minn,d[g]);
	    }
		ans=max(ans,maxl-minn);
		}
	}
	printf("%d",ans);

	return 0;
}
/*
10
aabbaaabab
*/

