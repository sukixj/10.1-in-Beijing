#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
double x1,yy1,x2,yy2;
double w1,w2,w3,w4;
double m1,m2,m3,m4;
double l1,l2,l3;
double n,nn;
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	cin>>x1>>yy1>>x2>>yy2;
	cin>>w1>>w2>>w3>>w4;
	cin>>m1>>m2>>m3>>m4;
	if(x1==x2&&w1!=w3)
	{
		l2=(w4-w2)/(w3-w1);
		n=x1;
		nn=l2*n-l2*w1+w2;
	}
	else if(w1==w3&&x1!=x2)
	{
		l1=(yy2-yy1)/(x2-x1);
		n=w1;
		nn=l1*n-l1*x1+yy1;
	}
	else
	{
	l1=(yy2-yy1)/(x2-x1);l2=(w4-w2)/(w3-w1);l3=(m4-m3)/(m2-m1);
	n=(l1*x1-l2*w1+w2-yy1)/(l1-l2);
	nn=l1*n-l1*x1+yy1;
    }
	if((n<=x1&&n<=x2&&x1!=x2)||(n>=x1&&n>=x2&&x1!=x2)||(n<=w1&&n<=w3&&w1!=w3)||(n>=w1&&n>=w3&&w1!=w3)||(nn<=yy1&&nn<=yy2&&yy1!=yy2)||(nn>=yy1&&nn>=yy2&&yy1!=yy2)||(nn<=w2&&nn<=w4&&w2!=w4)||(nn>=w2&&nn>=w4&&w2!=w4))
	{
	cout<<"YES";
	return 0;
    }
    cout<<"NO";
	return 0;
}


