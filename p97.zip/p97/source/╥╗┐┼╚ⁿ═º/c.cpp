#include<iostream>
#include<cstdio>
using namespace std;
int main(){
	freopen("c.in","r",stdin):
	freopen("c.out","w",stdout);
	printf("5");
	return 0;
}

