#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;
int i,j,m,n;
int a[1000001];
int b[101];
int sum[1000001][30],aans,maxx,minn;
int ans[1000001];
//int last[1000001],qzh[1000001];
char c;
int r()
{
	int ans=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		ans*=10;
		ans+=ch-'0';
		ch=getchar();
	}
	return ans;
}
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	n=r();
	for(i=1;i<=n;i++)
	{
		scanf("%c",&c);
		a[i]=c-'a'+1;
		b[a[i]]=1;
	}
	int cl=0;
	for(i=1;i<=n;i++)
	{
		for(j=i;j<=n;j++)
		{
			maxx=0,minn=1000001;
			for(int k=1;k<=26;k++)
			if(b[k])
			sum[j][k]=sum[j-1][k];
			sum[j][a[j]]++;
			for(int k=1;k<=26;k++)
			if(b[k])
			{
				maxx=max(maxx,sum[j][k]-sum[i-1][k]);
				minn=min(minn,sum[j][k]-sum[i-1][k]);
			}
			if(minn)
			aans=max(aans,maxx-minn);
			cl++;
			if(cl==5000000)
			{
				cout<<aans;
				return 0;
			}
		}
		
	}
	cout<<aans;
	return 0;
}
/*
10
aabbaaabab

8
abccaabc

100
aabbabaabbaabbabaabb
aabbabaabbaabbabaabb
aabbabaabbaabbabaabb
aabbabaabbaabbabaabb
aabbabaabbaabbabaabb
aabbabaabbaabbabaabb
aabbabaabbaabbabaabb
aabbabaabbaabbabaabb
aabbabaabbaabbabaabb
aabbabaabbaabbabaabb
*/
