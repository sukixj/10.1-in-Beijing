#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;
int i,j,m,n;
double x1,y1,x2,y2,qx1,qy1,qx2,qy2,jx1,jy1,jx2,jy2;
double k1,k2,k3,b1,b2,b3,solx,solxx;
double dcx,dcy,ank,anb;

int r()
{
	int ans=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9')
	{
		if(ch=='-')
		f=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9')
	{
		ans*=10;
		ans+=ch-'0';
		ch=getchar();
	}
	return ans*f;
}
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	x1=r(),y1=r();
	x2=r(),y2=r();
	
	qx1=r(),qy1=r();
	qx2=r(),qy2=r();
	jx1=r(),jy1=r();
	jx2=r(),jy2=r();
	
	if(x1!=x2)//k wu qiongȷ��ֱ�ӿ������� 
	{
		k1=(y2-y1)/(x2-x1);
		b1=(y1-k1*x1);
	}
	if(qx1!=qx2)
	{
		k2=(qy2-qy1)/(qx2-qx1);//ǽ����ֱ�� 
		b2=(qy1-k2*qx1);
	}
	if(jx1!=jx2)
	{
		k3=(jy2-jy1)/(jx2-jx1);//������ֱ�� 
		b3=(jy1-k3*jx1);
	}
	if(x1==x2)
	solx=x1;//ǽ�����߽�������� 
	else if(qx1==qx2)
	solx=qx1;
	else
	solx=(b2-b1)/(k1-k2);
	if(solx<=min(x1,x2)||solx>=max(x1,x2))
	{
		cout<<"YES";
		return 0;
	}
	else
	{
		if(y1!=y2)//����k����� 
		{//�ԳƵ� 
			dcx=2*(y1-b3)*k3/(k3*k3+1)+(1-k3*k3)/(k3*k3+1)*x1;
			dcy=-(1/k3)*dcx+y1+x1/k3;
		}
		else//����k����� 
		{//�ԳƵ� 
			dcx=2*jx1-x1;
			dcy=y1;
		}
		if(dcx!=x2)
		{	
			ank=(dcy-y2)/(dcx-x2);//�ԳƵ���y2����ֱ�� 
			anb=(y2-ank*x2);
		}
		if(dcx!=x2)
		solxx=(anb-b3)/(ank-k3);//���������
		else
		solxx=x2;
			if(solxx>=min(jx1,jx2)&&solxx<=max(jx1,jx2))
			{
				cout<<"YES";
				return 0;
			}
			else
			{
				cout<<"NO";
				return 0;
			}
	}
	
	return 0;
}
/*
-1 3
1 3
0 2 0 4
0 0 0 1

0 0
1 1
0 1 1 0
-1 1 1 3
*/
