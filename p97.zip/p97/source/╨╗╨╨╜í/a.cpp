#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>

#define UMAX(a, m) if ((a) > m) m = (a)
#define FMAX(a, m) if ((a) && (a) > m) m = (a)
#define FMIN(a, m) if ((a) && (a) < m) m = (a)
using namespace std;

int n, ans;
char str[1000009];
int pre[1000009][26];
int main() {
    freopen("a.in", "r", stdin);
    freopen("a.out", "w", stdout);
    
    scanf("%d", &n);
    getchar();
    for (int i = 1; i <= n; i++) {
        str[i] = getchar();
        for (int j = 0; j < 26; j++)
            pre[i][j] = pre[i - 1][j]
                      + (int)((str[i] - 'a') == j);
    }
    for (int i = 1; i <= n; i++)
        for (int j = i; j <= n; j++) {
            int max1 = 0, min1 = n + 1;
            for (int k = 0; k < 26; k++) {
                int a1 = pre[j][k] - pre[i - 1][k];
                FMAX(a1, max1);
                FMIN(a1, min1);
            }
            UMAX(max1 - min1, ans);
        }
    printf("%d\n", ans);
    //getchar(); getchar();
    return 0;
}
