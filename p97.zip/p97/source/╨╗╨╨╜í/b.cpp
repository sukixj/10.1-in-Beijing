#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <cmath>
using namespace std;

typedef struct point {
    double x, y;
    point(double x = 0, double y = 0) : x(x), y(y) {}
    point operator()(double _x = 0, double _y = 0) {
        x = _x, y = _y;
        return *this;
    }
    friend istream& operator>>(istream &in, point &p) {
        return in >> p.x >> p.y;
    }
    point d(double xlm, double b) {
        double xlm1 = (xlm != 100000000) ? (-1.0 / xlm) : 0;
        double b1 = (this -> y) - (xlm1 * (this -> x));
        double x = (b1 - b) / (xlm - xlm1);
        double y = xlm * x + b;
        return point((x + (x - this -> x)), (y + (x - this -> y)));
    }
};

typedef struct line {
    point a, b;
    line(point a = point(), point b = point()) : a(a), b(b) {
        if (a.x < b.x) swap(a, b);
    }
    line operator()(point _a = point(), point _b = point()) {
        a = _a, b = _b;
        if (a.x < b.x) swap(a, b);
        return *this;
    }
    friend istream& operator>>(istream &in, line &p) {
        return in >> p.a >> p.b;
    }
    friend bool operator&(line x, line y) {
        double xlx = (x.a.x - x.b.x) ? (double)(x.a.y - x.b.y) / (double)(x.a.x - x.b.x) : 100000000;
        double xly = (x.a.x - x.b.x) ? (double)(y.a.y - y.b.y) / (double)(y.a.x - y.b.x) : 100000000;
        if (abs(xlx - xly) <= 1e-8)
            if (x.b.x >= min(y.a.x, y.b.x) && x.b.x <= max(y.a.x, y.b.x)
             || y.b.x >= min(x.a.x, x.b.x) && y.b.x <= max(x.a.x, x.b.x))
                return true;
        return false;
    }
    friend bool operator*(line x, line y) {
        if (x.a.x > y.a.x) swap(x, y);
        return x.b.x >= y.b.x && max(y.a.y, y.b.y) >= min(y.a.y, y.b.y) && y.a.x >= x.a.x;
    }
    friend bool operator==(const line &x, const line &y) {
        return x.a == y.a && x.b == y.b;
    }
    line d(double xlm, double b) {
        return line(this -> a.d(xlm, b), this -> b.d(xlm, b));
    }
};
point v, p;
line w, m;

void yes() {
    printf("YES\n");
    exit(0);
}

void no() {
    printf("NO\n");
    exit(0);
}

int main() {
    freopen("b.in", "r", stdin);
    freopen("b.out", "w", stdout);
    
    cin >> v >> p >> w >> m;
    if (!(line(v, p) * w) && !(line(v, p) & w)) {
        if (!(line(v, p) * m))
            yes();
        else no();
    }
    
    double xlm = (m.a.x - m.b.x) ? (double)(m.a.y - m.b.y) / (double)(m.a.x - m.b.x) : 100000000;
    double b = (xlm == 100000000) ? m.a.y : (m.a.y - (xlm * m.a.x));
    line w2 = w.d(xlm, b);
    point p2 = p.d(xlm, b);
    if (!(line(v, p2) * w) && !(line(v, p2) & w) && !(line(v, p2) * w2) && !(line(v, p2) & w2) && (line(v,p2) * m)) yes();
    no();
    return 0;
}
/*
0 0
10 0
100 100 101 101
1 0 3 0
*/
