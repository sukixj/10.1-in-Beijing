#include<cstdio>
#include<cstring>
#include<iostream>
#define for0(i,n) for(int i=0;i<=(n);i++)
#define for1(i,n) for(int i=1;i<=(n);i++)
using namespace std;
inline int read()
{
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=10*x+ch-'0';ch=getchar();}
    return x*f;
}
int n,ans=0,f[30][30],g[30][30];
int main()
{
    freopen("a.in","r",stdin);
    freopen("a.out","w",stdout);
    n=read();
    for1(i,n)
    {
        char ch=getchar();
        while(ch>'z'||ch<'a')ch=getchar();
        int x=ch-'a';
        for0(j,25)
        {
            f[x][j]++;
            f[j][x]--;
            if(!g[j][x])g[j][x]=1;
            if(g[j][x]==2){g[j][x]=1;f[j][x]++;}
            if(f[j][x]<=-1){f[j][x]=-1;g[j][x]=2;}
            if(g[j][x])ans=max(ans,f[j][x]);
            if(g[x][j])ans=max(ans,f[x][j]);
        }
    }
    printf("%d\n",ans);
}
