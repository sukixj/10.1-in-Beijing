#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<vector>
#include<cstring>
#include<algorithm>
#include<iomanip>
using namespace std;
int n,b[26],mn,mx=0,a[1000099];
inline void gxmn()
{
	mn=1000099;
	for(int i=0;i<26;i++)	if(b[i])	if(b[i]<mn)	mn=b[i];
}
int main()
{
	freopen("a.in","r",stdin);
	freopen("a.out","w",stdout);
	scanf("%d",&n);
	char c=getchar();
	for(int i=0;i<26;i++)
	{
		b[i]=0;
	}
	while(!(c>=97&&c<=122))
	{
		c=getchar();
	}
	for(int i=1;i<n;i++)
	{
		b[c-97]++;
		if(b[c-97]>mx) mx=b[c-97];
		gxmn();
		a[i-1]=mx-mn;
//printf("%d",a[i-1]);
		c=getchar();
	}
	b[c-97]++;
	if(b[c-97]>mx) mx=b[c-97];
	gxmn();
	a[n-1]=mx-mn;
//printf("%d\n",a[n-1]);
	mx=0;
	mn=0;
	for(int i=n-1;i>0;i--)
	{
		a[i]-=a[i-1];
//printf("%d",a[i]);
		mn+=a[i];
		if(mn<0)
		{
			mn=0;
		}
		else
		{
			if(mn>mx)
			{
				mx=mn;
			}
		}
	}
//printf("\n");
	printf("%d",mx);
	return 0;
}

