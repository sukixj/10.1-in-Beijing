#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<vector>
#include<cstring>
#include<algorithm>
#include<iomanip>
using namespace std;
double intin()
{
	char cc=getchar();
	while(!((cc==45)||(cc>=48&&cc<=57))) cc=getchar();
	bool bb=0;
	if(cc==45)
	{
		bb=1;
		cc=getchar();
	}
	int aa=0;
	while(cc>=48&&cc<=57)
	{
		aa=(aa<<1)+(aa<<3)+cc-48;
		cc=getchar();
	}
	if(bb) aa=0-aa;
	double tt=aa*1.0;
	return tt;
}
/*
��          sb 
�ϰ�ǽ      za 
����        jm 
��ֱ�ھ���  cz
����		jx 
����        z
��ĸ        m 
y=k*x+b;
*/
struct rbq
{
	double k,b,px,py,qx,qy;
}sb,za,jm,cz,jx;
double k(rbq aa) { return (aa.py-aa.qy)*1.0/(aa.px-aa.qx)*1.0; }
double b(rbq aa) { return aa.py*1.0-aa.k*(aa.px*1.0); }
bool bj(double cc,double dd)
{
	int pp=cc,qq=dd;
	if(pp>qq)return 1;
	else	if(pp<qq) return 0;
			else{double aa=cc*10.0-pp*10.0,bb=dd*10.0-qq*10.0;pp=aa;qq=bb;int tt=0;
		while(pp==qq&&tt<20)
		{
			aa=aa*10.0-pp*10.0;
			bb=bb*10.0-qq*10.0;
			pp=aa;
			qq=bb;
			tt++;
		}
		if(pp>qq)return 1;
		else	return 0;
			}
		
}
bool xxoo(rbq sy,rbq mb)
{
	double nopy=sy.px*mb.k+mb.b,noqy=sy.qx*mb.k+mb.b,mbpy=sy.py,mbqy=sy.qy;
	if(bj(nopy,mbpy)==bj(noqy,mbqy))
	{
		return 0;
	}
	else
	{
		return 1;
	}
}
int main()
{
	freopen("b.in","r",stdin);
	freopen("b.out","w",stdout);
	
	sb.px=intin();
	sb.py=intin();
	sb.qx=intin();
	sb.qy=intin();
	sb.k=k(sb);
	sb.b=b(sb);
	za.px=intin();
	za.py=intin();
	za.qx=intin();
	za.qy=intin();
	za.k=k(za);
	za.b=b(za);
	jm.px=intin();
	jm.py=intin();
	jm.qx=intin();
	jm.qy=intin();
	if(xxoo(sb,za)==0||xxoo(za,sb)==0)
	{
		printf("YES");
		return 0;
	}
	jm.k=k(za);
	jm.b=b(za);
	double mdk=(-1)/jm.k;
	double mdb=sb.qy-sb.qx*mdk;
	double mdx=(mdb-jm.b)*1.0/(jm.k-mdb)*1.0;
	double mdy=mdx*jm.k+jm.b;
	jx.py=sb.py;
	jx.px=sb.px;
	jx.qx=mdx*2.0-sb.qx*1.0;
	jx.qy=mdy*2.0-sb.qy*1.0; 
	jx.k=k(jx);
	jx.b=b(jx);
	if(xxoo(jx,jm)&&xxoo(jm,jx))
	{
		if(xxoo(jx,sb)==0||xxoo(sb,jx)==0)
		{
			printf("YES");
			return 0;
		}
	}
	printf("NO");
	return 0;
}
